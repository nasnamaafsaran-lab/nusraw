@echo off
echo Setting up Elite System to run on startup...

:: Get the path to the start_system.bat script
set "SCRIPT_PATH=%~dp0start_system.bat"

:: Get the user's Startup folder
set "STARTUP_FOLDER=%APPDATA%\Microsoft\Windows\Start Menu\Programs\Startup"
set "SHORTCUT_PATH=%STARTUP_FOLDER%\EliteSystem.lnk"

:: Create a shortcut in the Startup folder using PowerShell
echo Creating shortcut in %STARTUP_FOLDER%...
powershell "$s=(New-Object -COM WScript.Shell).CreateShortcut('%SHORTCUT_PATH%');$s.TargetPath='%SCRIPT_PATH%';$s.Save()"

echo.
echo Done! The system will now start automatically when you turn on your computer.
pause
