@echo off
title Elite System Server
echo Starting Elite System...
echo Please wait while the system initializes...

:: Navigate to the project root directory (one level up from scripts)
cd /d "%~dp0.."

:: Check if node_modules exists, if not install dependencies
if not exist "node_modules" (
    echo Installing dependencies...
    call npm install
)

:: Open the browser after 5 seconds
timeout /t 5 /nobreak >nul
start "" http://localhost:3000

:: Start the server
echo Server is running. Do not close this window.
call npm start

pause
