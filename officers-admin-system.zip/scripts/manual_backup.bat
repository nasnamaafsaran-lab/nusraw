@echo off
echo Creating Manual Backup...

:: Navigate to the project root directory
cd /d "%~dp0.."

:: Create backups folder if it doesn't exist
if not exist "backups" mkdir "backups"

:: Get current date and time for filename
for /f "tokens=2-4 delims=/ " %%a in ('date /t') do (set mydate=%%c-%%a-%%b)
for /f "tokens=1-2 delims=/:" %%a in ('time /t') do (set mytime=%%a%%b)
set "FILENAME=manual-backup-%mydate%-%mytime%.json"

:: Use curl to download the backup from the server
curl http://localhost:3000/api/backup -o "backups\%FILENAME%"

echo.
echo Backup saved to backups\%FILENAME%
pause
