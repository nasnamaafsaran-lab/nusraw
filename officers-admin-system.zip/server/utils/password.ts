import bcrypt from 'bcrypt';

export const hashPasswordSync = (password: string): string => {
  return bcrypt.hashSync(password, 10);
};

export const comparePasswordSync = (password: string, hash: string): boolean => {
  if (!hash || (!hash.startsWith('$2b$') && !hash.startsWith('$2a$') && !hash.startsWith('$2y$'))) {
    return password === hash;
  }
  return bcrypt.compareSync(password, hash);
};
