import Database from 'better-sqlite3';
import path from 'path';
import fs from 'fs';
import { hashPasswordSync } from './utils/password.js';

const dbPath = path.resolve('database.sqlite');
const db = new Database(dbPath);

// Enable foreign keys and WAL mode
db.pragma('foreign_keys = ON');
db.pragma('journal_mode = WAL');

// Drop existing tables to ensure clean schema for the new requirements
/*
db.exec(`
  DROP TABLE IF EXISTS messages;
  DROP TABLE IF EXISTS chats;
  DROP TABLE IF EXISTS attachments;
  DROP TABLE IF EXISTS history;
  DROP TABLE IF EXISTS documents;
  DROP TABLE IF EXISTS workflow_templates;
  DROP TABLE IF EXISTS users;
  DROP TABLE IF EXISTS departments;
`);
*/

// Create Tables
db.exec(`
  CREATE TABLE IF NOT EXISTS users (
    id TEXT PRIMARY KEY,
    name TEXT NOT NULL,
    username TEXT UNIQUE NOT NULL,
    password TEXT NOT NULL,
    role TEXT NOT NULL, -- super_admin, director_general, deputy_director, staff_officer, office_manager, section_director, unit_head, employee, dispatch_staff, print_staff
    department TEXT NOT NULL,
    title TEXT NOT NULL,
    avatar TEXT,
    signature TEXT, -- Base64 or path to signature image
    isLocked INTEGER DEFAULT 0
  );

  CREATE TABLE IF NOT EXISTS departments (
    id TEXT PRIMARY KEY,
    name TEXT NOT NULL,
    parentDept TEXT,
    type TEXT, -- 'directorate', 'department', 'unit', 'office', 'special'
    allowedDestinations TEXT -- JSON array of department IDs
  );

  CREATE TABLE IF NOT EXISTS workflow_templates (
    id TEXT PRIMARY KEY,
    name TEXT NOT NULL,
    description TEXT,
    steps TEXT NOT NULL, -- JSON array of WorkflowStep
    createdBy TEXT NOT NULL,
    createdAt TEXT NOT NULL
  );

  CREATE TABLE IF NOT EXISTS documents (
    id TEXT PRIMARY KEY,
    referenceNumber TEXT UNIQUE NOT NULL,
    title TEXT NOT NULL,
    content TEXT NOT NULL, -- Encrypted content
    senderId TEXT NOT NULL,
    senderName TEXT NOT NULL,
    senderDepartment TEXT NOT NULL,
    currentHolderId TEXT, -- Can be a User ID or a Department ID
    status TEXT NOT NULL, -- Pending, Under Review, Approved, Rejected, Archived
    priority TEXT NOT NULL, -- Normal, Urgent, Top Secret
    confidentiality TEXT NOT NULL,
    deadline TEXT,
    createdAt TEXT NOT NULL,
    participants TEXT, -- JSON array of user IDs/Dept names
    workflowStage TEXT NOT NULL, -- Tracks the strict sequential flow step
    workflowTemplateId TEXT,
    currentStepIndex INTEGER DEFAULT 0,
    isCircular INTEGER DEFAULT 0,
    circularReadBy TEXT, -- JSON array of user IDs
    signatureData TEXT, -- JSON object storing digital signatures
    incomingNumber TEXT,
    incomingDate TEXT,
    source TEXT,
    relatedDocIds TEXT, -- JSON array of document IDs
    relatedRoomName TEXT,
    FOREIGN KEY(workflowTemplateId) REFERENCES workflow_templates(id)
  );

  CREATE TABLE IF NOT EXISTS history (
    id TEXT PRIMARY KEY,
    documentId TEXT NOT NULL,
    action TEXT NOT NULL,
    fromUser TEXT NOT NULL,
    toUser TEXT,
    timestamp TEXT NOT NULL,
    note TEXT,
    metadata TEXT,
    FOREIGN KEY(documentId) REFERENCES documents(id) ON DELETE CASCADE
  );

  CREATE TABLE IF NOT EXISTS attachments (
    id TEXT PRIMARY KEY,
    documentId TEXT NOT NULL,
    name TEXT NOT NULL,
    type TEXT NOT NULL,
    url TEXT NOT NULL,
    FOREIGN KEY(documentId) REFERENCES documents(id) ON DELETE CASCADE
  );

  CREATE TABLE IF NOT EXISTS comments (
    id TEXT PRIMARY KEY,
    documentId TEXT NOT NULL,
    userId TEXT NOT NULL,
    userName TEXT NOT NULL,
    content TEXT NOT NULL,
    timestamp TEXT NOT NULL,
    FOREIGN KEY(documentId) REFERENCES documents(id) ON DELETE CASCADE
  );

  CREATE TABLE IF NOT EXISTS chats (
    id TEXT PRIMARY KEY,
    type TEXT NOT NULL, -- 'direct', 'group'
    name TEXT, -- For groups
    participants TEXT NOT NULL, -- JSON array of user IDs
    createdAt TEXT NOT NULL
  );

  CREATE TABLE IF NOT EXISTS messages (
    id TEXT PRIMARY KEY,
    chatId TEXT NOT NULL,
    senderId TEXT NOT NULL,
    content TEXT NOT NULL,
    type TEXT NOT NULL, -- 'text', 'file', 'voice'
    fileUrl TEXT,
    createdAt TEXT NOT NULL,
    readBy TEXT, -- JSON array of user IDs
    FOREIGN KEY(chatId) REFERENCES chats(id) ON DELETE CASCADE
  );

  CREATE TABLE IF NOT EXISTS notifications (
    id TEXT PRIMARY KEY,
    userId TEXT NOT NULL,
    title TEXT NOT NULL,
    message TEXT NOT NULL,
    type TEXT, -- 'info', 'success', 'warning', 'error'
    read INTEGER DEFAULT 0,
    timestamp TEXT NOT NULL,
    docId TEXT
  );

  CREATE TABLE IF NOT EXISTS hand_delivery_records (
    id TEXT PRIMARY KEY,
    documentId TEXT NOT NULL,
    receiverName TEXT NOT NULL,
    receiverId TEXT NOT NULL,
    receiverDept TEXT NOT NULL,
    receiverPhotoUrl TEXT,
    documentPhotoUrl TEXT,
    deliveredBy TEXT NOT NULL,
    timestamp TEXT NOT NULL,
    notes TEXT,
    signature TEXT,
    FOREIGN KEY(documentId) REFERENCES documents(id) ON DELETE CASCADE
  );
`);

// Seed Initial Data
const departments = [
  // Directorate Level
  { id: 'directorate_office', name: 'بەڕێوەبەری ئیدارەی ئەفسەران', type: 'directorate' },
  { id: 'deputy_office', name: 'جێگری بەڕێوەبەری ئیدارەی ئەفسەران', type: 'directorate' },
  { id: 'staff_officer', name: 'ظابط ركن', type: 'office' },
  { id: 'main_office', name: 'نوسینگە', type: 'office' },
  
  // Milakat Department
  { id: 'milakat_dept', name: 'بەشی میلاکات', type: 'department' },
  { id: 'milakat_director_office', name: 'بەڕێوەبەری بەشی میلاکات', type: 'office', parentDept: 'milakat_dept' },
  { id: 'milakat_transfer', name: 'هۆبەی گواستنەوە و ڕێکخستنی میلاکات', type: 'unit', parentDept: 'milakat_dept' },
  { id: 'milakat_execution', name: 'هۆبەی جێبەجێکردنی میلاکات', type: 'unit', parentDept: 'milakat_dept' },

  // Promotion Department
  { id: 'promotion_dept', name: 'بەشی پلە بەرزکردنەوە', type: 'department' },
  { id: 'promotion_director_office', name: 'بەڕێوەبەری بەشی پلە بەرزکردنەوە', type: 'office', parentDept: 'promotion_dept' },
  { id: 'promotion_office', name: 'نوسینگەی پلە بەرزکردنەوە', type: 'unit', parentDept: 'promotion_dept' },
  { id: 'courses_unit', name: 'هۆبەی دەورات', type: 'unit', parentDept: 'promotion_dept' },

  // Legal Department
  { id: 'legal_dept', name: 'بەشی یاسایی', type: 'department' },
  { id: 'legal_director_office', name: 'بەڕێوەبەری بەشی یاسایی', type: 'office', parentDept: 'legal_dept' },
  { id: 'legal_office', name: 'نوسینگەی یاسایی', type: 'unit', parentDept: 'legal_dept' },
  { id: 'retirement_unit', name: 'هۆبەی خانەنشینی', type: 'unit', parentDept: 'legal_dept' },

  // Admin Department
  { id: 'admin_dept', name: 'بەشی ئیدارە', type: 'department' },
  { id: 'admin_director_office', name: 'بەڕێوەبەری بەشی ئیدارە', type: 'office', parentDept: 'admin_dept' },
  { id: 'files_unit', name: 'هۆبەی دۆسییەکان', type: 'unit', parentDept: 'admin_dept' },
  { id: 'service_form_unit', name: 'هۆبەی فۆڕمی ڕاژە', type: 'unit', parentDept: 'admin_dept' },
  { id: 'id_unit', name: 'هۆبەی ناسنامە', type: 'unit', parentDept: 'admin_dept' },
  { id: 'umrah_unit', name: 'هۆبەی ئومرە', type: 'unit', parentDept: 'admin_dept' },

  // Special Units
  { id: 'print_room', name: 'بەشی پڕێنت کردن', type: 'special' },
  { id: 'dispatch_room', name: 'بەشی ناردنی نووسراو', type: 'special' },
];

const users = [
  // Directorate
  { id: 'u_director', name: 'Director General', username: 'director', password: '123', role: 'director_general', department: 'directorate_office', title: 'بەڕێوەبەری ئیدارەی ئەفسەران' },
  { id: 'u_deputy', name: 'Deputy Director', username: 'deputy', password: '123', role: 'deputy_director', department: 'deputy_office', title: 'جێگری بەڕێوەبەری ئیدارەی ئەفسەران' },
  { id: 'u_staff', name: 'Staff Officer', username: 'staff', password: '123', role: 'staff_officer', department: 'staff_officer', title: 'ظابط ركن' },
  { id: 'u_office_mgr', name: 'Office Manager', username: 'office', password: '123', role: 'office_manager', department: 'main_office', title: 'بەڕێوەبەری نوسینگە' },
  { id: 'u_office_emp', name: 'Office Staff', username: 'office_staff', password: '123', role: 'employee', department: 'main_office', title: 'کارمەندی نوسینگە' },

  // Milakat
  { id: 'u_milakat_head', name: 'Milakat Head', username: 'milakat_head', password: '123', role: 'section_director', department: 'milakat_director_office', title: 'بەڕێوەبەری بەشی میلاکات' },
  { id: 'u_milakat_trans', name: 'Transfer Unit Head', username: 'milakat_trans', password: '123', role: 'unit_head', department: 'milakat_transfer', title: 'لێپرسراوی هۆبەی گواستنەوە' },
  { id: 'u_milakat_exec', name: 'Execution Unit Head', username: 'milakat_exec', password: '123', role: 'unit_head', department: 'milakat_execution', title: 'لێپرسراوی هۆبەی جێبەجێکردن' },
  { id: 'u_milakat_emp1', name: 'Milakat Employee', username: 'milakat_emp', password: '123', role: 'employee', department: 'milakat_execution', title: 'کارمەند' },

  // Promotion
  { id: 'u_promo_head', name: 'Promotion Head', username: 'promo_head', password: '123', role: 'section_director', department: 'promotion_director_office', title: 'بەڕێوەبەری بەشی پلە بەرزکردنەوە' },
  { id: 'u_promo_office', name: 'Promotion Office', username: 'promo_office', password: '123', role: 'unit_head', department: 'promotion_office', title: 'لێپرسراوی نوسینگە' },
  { id: 'u_promo_emp', name: 'Promotion Employee', username: 'promo_emp', password: '123', role: 'employee', department: 'courses_unit', title: 'کارمەندی هۆبەی دەورات' },

  // Legal
  { id: 'u_legal_head', name: 'Legal Head', username: 'legal_head', password: '123', role: 'section_director', department: 'legal_director_office', title: 'بەڕێوەبەری بەشی یاسایی' },
  { id: 'u_legal_office', name: 'Legal Office', username: 'legal_office', password: '123', role: 'unit_head', department: 'legal_office', title: 'لێپرسراوی نوسینگەی یاسایی' },
  { id: 'u_legal_emp', name: 'Legal Employee', username: 'legal_emp', password: '123', role: 'employee', department: 'retirement_unit', title: 'کارمەندی هۆبەی خانەنشینی' },

  // Admin
  { id: 'u_admin_head', name: 'Admin Head', username: 'admin_head', password: '123', role: 'section_director', department: 'admin_director_office', title: 'بەڕێوەبەری بەشی ئیدارە' },
  { id: 'u_files_head', name: 'Files Unit Head', username: 'files_head', password: '123', role: 'unit_head', department: 'files_unit', title: 'لێپرسراوی هۆبەی دۆسییەکان' },

  // Special
  { id: 'u_dispatch', name: 'Dispatch Officer', username: 'dispatch', password: '123', role: 'dispatch_staff', department: 'dispatch_room', title: 'کارمەندی ناردن' },
  { id: 'u_print', name: 'Print Officer', username: 'print', password: '123', role: 'print_staff', department: 'print_room', title: 'کارمەندی چاپ' },
  { id: 'u_super', name: 'Super Admin', username: 'admin', password: '123', role: 'super_admin', department: 'main_office', title: 'Super Admin' },
];

const seed = db.transaction(() => {
  // Disable foreign keys temporarily to allow clearing tables with dependencies
  db.pragma('foreign_keys = OFF');

  // Clear existing data to ensure clean state
  db.prepare('DELETE FROM departments').run();
  db.prepare('DELETE FROM users').run();
  db.prepare('DELETE FROM workflow_templates').run();

  const insertDept = db.prepare('INSERT INTO departments (id, name, parentDept, type, allowedDestinations) VALUES (?, ?, ?, ?, ?)');
  for (const dept of departments) {
    insertDept.run(dept.id, dept.name, dept.parentDept || null, dept.type, JSON.stringify([]));
  }

  const insertUser = db.prepare('INSERT INTO users (id, name, username, password, role, department, title, avatar, signature, isLocked) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?)');
  for (const user of users) {
    insertUser.run(user.id, user.name, user.username, hashPasswordSync(user.password), user.role, user.department, user.title, null, null, 0);
  }

  // Seed default workflow template
  const defaultSteps = [
    { id: 'step1', label: 'بەڕێوەبەری بەش (Dept Head)', role: 'section_director' },
    { id: 'step2', label: 'لێپرسراوی هۆبە (Unit Head)', role: 'unit_head' },
    { id: 'step3', label: 'کارمەند (Employee)', role: 'employee' },
    { id: 'step4', label: 'لێپرسراوی هۆبە (Unit Head)', role: 'unit_head' },
    { id: 'step5', label: 'بەڕێوەبەری بەش (Dept Head)', role: 'section_director' },
    { id: 'step6', label: 'جێگر / بەڕێوەبەر (Deputy/Director)', role: 'deputy_director' }
  ];

  db.prepare('INSERT INTO workflow_templates (id, name, description, steps, createdBy, createdAt) VALUES (?, ?, ?, ?, ?, ?)').run(
    'default_workflow',
    'ڕەوتی کاری گشتی (Default Workflow)',
    'ڕەوتی کاری ئاسایی بۆ نوسراوەکان',
    JSON.stringify(defaultSteps),
    'u_super',
    new Date().toISOString()
  );

  db.pragma('foreign_keys = ON');
});

// Run seed if users table is empty
try {
  const userCount = db.prepare('SELECT count(*) as count FROM users').get() as { count: number };
  if (userCount.count === 0) {
    console.log('Seeding database...');
    seed();
    console.log('Database seeded!');
  } else {
      console.log('Database already seeded, checking for plain text passwords...');
      const users = db.prepare('SELECT id, password FROM users').all() as { id: string, password: string }[];
      let updatedCount = 0;
      const updateStmt = db.prepare('UPDATE users SET password = ? WHERE id = ?');
      
      for (const user of users) {
          if (user.password && user.password.length < 50) { // Bcrypt hashes are usually 60 chars
              updateStmt.run(hashPasswordSync(user.password), user.id);
              updatedCount++;
          }
      }
      if (updatedCount > 0) {
          console.log(`Migrated ${updatedCount} users to hashed passwords.`);
      }
  }
} catch (error) {
  console.error('Failed to seed/migrate database:', error);
}

export default db;
