declare module 'print-js' {
  function printJS(configuration: any): void;
  export default printJS;
}
