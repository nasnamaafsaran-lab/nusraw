export type Role = 
  | 'super_admin'
  | 'director_general'
  | 'deputy_director'
  | 'staff_officer'
  | 'office_manager'
  | 'section_director' // Department Head
  | 'unit_head' // Unit/Hoba Head
  | 'employee'
  | 'dispatch_staff'
  | 'print_staff'
  | 'control_room';

export type DepartmentType = 'directorate' | 'department' | 'unit' | 'office' | 'special';

export interface Department {
  id: string;
  name: string;
  parentDept?: string;
  type: DepartmentType;
  allowedDestinations?: string[];
}

export type WorkflowStage = 
  | 'DISPATCH'
  | 'DEPT_HEAD_IN'
  | 'UNIT_HEAD_IN'
  | 'EMPLOYEE_ACTION'
  | 'UNIT_HEAD_OUT'
  | 'DEPT_HEAD_OUT'
  | 'DEPUTY_REVIEW'
  | 'DIRECTOR_REVIEW'
  | 'PRINT_ROOM'
  | 'ARCHIVED';

export interface User {
  id: string;
  name: string;
  username: string;
  password?: string;
  role: Role;
  department: string;
  title: string;
  avatar?: string;
  signature?: string;
  isLocked: boolean;
}

export interface WorkflowStep {
  id: string;
  label: string;
  role: Role;
  departmentId?: string; // Optional: target a specific department
}

export interface WorkflowTemplate {
  id: string;
  name: string;
  description?: string;
  steps: WorkflowStep[];
  createdBy: string;
  createdAt: string;
}

export interface Comment {
  id: string;
  userId: string;
  userName: string;
  content: string;
  timestamp: string;
  userRole: string;
}

export interface Document {
  id: string;
  type: 'official' | 'request'; // Distinguish between official docs and requests
  referenceNumber: string;
  title: string;
  content: string;
  senderId: string;
  senderName: string;
  senderDepartment: string;
  currentHolderId: string;
  status: DocumentStatus;
  priority: Priority;
  confidentiality: Confidentiality;
  deadline?: string;
  createdAt: string;
  
  // New Fields for Registration
  incomingNumber?: string;
  incomingDate?: string;
  source?: string;
  relatedDocIds?: string[];
  relatedRoomName?: string;

  participants: string[];
  workflowStage: WorkflowStage;
  workflowTemplateId?: string;
  currentStepIndex: number;
  isCircular: boolean;
  circularReadBy: string[];
  signatureData?: SignatureData;
  history: HistoryEntry[];
  attachments: Attachment[];
  comments: Comment[]; // For the "Note Board"
}

// ... keep existing interfaces ...
export interface HandDeliveryRecord {
  id: string;
  documentId: string;
  receiverName: string;
  receiverId: string;
  receiverDept?: string;
  receiverRank?: string;
  receiverPhone?: string;
  receiverPhotoUrl?: string;
  documentPhotoUrl?: string;
  deliveredBy: string;
  timestamp: string;
  notes?: string;
  signature?: string;
}

export const MOCK_USERS: User[] = [];

export type DocumentStatus = 
  | 'Pending'
  | 'Under Review'
  | 'Approved'
  | 'Rejected'
  | 'Archived';

export type Priority = 'Normal' | 'Urgent' | 'Top Secret';
export type Confidentiality = 'Normal' | 'Confidential' | 'Secret';

export interface Attachment {
  id: string;
  documentId: string;
  name: string;
  type: 'pdf' | 'word' | 'excel' | 'image' | 'other';
  url: string;
  uploadedBy?: string;
  uploadedAt?: string;
}

export type DocumentLog = HistoryEntry;
export type DepartmentInfo = Department;

export interface HistoryEntry {
  id: string;
  documentId: string;
  action: string;
  fromUser: string;
  toUser: string;
  timestamp: string;
  note?: string;
  metadata?: any;
}

export interface SignatureData {
  [userId: string]: {
    signature: string; // Base64 image
    timestamp: string;
    ip: string;
  };
}

export interface Chat {
  id: string;
  type: 'direct' | 'group';
  name?: string;
  participants: string[]; // User IDs
  createdAt: string;
  lastMessage?: Message;
}

export interface Message {
  id: string;
  chatId: string;
  senderId: string;
  content: string;
  type: 'text' | 'file' | 'voice';
  fileUrl?: string;
  createdAt: string;
  readBy: string[];
}

export interface Notification {
  id: string;
  userId: string; // Target user ID or 'ALL'
  title: string;
  message: string;
  type?: 'info' | 'success' | 'warning' | 'error' | 'circular';
  read: boolean;
  timestamp: string;
  docId?: string;
}

export interface ActivityLog {
  id: string;
  userId: string;
  userName: string;
  action: string;
  target: string;
  timestamp: string;
  type: 'create' | 'approve' | 'reject' | 'archive' | 'comment';
}

export interface ToDoItem {
  id: string;
  userId: string;
  text: string;
  completed: boolean;
  createdAt: string;
  dueDate?: string;
}

