import React, { createContext, useContext, useState, useEffect } from 'react';
import { io, Socket } from 'socket.io-client';
import { User, Document, DocumentStatus, Attachment, Notification, Department, Chat, Message, Priority, Confidentiality, WorkflowTemplate, WorkflowStep, HandDeliveryRecord, ActivityLog, ToDoItem } from './types';

export interface Toast {
  id: string;
  message: string;
  type: 'success' | 'error' | 'warning' | 'info';
  action?: {
    label: string;
    onClick: () => void;
  };
}

interface AppState {
  currentUser: User | null;
  users: User[];
  departments: Department[];
  documents: Document[];
  chats: Chat[];
  notifications: Notification[];
  toasts: Toast[];
  workflowTemplates: WorkflowTemplate[];
  handDeliveryRecords: HandDeliveryRecord[];
  activityLogs: ActivityLog[];
  toDoItems: ToDoItem[];
  
  login: (username: string, password?: string) => Promise<boolean>;
  logout: () => void;
  
  isConnected: boolean;
  
  // Documents
  createDocument: (title: string, content: string, targetId: string, attachments: Attachment[], priority: Priority, confidentiality: Confidentiality, isCircular?: boolean, incomingNumber?: string, incomingDate?: string, source?: string, relatedDocIds?: string[], workflowTemplateId?: string, initialWorkflowStage?: string, type?: 'official' | 'request', deadline?: string, relatedRoomName?: string) => Promise<void>;
  updateDocument: (docId: string, updates: any) => Promise<void>;
  addComment: (docId: string, content: string) => Promise<void>;
  handDeliverDocument: (docId: string, record: HandDeliveryRecord) => Promise<void>;
  
  // Departments
  addDepartment: (dept: Department) => Promise<void>;
  updateDepartment: (dept: Department) => Promise<void>;

  // Workflow Templates
  addWorkflowTemplate: (template: WorkflowTemplate) => Promise<void>;
  updateWorkflowTemplate: (template: WorkflowTemplate) => Promise<void>;
  deleteWorkflowTemplate: (id: string) => Promise<void>;
  
  // Chats
  createChat: (type: 'direct' | 'group', participants: string[], name?: string) => Promise<string | null>;
  sendMessage: (chatId: string, content: string, type?: 'text' | 'file' | 'voice', fileUrl?: string) => Promise<void>;
  getChatMessages: (chatId: string) => Promise<Message[]>;
  
  // ToDo
  addToDo: (text: string) => Promise<void>;
  toggleToDo: (id: string) => Promise<void>;
  deleteToDo: (id: string) => Promise<void>;

  // Utils
  showToast: (message: string, type: 'success' | 'error' | 'warning' | 'info') => void;
  removeToast: (id: string) => void;
  uploadFiles: (files: File[]) => Promise<Attachment[]>;
  
  // Admin
  addUser: (user: Omit<User, 'id' | 'isLocked'>) => Promise<void>;
  updateUser: (id: string, user: Partial<User>) => Promise<void>;
  deleteUser: (id: string) => Promise<void>;
  toggleUserLock: (id: string) => Promise<void>;
  deleteDepartment: (id: string) => Promise<void>;
  markNotificationAsRead: (id: string) => void;
  refreshData: () => void;
  getVisibleDocuments: () => Document[];
  backupSystem: () => Promise<void>;
  restoreSystem: (file: File) => Promise<void>;
}

const AppContext = createContext<AppState | undefined>(undefined);

const API_URL = '/api';
let socket: Socket;

export const calculateWorkingDeadline = (days: number): string => {
  const date = new Date();
  let addedDays = 0;
  while (addedDays < days) {
    date.setDate(date.getDate() + 1);
    const day = date.getDay();
    // 0 = Sunday, 1 = Monday, 2 = Tuesday, 3 = Wednesday, 4 = Thursday
    if (day >= 0 && day <= 4) {
      addedDays++;
    }
  }
  // Set time to 13:00 (end of working day)
  date.setHours(13, 0, 0, 0);
  return date.toISOString();
};

export const AppProvider: React.FC<{ children: React.ReactNode }> = ({ children }) => {
  const [currentUser, setCurrentUser] = useState<User | null>(null);
  const [users, setUsers] = useState<User[]>([]);
  const [departments, setDepartments] = useState<Department[]>([]);
  const [documents, setDocuments] = useState<Document[]>([]);
  const [chats, setChats] = useState<Chat[]>([]);
  const [notifications, setNotifications] = useState<Notification[]>([]);
  const [toasts, setToasts] = useState<Toast[]>([]);
  const [workflowTemplates, setWorkflowTemplates] = useState<WorkflowTemplate[]>([]);
  const [handDeliveryRecords, setHandDeliveryRecords] = useState<HandDeliveryRecord[]>([]);
  const [activityLogs, setActivityLogs] = useState<ActivityLog[]>([]);
  const [toDoItems, setToDoItems] = useState<ToDoItem[]>([]);
  const [isConnected, setIsConnected] = useState(false);

  // Sound Effect
  const playNotificationSound = (type: string) => {
    try {
      const audioCtx = new (window.AudioContext || (window as any).webkitAudioContext)();
      const oscillator = audioCtx.createOscillator();
      const gainNode = audioCtx.createGain();
      
      oscillator.connect(gainNode);
      gainNode.connect(audioCtx.destination);
      
      if (type === 'warning' || type === 'error') {
        oscillator.type = 'sawtooth';
        oscillator.frequency.setValueAtTime(400, audioCtx.currentTime);
        oscillator.frequency.exponentialRampToValueAtTime(200, audioCtx.currentTime + 0.3);
      } else if (type === 'success') {
        oscillator.type = 'sine';
        oscillator.frequency.setValueAtTime(600, audioCtx.currentTime);
        oscillator.frequency.exponentialRampToValueAtTime(800, audioCtx.currentTime + 0.1);
      } else {
        oscillator.type = 'sine';
        oscillator.frequency.setValueAtTime(500, audioCtx.currentTime);
      }
      
      gainNode.gain.setValueAtTime(0.1, audioCtx.currentTime);
      gainNode.gain.exponentialRampToValueAtTime(0.01, audioCtx.currentTime + 0.2);
      
      oscillator.start(audioCtx.currentTime);
      oscillator.stop(audioCtx.currentTime + 0.2);
    } catch (e) {
      console.log('Audio play failed', e);
    }
  };

  const fetchNotifications = async () => {
    if (!currentUser) return;
    try {
      const res = await fetch(`${API_URL}/notifications?userId=${currentUser.id}&_t=${Date.now()}`);
      const data = await res.json();
      setNotifications(data);
    } catch (error) {
      console.error('Failed to fetch notifications', error);
    }
  };

  // Initialize Socket.io - Persistent Connection
  useEffect(() => {
    socket = io();

    socket.on('connect', () => {
      console.log('Connected to WebSocket');
      setIsConnected(true);
    });

    socket.on('disconnect', () => {
      console.log('Disconnected from WebSocket');
      setIsConnected(false);
    });

    return () => {
      socket.disconnect();
    };
  }, []);

  // Handle User Room Joining
  useEffect(() => {
    if (currentUser) {
      socket.emit('join', currentUser.id);
    }
  }, [currentUser]);

  // Attach Event Listeners - Re-attach when dependencies change to ensure fresh closures
  useEffect(() => {
    if (!socket) return;

    const handleNotification = (notif: Notification) => {
      playNotificationSound(notif.type);
      
      // Add to state if it belongs to current user or is global
      if (notif.userId === currentUser?.id || notif.userId === 'ALL') {
         setNotifications(prev => [notif, ...prev]);

         // Show enhanced toast
         const toastId = Math.random().toString(36).substr(2, 9);
         const toast: Toast = {
           id: toastId,
           message: notif.message,
           type: notif.type as any || 'info',
           action: notif.docId ? {
             label: 'بینین',
             onClick: () => {
                window.dispatchEvent(new CustomEvent('NAVIGATE_TO_DOC', { detail: notif.docId }));
                removeToast(toastId);
             }
           } : undefined
         };
         setToasts(prev => [...prev, toast]);
         setTimeout(() => removeToast(toastId), 8000);
      }
    };

    const handleNewMessage = (data: { chatId: string, message: Message }) => {
        // Update chat list last message or trigger re-fetch
        fetchChats();
        if (currentUser && data.message.senderId !== currentUser.id) {
            showToast(`New message from ${users.find(u => u.id === data.message.senderId)?.name || 'User'}`, 'info');
        }
    };

    // Attach listeners
    socket.on('users:update', fetchUsers);
    socket.on('departments:update', fetchDepartments);
    socket.on('documents:update', fetchDocuments);
    socket.on('workflowTemplates:update', fetchWorkflowTemplates);
    socket.on('handDelivery:update', fetchHandDeliveryRecords);
    socket.on('chats:update', fetchChats);
    socket.on('activityLogs:update', fetchActivityLogs);
    socket.on('toDoItems:update', fetchToDoItems);
    socket.on('notification', handleNotification);
    socket.on('message:new', handleNewMessage);

    // Cleanup listeners
    return () => {
      socket.off('users:update', fetchUsers);
      socket.off('departments:update', fetchDepartments);
      socket.off('documents:update', fetchDocuments);
      socket.off('workflowTemplates:update', fetchWorkflowTemplates);
      socket.off('handDelivery:update', fetchHandDeliveryRecords);
      socket.off('chats:update', fetchChats);
      socket.off('activityLogs:update', fetchActivityLogs);
      socket.off('toDoItems:update', fetchToDoItems);
      socket.off('notification', handleNotification);
      socket.off('message:new', handleNewMessage);
    };
  }, [currentUser, users]); // Re-run when currentUser or users change to update closures

  // Fetch Initial Data
  useEffect(() => {
    fetchUsers();
    fetchDepartments();
    fetchWorkflowTemplates();
    fetchHandDeliveryRecords();
    fetchActivityLogs();
  }, []);

  useEffect(() => {
      if (currentUser) {
          fetchDocuments();
          fetchChats();
          fetchHandDeliveryRecords();
          fetchToDoItems();
          fetchNotifications();
          socket.emit('join', currentUser.id);
      }
  }, [currentUser]);

  const fetchUsers = async () => {
    try {
      const res = await fetch(`${API_URL}/users?_t=${Date.now()}`);
      const data = await res.json();
      setUsers(data);
    } catch (error) {
      console.error('Failed to fetch users', error);
    }
  };

  const fetchHandDeliveryRecords = async () => {
    try {
      const res = await fetch(`${API_URL}/hand-delivery?_t=${Date.now()}`);
      const data = await res.json();
      setHandDeliveryRecords(data);
    } catch (error) {
      console.error('Failed to fetch hand delivery records', error);
    }
  };

  const fetchDepartments = async () => {
    try {
      const res = await fetch(`${API_URL}/departments?_t=${Date.now()}`);
      const data = await res.json();
      setDepartments(data);
    } catch (error) {
      console.error('Failed to fetch departments', error);
    }
  };

  const fetchWorkflowTemplates = async () => {
    try {
      const res = await fetch(`${API_URL}/workflow-templates?_t=${Date.now()}`);
      const data = await res.json();
      setWorkflowTemplates(data);
    } catch (error) {
      console.error('Failed to fetch workflow templates', error);
    }
  };

  const fetchActivityLogs = async () => {
    try {
      const res = await fetch(`${API_URL}/activity-logs?_t=${Date.now()}`);
      const data = await res.json();
      setActivityLogs(data);
    } catch (error) {
      console.error('Failed to fetch activity logs', error);
    }
  };

  const fetchToDoItems = async () => {
    if (!currentUser) return;
    try {
      const res = await fetch(`${API_URL}/todos?userId=${currentUser.id}&_t=${Date.now()}`);
      const data = await res.json();
      setToDoItems(data);
    } catch (error) {
      console.error('Failed to fetch todo items', error);
    }
  };

  const fetchDocuments = async () => {
    if (!currentUser) return;
    try {
      const res = await fetch(`${API_URL}/documents?userId=${currentUser.id}&role=${currentUser.role}&department=${currentUser.department}&_t=${Date.now()}`);
      const data = await res.json();
      setDocuments(data);
    } catch (error) {
      console.error('Failed to fetch documents', error);
    }
  };

  const fetchChats = async () => {
      if (!currentUser) return;
      try {
          const res = await fetch(`${API_URL}/chats?userId=${currentUser.id}&_t=${Date.now()}`);
          const data = await res.json();
          setChats(data);
      } catch (error) {
          console.error('Failed to fetch chats', error);
      }
  };

  const showToast = React.useCallback((message: string, type: 'success' | 'error' | 'warning' | 'info') => {
    const id = Math.random().toString(36).substr(2, 9);
    setToasts(prev => [...prev, { id, message, type }]);
    setTimeout(() => removeToast(id), 5000);
  }, []);

  const removeToast = React.useCallback((id: string) => {
    setToasts(prev => prev.filter(t => t.id !== id));
  }, []);

  // --- Auth ---
  const login = React.useCallback(async (username: string, password?: string): Promise<boolean> => {
    try {
      const res = await fetch(`${API_URL}/auth/login`, {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ username, password }),
      });
      
      const data = await res.json();
      
      if (res.ok && data.success) {
        setCurrentUser(data.user);
        showToast(`بەخێربێیت ${data.user.name}`, 'success');
        return true;
      } else {
        showToast(data.error || 'هەڵە لە چوونەژوورەوە', 'error');
        return false;
      }
    } catch (error) {
      console.error('Login failed', error);
      showToast('هەڵەیەک ڕوویدا', 'error');
      return false;
    }
  }, [showToast]);

  const logout = React.useCallback(() => {
    setCurrentUser(null);
    setDocuments([]);
    setChats([]);
    setNotifications([]);
    setToDoItems([]);
  }, []);

  // --- ToDo ---
  const addToDo = React.useCallback(async (text: string) => {
    if (!currentUser) return;
    try {
      await fetch(`${API_URL}/todos`, {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ userId: currentUser.id, text }),
      });
    } catch (error) {
      console.error('Failed to add todo', error);
      showToast('هەڵە لە زیادکردنی کار', 'error');
    }
  }, [currentUser, showToast]);

  const toggleToDo = React.useCallback(async (id: string) => {
    try {
      await fetch(`${API_URL}/todos/${id}/toggle`, { method: 'POST' });
    } catch (error) {
      console.error('Failed to toggle todo', error);
    }
  }, []);

  const deleteToDo = React.useCallback(async (id: string) => {
    try {
      await fetch(`${API_URL}/todos/${id}`, { method: 'DELETE' });
    } catch (error) {
      console.error('Failed to delete todo', error);
    }
  }, []);

  // --- Documents ---
  const createDocument = React.useCallback(async (
    title: string, 
    content: string, 
    targetId: string, 
    attachments: Attachment[], 
    priority: Priority, 
    confidentiality: Confidentiality, 
    isCircular?: boolean,
    incomingNumber?: string,
    incomingDate?: string,
    source?: string,
    relatedDocIds?: string[],
    workflowTemplateId?: string,
    initialWorkflowStage?: string,
    type: 'official' | 'request' = 'official',
    deadline?: string,
    relatedRoomName?: string
  ) => {
    if (!currentUser) return;

    const newDoc = {
      title,
      content,
      senderId: currentUser.id,
      senderName: currentUser.name,
      senderDepartment: currentUser.department,
      currentHolderId: targetId,
      status: 'Pending',
      priority,
      confidentiality,
      deadline: deadline || calculateWorkingDeadline(3), // Use provided deadline or default 3 working days
      attachments,
      isCircular,
      workflowStage: initialWorkflowStage || 'DISPATCH',
      workflowTemplateId,
      currentStepIndex: 0,
      incomingNumber,
      incomingDate,
      source,
      relatedDocIds,
      relatedRoomName,
      type,
      comments: []
    };

    try {
      await fetch(`${API_URL}/documents`, {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify(newDoc),
      });
      showToast('نوسراوەکە بە سەرکەوتوویی نێردرا', 'success');
      playNotificationSound('success');
      // Optimistic update or wait for socket
    } catch (error) {
      console.error('Failed to create document', error);
      showToast('هەڵە لە دروستکردنی نوسراو', 'error');
    }
  }, [currentUser, showToast]);

  const addComment = React.useCallback(async (docId: string, content: string) => {
    if (!currentUser) return;
    try {
      await fetch(`${API_URL}/documents/${docId}/comments`, {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          userId: currentUser.id,
          userName: currentUser.name,
          userRole: currentUser.role,
          content
        }),
      });
      showToast('کۆمێنت بە سەرکەوتوویی زیادکرا', 'success');
      playNotificationSound('success');
    } catch (error) {
      console.error('Failed to add comment', error);
      showToast('هەڵە لە زیادکردنی کۆمێنت', 'error');
    }
  }, [currentUser, showToast]);

  const updateDocument = React.useCallback(async (docId: string, updates: any) => {
    try {
      await fetch(`${API_URL}/documents/${docId}`, {
        method: 'PUT',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify(updates),
      });
      showToast('نوسراوەکە بە سەرکەوتوویی نوێکرایەوە', 'success');
      playNotificationSound('success');
    } catch (error) {
      console.error('Failed to update document', error);
      showToast('هەڵە لە نوێکردنەوەی نوسراو', 'error');
    }
  }, [showToast]);

  const handDeliverDocument = React.useCallback(async (docId: string, record: HandDeliveryRecord) => {
    try {
      await fetch(`${API_URL}/hand-delivery`, {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify(record),
      });
      showToast('نوسراو بە سەرکەوتوویی ڕادەستکرا', 'success');
      playNotificationSound('success');
    } catch (error) {
      console.error('Failed to hand deliver document', error);
      showToast('هەڵە لە ڕادەستکردنی نوسراو', 'error');
    }
  }, [showToast]);

  const addDepartment = React.useCallback(async (dept: Department) => {
    try {
      await fetch(`${API_URL}/departments`, {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify(dept),
      });
    } catch (error) {
      console.error('Failed to add department', error);
      showToast('هەڵە لە زیادکردنی ژوور', 'error');
    }
  }, [showToast]);

  const updateDepartment = React.useCallback(async (dept: Department) => {
    try {
      await fetch(`${API_URL}/departments/${dept.id}`, {
        method: 'PUT',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify(dept),
      });
    } catch (error) {
      console.error('Failed to update department', error);
      showToast('هەڵە لە نوێکردنەوەی ژوور', 'error');
    }
  }, [showToast]);

  const addWorkflowTemplate = React.useCallback(async (template: WorkflowTemplate) => {
    try {
      await fetch(`${API_URL}/workflow-templates`, {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify(template),
      });
    } catch (error) {
      console.error('Failed to add workflow template', error);
      showToast('هەڵە لە زیادکردنی ڕەوتی کار', 'error');
    }
  }, [showToast]);

  const updateWorkflowTemplate = React.useCallback(async (template: WorkflowTemplate) => {
    try {
      await fetch(`${API_URL}/workflow-templates/${template.id}`, {
        method: 'PUT',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify(template),
      });
    } catch (error) {
      console.error('Failed to update workflow template', error);
      showToast('هەڵە لە نوێکردنەوەی ڕەوتی کار', 'error');
    }
  }, [showToast]);

  const deleteWorkflowTemplate = React.useCallback(async (id: string) => {
    try {
      await fetch(`${API_URL}/workflow-templates/${id}`, {
        method: 'DELETE',
      });
    } catch (error) {
      console.error('Failed to delete workflow template', error);
      showToast('هەڵە لە سڕینەوەی ڕەوتی کار', 'error');
    }
  }, [showToast]);

  const addUser = React.useCallback(async (user: Omit<User, 'id' | 'isLocked'>) => {
    try {
      const res = await fetch(`${API_URL}/users`, {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify(user),
      });
      if (!res.ok) {
        const data = await res.json();
        throw new Error(data.error || 'Failed to add user');
      }
      showToast('بەکارهێنەر بە سەرکەوتوویی زیادکرا', 'success');
    } catch (error) {
      console.error('Failed to add user', error);
      showToast((error as Error).message || 'هەڵە لە زیادکردنی بەکارهێنەر', 'error');
    }
  }, [showToast]);

  const updateUser = React.useCallback(async (id: string, user: Partial<User>) => {
    try {
      const res = await fetch(`${API_URL}/users/${id}`, {
        method: 'PUT',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify(user),
      });
      if (!res.ok) {
        const data = await res.json();
        throw new Error(data.error || 'Failed to update user');
      }
      showToast('بەکارهێنەر بە سەرکەوتوویی نوێکرایەوە', 'success');
    } catch (error) {
      console.error('Failed to update user', error);
      showToast((error as Error).message || 'هەڵە لە نوێکردنەوەی بەکارهێنەر', 'error');
    }
  }, [showToast]);

  const deleteUser = React.useCallback(async (id: string) => {
    try {
      await fetch(`${API_URL}/users/${id}`, {
        method: 'DELETE',
      });
      showToast('بەکارهێنەر بە سەرکەوتوویی سڕایەوە', 'success');
    } catch (error) {
      console.error('Failed to delete user', error);
      showToast('هەڵە لە سڕینەوەی بەکارهێنەر', 'error');
    }
  }, [showToast]);

  const toggleUserLock = React.useCallback(async (id: string) => {
    try {
      await fetch(`${API_URL}/users/${id}/toggle-lock`, {
        method: 'POST',
      });
    } catch (error) {
      console.error('Failed to toggle user lock', error);
    }
  }, []);

  const deleteDepartment = React.useCallback(async (id: string) => {
    try {
      await fetch(`${API_URL}/departments/${id}`, {
        method: 'DELETE',
      });
      showToast('ژوور بە سەرکەوتوویی سڕایەوە', 'success');
    } catch (error) {
      console.error('Failed to delete department', error);
      showToast('هەڵە لە سڕینەوەی ژوور', 'error');
    }
  }, [showToast]);

  const markNotificationAsRead = React.useCallback(async (id: string) => {
    try {
      await fetch(`${API_URL}/notifications/${id}/read`, { method: 'POST' });
      setNotifications(prev => prev.map(n => n.id === id ? { ...n, read: true } : n));
    } catch (error) {
      console.error('Failed to mark notification as read', error);
    }
  }, []);

  const restoreSystem = React.useCallback(async (file: File) => {
    const formData = new FormData();
    formData.append('backup', file);

    try {
      const res = await fetch(`${API_URL}/restore`, {
        method: 'POST',
        body: formData,
      });
      if (!res.ok) throw new Error('Restore failed');
      showToast('سیستەم بە سەرکەوتوویی گەڕێندرایەوە', 'success');
      // Refresh all data
      fetchUsers();
      fetchDepartments();
      fetchDocuments();
      fetchWorkflowTemplates();
      fetchChats();
    } catch (error) {
      console.error('Failed to restore system', error);
      showToast('هەڵە لە گەڕاندنەوەی سیستەم', 'error');
    }
  }, [showToast]);

  const backupSystem = React.useCallback(async () => {
    try {
      const res = await fetch(`${API_URL}/backup`);
      if (!res.ok) throw new Error('Backup failed');
      
      const blob = await res.blob();
      const url = window.URL.createObjectURL(blob);
      const a = document.createElement('a');
      a.href = url;
      a.download = `backup-${new Date().toISOString().split('T')[0]}.zip`;
      document.body.appendChild(a);
      a.click();
      window.URL.revokeObjectURL(url);
      document.body.removeChild(a);
      
      showToast('پاشەکەوت بە سەرکەوتوویی ئەنجامدرا', 'success');
    } catch (error) {
      console.error('Failed to backup system', error);
      showToast('هەڵە لە پاشەکەوتکردنی سیستەم', 'error');
    }
  }, [showToast]);

  const createChat = React.useCallback(async (type: 'direct' | 'group', participants: string[], name?: string) => {
    try {
      const res = await fetch(`${API_URL}/chats`, {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ type, name, participants }),
      });
      const data = await res.json();
      return data.id;
    } catch (error) {
      console.error('Failed to create chat', error);
      return null;
    }
  }, []);

  const sendMessage = React.useCallback(async (chatId: string, content: string, type: 'text' | 'file' | 'voice' = 'text', fileUrl?: string) => {
    if (!currentUser) return;
    try {
      const res = await fetch(`${API_URL}/messages`, {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ chatId, senderId: currentUser.id, content, type, fileUrl }),
      });
      if (!res.ok) throw new Error('Failed to send message');
    } catch (error) {
      console.error('Failed to send message', error);
      showToast('هەڵە لە ناردنی نامە', 'error');
    }
  }, [currentUser, showToast]);

  const getChatMessages = React.useCallback(async (chatId: string) => {
    try {
      const res = await fetch(`${API_URL}/chats/${chatId}/messages?_t=${Date.now()}`);
      if (!res.ok) throw new Error('Failed to fetch messages');
      return await res.json();
    } catch (error) {
      console.error('Failed to get messages', error);
      showToast('هەڵە لە هێنانی نامەکان', 'error');
      return [];
    }
  }, [showToast]);

  const uploadFiles = React.useCallback(async (files: File[]) => {
    if (!files || files.length === 0) {
      return [];
    }

    const formData = new FormData();
    files.forEach(file => formData.append('files', file));

    try {
      const res = await fetch(`${API_URL}/upload`, {
        method: 'POST',
        body: formData,
      });
      
      if (!res.ok) throw new Error('Upload failed');
      
      const uploadedFiles = await res.json();
      return uploadedFiles.map((f: any) => ({
        id: f.id,
        documentId: '',
        name: f.name,
        type: f.type,
        url: f.url, // Use the URL returned by the server (e.g., /uploads/filename)
        uploadedBy: currentUser?.name || 'Unknown',
        uploadedAt: new Date().toISOString()
      }));
    } catch (error) {
      console.error('Failed to upload files', error);
      showToast('هەڵە لە بەرزکردنەوەی فایل', 'error');
      return [];
    }
  }, [currentUser, showToast]);

  const refreshData = React.useCallback(() => {
    fetchUsers();
    fetchDepartments();
    fetchDocuments();
  }, []);

  const getVisibleDocuments = React.useCallback(() => {
    if (!currentUser) return [];
    
    // Roles that can see ALL documents
    const allAccessRoles = ['super_admin', 'dispatch_staff'];
    
    return documents.filter(doc => {
      const isParticipant = 
        doc.currentHolderId === currentUser.id || 
        doc.senderId === currentUser.id ||
        doc.participants?.includes(currentUser.id) ||
        doc.participants?.includes(currentUser.department);

      // Requests are strictly private to participants
      if (doc.type === 'request') {
        return isParticipant;
      }

      // For official documents, allAccessRoles see everything
      if (allAccessRoles.includes(currentUser.role)) {
        return true;
      }

      // Others see official documents they participated in, or circulars
      return isParticipant || doc.isCircular;
    });
  }, [documents, currentUser]);

  return (
    <AppContext.Provider value={{
      currentUser,
      isConnected,
      users,
      departments,
      documents,
      chats,
      notifications,
      toasts,
      workflowTemplates,
      handDeliveryRecords,
      activityLogs,
      toDoItems,
      login,
      logout,
      createDocument,
      updateDocument,
      handDeliverDocument,
      addDepartment,
      updateDepartment,
      addWorkflowTemplate,
      updateWorkflowTemplate,
      deleteWorkflowTemplate,
      addUser,
      updateUser,
      deleteUser,
      toggleUserLock,
      deleteDepartment,
      markNotificationAsRead,
      createChat,
      sendMessage,
      backupSystem,
      restoreSystem,
      addToDo,
      toggleToDo,
      deleteToDo,
      getChatMessages,
      showToast,
      removeToast,
      uploadFiles,
      refreshData,
      getVisibleDocuments
    }}>
      {children}
    </AppContext.Provider>
  );
};

export const useApp = () => {
  const context = useContext(AppContext);
  if (!context) throw new Error('useApp must be used within AppProvider');
  return context;
};
