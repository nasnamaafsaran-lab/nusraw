import { Role, WorkflowStage, DocumentStatus, Priority } from './types';

export const translations = {
  role: {
    super_admin: 'بەڕێوەبەری سیستەم',
    director_general: 'بەڕێوەبەری گشتی',
    deputy_director: 'جێگری بەڕێوەبەر',
    staff_officer: 'ئەفسەری ستاف',
    office_manager: 'بەڕێوەبەری نووسینگە',
    section_director: 'بەڕێوەبەری بەش',
    unit_head: 'بەڕێوەبەری هۆبە',
    employee: 'کارمەند',
    dispatch_staff: 'کارمەندی ناردن',
    print_staff: 'کارمەندی پڕێنت',
    control_room: 'ژووری کۆنترۆڵ',
  },
  days: {
    Sunday: 'یەکشەممە',
    Monday: 'دووشەممە',
    Tuesday: 'سێشەممە',
    Wednesday: 'چوارشەممە',
    Thursday: 'پێنجشەممە',
    Friday: 'هەینی',
    Saturday: 'شەممە',
  }
};

export const getRoleLabel = (role: Role | string): string => {
  return (translations.role as any)[role] || role;
};

export const getActionLabel = (action: string): string => {
  const actions: Record<string, string> = {
    create: 'دروستکردن',
    forward: 'ناردن',
    manual_forward: 'ناردنی دەستی',
    approve: 'پەسەندکردن',
    reject: 'ڕەتکردنەوە',
    return: 'گەڕاندنەوە',
    archive: 'ئەرشیفکردن',
    edit: 'دەستکاریکردن',
    read: 'خوێندنەوە',
    comment: 'لێدوان',
    approved: 'پەسەندکراو',
    rejected: 'ڕەتکراوە',
    returned: 'گەڕێندراوە',
  };
  return actions[action] || action;
};

export const getStatusLabel = (status: DocumentStatus | string): string => {
  const statuses: Record<string, string> = {
    'Pending': 'چاوەڕوان',
    'Under Review': 'لە پێداچوونەوەدایە',
    'Approved': 'پەسەندکراو',
    'Rejected': 'ڕەتکراوە',
    'Archived': 'ئەرشیفکراو',
  };
  return statuses[status as string] || status;
};

export const getWorkflowStageLabel = (stage: WorkflowStage | string): string => {
  const stages: Record<string, string> = {
    'DISPATCH': 'بەشی ناردن',
    'DEPT_HEAD_IN': 'بەڕێوەبەری بەش',
    'UNIT_HEAD_IN': 'بەڕێوەبەری هۆبە',
    'EMPLOYEE_ACTION': 'کارمەند',
    'UNIT_HEAD_OUT': 'بەڕێوەبەری هۆبە',
    'DEPT_HEAD_OUT': 'بەڕێوەبەری بەش',
    'DEPUTY_REVIEW': 'جێگری بەڕێوەبەر',
    'DIRECTOR_REVIEW': 'بەڕێوەبەری گشتی',
    'PRINT_ROOM': 'بەشی پڕێنت',
    'ARCHIVED': 'ئەرشیف',
  };
  return stages[stage as string] || stage;
};

export const getPriorityLabel = (priority: Priority | string): string => {
  const priorities: Record<string, string> = {
    'Normal': 'ئاسایی',
    'Urgent': 'بەپەلە',
    'Top Secret': 'زۆر نهێنی',
  };
  return priorities[priority as string] || priority;
};
