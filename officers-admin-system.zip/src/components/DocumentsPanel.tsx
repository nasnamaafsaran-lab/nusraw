import React, { useState } from 'react';
import { useApp } from '../context';
import { 
  FileText, Search, Filter, Clock, CheckCircle2, XCircle, 
  AlertTriangle, ArrowRight, User, Building2, Layers, 
  Activity, Archive, ChevronRight, MessageSquare, Paperclip,
  Share2, Plus
} from 'lucide-react';
import { Document } from '../types';
import { getWorkflowStageLabel, getPriorityLabel, getStatusLabel } from '../translations';

interface DocumentsPanelProps {
  onViewDoc: (doc: Document) => void;
}

export const DocumentsPanel: React.FC<DocumentsPanelProps> = ({ onViewDoc }) => {
  const { getVisibleDocuments, currentUser, departments, workflowTemplates, users } = useApp();
  const [searchQuery, setSearchQuery] = useState('');
  const [activeWorkflowStep, setActiveWorkflowStep] = useState<string | null>(null);
  const [statusFilter, setStatusFilter] = useState<string>('inbox');

  const allDocs = getVisibleDocuments();

  const getStepLabel = (doc: Document) => {
    const currentHolder = users.find(u => u.id === doc.currentHolderId);
    const currentDept = departments.find(d => d.id === currentHolder?.department);
    
    if (doc.workflowTemplateId) {
      const template = workflowTemplates.find(t => t.id === doc.workflowTemplateId);
      if (template && template.steps[doc.currentStepIndex]) {
        return {
          templateName: template.name,
          stepLabel: template.steps[doc.currentStepIndex].label,
          deptName: currentDept?.name
        };
      }
    }
    
    return {
      templateName: null,
      stepLabel: getWorkflowStageLabel(doc.workflowStage),
      deptName: currentDept?.name
    };
  };

  // Filter and Sort: Newest first
  const filteredDocs = allDocs
    .filter(doc => {
      const matchesSearch = 
        doc.title.toLowerCase().includes(searchQuery.toLowerCase()) ||
        doc.senderName.toLowerCase().includes(searchQuery.toLowerCase()) ||
        doc.referenceNumber.toLowerCase().includes(searchQuery.toLowerCase());
      
      const matchesWorkflow = activeWorkflowStep ? doc.workflowStage === activeWorkflowStep : true;
      
      let matchesStatus = true;
      if (statusFilter === 'inbox') {
        matchesStatus = doc.currentHolderId === currentUser?.id && doc.status !== 'Archived';
      } else if (statusFilter === 'processed') {
        matchesStatus = (doc.participants?.includes(currentUser?.id || '') || doc.senderId === currentUser?.id) && doc.currentHolderId !== currentUser?.id;
      } else if (statusFilter === 'Pending') {
        matchesStatus = doc.status === 'Pending' || doc.status === 'Under Review';
      } else if (statusFilter !== 'all') {
        matchesStatus = doc.status === statusFilter;
      }

      return matchesSearch && matchesWorkflow && matchesStatus;
    })
    .sort((a, b) => new Date(b.createdAt).getTime() - new Date(a.createdAt).getTime());

  const workflowSteps = [
    { id: 'DISPATCH', label: 'بەشی نوسراو', count: allDocs.filter(d => d.workflowStage === 'DISPATCH').length, icon: FileText },
    { id: 'DEPT_HEAD_IN', label: 'بەڕێوەبەری بەش', count: allDocs.filter(d => d.workflowStage === 'DEPT_HEAD_IN').length, icon: User },
    { id: 'UNIT_HEAD_IN', label: 'بەڕێوەبەری هۆبە', count: allDocs.filter(d => d.workflowStage === 'UNIT_HEAD_IN').length, icon: Building2 },
    { id: 'EMPLOYEE_ACTION', label: 'کارمەندی هۆبە', count: allDocs.filter(d => d.workflowStage === 'EMPLOYEE_ACTION').length, icon: User },
    { id: 'UNIT_HEAD_OUT', label: 'بەڕێوەبەری هۆبە', count: allDocs.filter(d => d.workflowStage === 'UNIT_HEAD_OUT').length, icon: CheckCircle2 },
    { id: 'DEPT_HEAD_OUT', label: 'بەڕێوەبەری بەش', count: allDocs.filter(d => d.workflowStage === 'DEPT_HEAD_OUT').length, icon: CheckCircle2 },
    { id: 'DEPUTY_REVIEW', label: 'جێگری بەڕێوەبەر', count: allDocs.filter(d => d.workflowStage === 'DEPUTY_REVIEW').length, icon: Building2 },
    { id: 'DIRECTOR_REVIEW', label: 'بەڕێوەبەری گشتی', count: allDocs.filter(d => d.workflowStage === 'DIRECTOR_REVIEW').length, icon: Building2 },
    { id: 'ARCHIVED', label: 'ئەرشیف', count: allDocs.filter(d => d.workflowStage === 'ARCHIVED').length, icon: Archive },
  ];

  return (
    <div className="space-y-6 animate-in fade-in duration-500" dir="rtl">
      {/* Header Section */}
      <div className="flex flex-col md:flex-row justify-between items-start md:items-center gap-4">
        <div>
          <h2 className="text-3xl font-black text-white neon-text">نوسراوەکان</h2>
          <p className="text-slate-500 text-sm mt-1 font-medium">هەموو نوسراوەکانی سیستەم</p>
        </div>
        <div className="flex gap-3">
          <button className="relative group flex items-center gap-2 px-6 py-3 bg-white/5 hover:bg-white/10 border border-white/10 rounded-2xl text-slate-300 hover:text-white transition-all text-sm font-bold backdrop-blur-md overflow-hidden hover:shadow-[0_0_20px_rgba(255,255,255,0.1)]">
            <div className="absolute inset-0 bg-gradient-to-r from-transparent via-white/10 to-transparent translate-x-[-100%] group-hover:translate-x-[100%] transition-transform duration-1000" />
            <Share2 size={18} className="rotate-180 group-hover:scale-110 transition-transform" />
            <span className="relative z-10">ئێکسپۆرت</span>
          </button>
          <button className="relative group flex items-center gap-2 px-8 py-3 bg-gradient-to-r from-blue-600 to-indigo-600 hover:from-blue-500 hover:to-indigo-500 text-white rounded-2xl font-bold shadow-[0_10px_20px_rgba(37,99,235,0.3)] hover:shadow-[0_15px_30px_rgba(37,99,235,0.4)] transition-all hover:-translate-y-1 border border-white/20 overflow-hidden">
            <div className="absolute inset-0 bg-gradient-to-r from-transparent via-white/20 to-transparent translate-x-[-100%] group-hover:translate-x-[100%] transition-transform duration-1000" />
            <Plus size={20} className="group-hover:rotate-90 transition-transform duration-300" />
            <span className="relative z-10">نوسراوی نوێ</span>
          </button>
        </div>
      </div>

      {/* Tabs / Filters */}
      <div className="flex flex-wrap items-center gap-4 p-4 bg-white/5 rounded-[2rem] border border-white/10 backdrop-blur-md w-fit mx-auto md:mx-0">
        {[
          { id: 'inbox', label: 'بۆ من', count: allDocs.filter(d => d.currentHolderId === currentUser?.id && d.status !== 'Archived').length, gradient: 'from-blue-600 to-indigo-500', shadow: 'shadow-blue-500/40', icon: User },
          { id: 'processed', label: 'کارپێکراو', count: allDocs.filter(d => d.participants?.includes(currentUser?.id || '') && d.currentHolderId !== currentUser?.id).length, gradient: 'from-violet-600 to-purple-500', shadow: 'shadow-purple-500/40', icon: CheckCircle2 },
          { id: 'all', label: 'هەموو', count: allDocs.length, gradient: 'from-slate-600 to-slate-500', shadow: 'shadow-slate-500/40', icon: Layers },
          { id: 'Pending', label: 'لە کاردایە', count: allDocs.filter(d => d.status === 'Pending' || d.status === 'Under Review').length, gradient: 'from-amber-500 to-orange-500', shadow: 'shadow-orange-500/40', icon: Clock },
          { id: 'Approved', label: 'پەسەندکراو', count: allDocs.filter(d => d.status === 'Approved').length, gradient: 'from-emerald-600 to-teal-500', shadow: 'shadow-emerald-500/40', icon: CheckCircle2 },
          { id: 'Rejected', label: 'ڕەتکراو', count: allDocs.filter(d => d.status === 'Rejected').length, gradient: 'from-red-600 to-rose-500', shadow: 'shadow-red-500/40', icon: XCircle },
          { id: 'Archived', label: 'ئەرشیف', count: allDocs.filter(d => d.status === 'Archived').length, gradient: 'from-cyan-600 to-sky-500', shadow: 'shadow-cyan-500/40', icon: Archive },
        ].map((tab) => (
          <button
            key={tab.id}
            onClick={() => setStatusFilter(tab.id)}
            className={`relative px-6 py-4 rounded-2xl text-sm font-bold transition-all duration-500 flex items-center gap-3 overflow-hidden group shadow-lg ${
              statusFilter === tab.id 
                ? `bg-gradient-to-r ${tab.gradient} text-white ${tab.shadow} scale-110 ring-2 ring-white/30 -translate-y-1` 
                : `bg-gradient-to-r ${tab.gradient} text-white/90 opacity-80 hover:opacity-100 hover:scale-105 hover:-translate-y-0.5 hover:shadow-xl`
            }`}
          >
            <div className={`absolute inset-0 bg-gradient-to-r from-transparent via-white/30 to-transparent translate-x-[-100%] group-hover:translate-x-[100%] transition-transform duration-1000`} />
            <tab.icon size={20} className={`transition-transform duration-300 ${statusFilter === tab.id ? 'scale-125' : 'group-hover:scale-110'}`} />
            <div className="flex flex-col items-start">
              <span className="relative z-10 text-xs opacity-90 font-medium uppercase tracking-wider">{tab.label}</span>
              <span className="relative z-10 text-lg font-black">{tab.count}</span>
            </div>
          </button>
        ))}
      </div>

      {/* Table UI */}
      <div className="glass-panel rounded-3xl border border-white/10 overflow-hidden shadow-2xl">
        <div className="overflow-x-auto custom-scrollbar">
          <table className="w-full text-right border-collapse">
            <thead>
              <tr className="bg-white/5 border-b border-white/10">
                <th className="px-6 py-4 text-[11px] font-black text-slate-500 uppercase tracking-widest">ژمارەی نوسراو</th>
                <th className="px-6 py-4 text-[11px] font-black text-slate-500 uppercase tracking-widest">بابەتی نوسراو</th>
                <th className="px-6 py-4 text-[11px] font-black text-slate-500 uppercase tracking-widest">ناوەڕۆک</th>
                <th className="px-6 py-4 text-[11px] font-black text-slate-500 uppercase tracking-widest">لە کوێ هاتووە</th>
                <th className="px-6 py-4 text-[11px] font-black text-slate-500 uppercase tracking-widest">ژووری پەیوەندیدار</th>
                <th className="px-6 py-4 text-[11px] font-black text-slate-500 uppercase tracking-widest">ئاست</th>
                <th className="px-6 py-4 text-[11px] font-black text-slate-500 uppercase tracking-widest">نهێنی بوون</th>
                <th className="px-6 py-4 text-[11px] font-black text-slate-500 uppercase tracking-widest">بەرواری نوسراو</th>
                <th className="px-6 py-4 text-[11px] font-black text-slate-500 uppercase tracking-widest">بەرواری ناردن</th>
                <th className="px-6 py-4 text-[11px] font-black text-slate-500 uppercase tracking-widest">شوێنی ئێستا</th>
                <th className="px-6 py-4 text-[11px] font-black text-slate-500 uppercase tracking-widest">بینرا</th>
                <th className="px-6 py-4 text-[11px] font-black text-slate-500 uppercase tracking-widest">دۆخ</th>
                <th className="px-6 py-4 text-[11px] font-black text-slate-500 uppercase tracking-widest text-center">کردار</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-white/5">
              {filteredDocs.length === 0 ? (
                <tr>
                  <td colSpan={12} className="px-6 py-20 text-center">
                    <div className="flex flex-col items-center gap-4 opacity-30">
                      <FileText size={48} />
                      <p className="font-bold">هیچ نوسراوێک نییە</p>
                    </div>
                  </td>
                </tr>
              ) : (
                filteredDocs.map((doc) => {
                  const stepInfo = getStepLabel(doc);
                  return (
                    <tr 
                      key={doc.id} 
                      className="group hover:bg-white/5 transition-colors cursor-pointer"
                      onClick={() => onViewDoc(doc)}
                    >
                      <td className="px-6 py-4">
                        <span className="text-xs font-mono text-blue-400/70 font-bold">{doc.incomingNumber || doc.referenceNumber}</span>
                      </td>
                      <td className="px-6 py-4">
                        <div className="flex items-center gap-3">
                          <div className={`w-2 h-2 rounded-full ${
                            doc.priority === 'Urgent' ? 'bg-red-500 shadow-[0_0_8px_rgba(239,68,68,0.6)]' :
                            doc.priority === 'Top Secret' ? 'bg-purple-500 shadow-[0_0_8px_rgba(168,85,247,0.6)]' :
                            'bg-emerald-500 shadow-[0_0_8px_rgba(16,185,129,0.6)]'
                          }`} />
                          <span className="text-sm font-bold text-slate-200 group-hover:text-blue-400 transition-colors">{doc.title}</span>
                        </div>
                      </td>
                      <td className="px-6 py-4">
                        <span className="text-xs text-slate-400 font-medium max-w-[150px] truncate block" title={doc.content}>
                          {doc.content || '---'}
                        </span>
                      </td>
                      <td className="px-6 py-4">
                        <span className="text-xs text-slate-400 font-medium">{doc.source || '---'}</span>
                      </td>
                      <td className="px-6 py-4">
                        <span className="text-xs text-blue-400/80 font-bold">{doc.relatedRoomName || '---'}</span>
                      </td>
                      <td className="px-6 py-4">
                        <span className={`px-3 py-1 rounded-full text-[10px] font-black border ${
                          doc.priority === 'Urgent' ? 'bg-red-500/10 text-red-400 border-red-500/20' :
                          doc.priority === 'Top Secret' ? 'bg-orange-500/10 text-orange-400 border-orange-500/20' :
                          'bg-slate-500/10 text-slate-400 border-white/10'
                        }`}>
                          {getPriorityLabel(doc.priority)}
                        </span>
                      </td>
                      <td className="px-6 py-4">
                        <span className={`px-3 py-1 rounded-full text-[10px] font-black border ${
                          doc.confidentiality === 'Strictly Confidential' ? 'bg-red-500/10 text-red-400 border-red-500/20' :
                          doc.confidentiality === 'Confidential' ? 'bg-orange-500/10 text-orange-400 border-orange-500/20' :
                          'bg-slate-500/10 text-slate-400 border-white/10'
                        }`}>
                          {doc.confidentiality === 'Strictly Confidential' ? 'زۆر نهێنی' : doc.confidentiality === 'Confidential' ? 'نهێنی' : 'ئاسایی'}
                        </span>
                      </td>
                      <td className="px-6 py-4">
                        <span className="text-xs text-slate-400 font-mono">{doc.incomingDate ? new Date(doc.incomingDate).toLocaleDateString('en-GB', { day: '2-digit', month: '2-digit', year: 'numeric' }) : '---'}</span>
                      </td>
                      <td className="px-6 py-4">
                        <span className="text-xs text-slate-400 font-mono">{new Date(doc.createdAt).toLocaleDateString('en-GB', { day: '2-digit', month: '2-digit', year: 'numeric' })}</span>
                      </td>
                      <td className="px-6 py-4">
                        <div className="flex flex-col gap-0.5">
                          <span className="text-[11px] font-bold text-blue-400">{stepInfo.deptName || '---'}</span>
                          <span className="text-[10px] text-slate-500">{stepInfo.stepLabel}</span>
                        </div>
                      </td>
                      <td className="px-6 py-4">
                        <div className="flex items-center gap-1.5 text-[10px] font-bold">
                          {doc.circularReadBy?.length > 0 ? (
                            <span className="text-emerald-400 flex items-center gap-1">
                              <CheckCircle2 size={12} /> بینرا
                            </span>
                          ) : (
                            <span className="text-slate-600">-- نەبینرا</span>
                          )}
                        </div>
                      </td>
                      <td className="px-6 py-4">
                        <span className={`px-3 py-1 rounded-full text-[10px] font-black flex items-center gap-2 w-fit border ${
                          doc.status === 'Approved' ? 'bg-emerald-500/10 text-emerald-400 border-emerald-500/20' :
                          doc.status === 'Rejected' ? 'bg-red-500/10 text-red-400 border-red-500/20' :
                          doc.status === 'Archived' ? 'bg-blue-500/10 text-blue-400 border-blue-500/20' :
                          doc.status === 'Under Review' ? 'bg-purple-500/10 text-purple-400 border-purple-500/20' :
                          'bg-amber-500/10 text-amber-400 border-amber-500/20'
                        }`}>
                          <div className={`w-1.5 h-1.5 rounded-full ${
                             doc.status === 'Approved' ? 'bg-emerald-500' :
                             doc.status === 'Rejected' ? 'bg-red-500' :
                             doc.status === 'Archived' ? 'bg-blue-500' :
                             doc.status === 'Under Review' ? 'bg-purple-500' :
                             'bg-amber-500'
                          }`} />
                          {getStatusLabel(doc.status)}
                        </span>
                      </td>
                      <td className="px-6 py-4 text-center">
                        <button className="px-4 py-1.5 bg-white/5 border border-white/10 rounded-lg text-[10px] font-black text-slate-300 hover:bg-blue-600 hover:text-white hover:border-blue-500 transition-all hover:shadow-[0_0_10px_rgba(59,130,246,0.3)] hover:-translate-y-0.5">
                          وردەکاری
                        </button>
                      </td>
                    </tr>
                  );
                })
              )}
            </tbody>
          </table>
        </div>
      </div>
    </div>
  );
};
