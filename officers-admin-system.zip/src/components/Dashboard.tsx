import React, { useState, useEffect } from 'react';
import { useApp } from '../context';
import { 
  Inbox, FileText, AlertTriangle, Clock, CheckCircle2, XCircle, 
  TrendingUp, Activity, Search, Zap, Archive, Share2, Printer, 
  Building2, ArrowRight, AlertCircle, BarChart2, PieChart as PieChartIcon,
  Cpu, Layers, Users, Shield, Bell, Calendar, ChevronLeft, Plus, Check, Trash2
} from 'lucide-react';
import { Document } from '../types';
import { 
  PieChart, Pie, Cell, Tooltip, ResponsiveContainer, 
  LineChart, Line, XAxis, YAxis, CartesianGrid, 
  BarChart, Bar, AreaChart, Area 
} from 'recharts';
import { getStatusLabel } from '../translations';

interface DashboardProps {
  onViewDoc: (doc: Document) => void;
  onNavigate: (view: string) => void;
}

export const Dashboard: React.FC<DashboardProps> = ({ onViewDoc, onNavigate }) => {
  const { getVisibleDocuments, currentUser, departments, activityLogs, toDoItems, addToDo, toggleToDo, deleteToDo, showToast } = useApp();
  const [searchQuery, setSearchQuery] = useState('');
  const [aiInsight, setAiInsight] = useState('');
  const [newToDo, setNewToDo] = useState('');
  
  const allDocs = React.useMemo(() => getVisibleDocuments(), [getVisibleDocuments]);

  // Stats Calculation
  const { pending, approved, rejected, archived, circulars } = React.useMemo(() => {
    return {
      pending: allDocs.filter(doc => (doc.status === 'Pending' || doc.status === 'Under Review') && !doc.isCircular),
      approved: allDocs.filter(doc => doc.status === 'Approved' && !doc.isCircular),
      rejected: allDocs.filter(doc => doc.status === 'Rejected' && !doc.isCircular),
      archived: allDocs.filter(doc => doc.status === 'Archived'),
      circulars: allDocs.filter(doc => doc.isCircular)
    };
  }, [allDocs]);

  // SLA Calculation
  const now = React.useMemo(() => new Date(), []);
  
  const overdueDocs = React.useMemo(() => allDocs.filter(doc => {
    if (!doc.deadline) return false;
    if (['Approved', 'Rejected', 'Archived'].includes(doc.status)) return false;
    return new Date(doc.deadline) < now;
  }), [allDocs, now]);

  const recentDocs = React.useMemo(() => [...allDocs].sort((a, b) => new Date(b.createdAt).getTime() - new Date(a.createdAt).getTime()).slice(0, 5), [allDocs]);

  const upcomingDeadlines = React.useMemo(() => allDocs.filter(doc => {
    if (!doc.deadline) return false;
    if (['Approved', 'Rejected', 'Archived'].includes(doc.status)) return false;
    const deadlineDate = new Date(doc.deadline);
    return deadlineDate > now && deadlineDate <= new Date(now.getTime() + 7 * 24 * 60 * 60 * 1000); // Next 7 days
  }).sort((a, b) => {
    const numA = parseInt(a.referenceNumber.replace(/\D/g, '')) || 0;
    const numB = parseInt(b.referenceNumber.replace(/\D/g, '')) || 0;
    if (numA !== numB) return numA - numB;
    return new Date(a.createdAt).getTime() - new Date(b.createdAt).getTime();
  }).slice(0, 5), [allDocs, now]);

  useEffect(() => {
    if (upcomingDeadlines.length > 0) {
      showToast(`ئاگاداربە: ${upcomingDeadlines.length} نوسراو وادەی تەواوبوونیان نزیک بووەتەوە`, 'warning');
    }
  }, [upcomingDeadlines.length, showToast]);

  const storageData = React.useMemo(() => [
    { name: 'پی دی ئێف', value: 45, color: '#3b82f6' },
    { name: 'وێنە', value: 30, color: '#a855f7' },
    { name: 'وۆرد', value: 15, color: '#10b981' },
    { name: 'تر', value: 10, color: '#f59e0b' },
  ], []);

  const handleAddToDo = React.useCallback(async (e: React.FormEvent) => {
    e.preventDefault();
    if (!newToDo.trim()) return;
    await addToDo(newToDo);
    setNewToDo('');
  }, [newToDo, addToDo]);

  // AI Insights Simulation
  useEffect(() => {
    const insights = [
      `${overdueDocs.length} نوسراو کاتیان بەسەرچووە، پێویستە کاریان لەسەر بکرێت.`,
      "خێرایی پەسەندکردن بە ڕێژەی ١٢٪ کەمبووەتەوە لەم هەفتەیەدا.",
      "بەشی میلاکات چالاکترین بەشە لەم مانگەدا.",
      "پێشبینی دەکرێت هەفتەی داهاتوو ٢٠٪ نوسراوی زیاتر بێت.",
      "تکایە ئاگاداربە: ٣ نوسراوی گرنگ لە چاوەڕوانیدان.",
      "AI شیکاری کرد: نوسراوەکانی بەشی دارایی ٥ کاتژمێر خێراتر ڕەوانە دەکرێن.",
      "ئاگاداری: نوسراوی ژمارە ٨٨٢ پێویستی بە واژۆی بەڕێوەبەری گشتییە."
    ];
    
    let currentInsightIndex = 0;
    let charIndex = 0;
    let isDeleting = false;
    let typingSpeed = 50;
    let timeoutId: NodeJS.Timeout;

    const type = () => {
      const currentText = insights[currentInsightIndex];
      
      if (isDeleting) {
        setAiInsight(currentText.substring(0, charIndex - 1));
        charIndex--;
        typingSpeed = 30;
      } else {
        setAiInsight(currentText.substring(0, charIndex + 1));
        charIndex++;
        typingSpeed = 50;
      }

      if (!isDeleting && charIndex === currentText.length) {
        isDeleting = true;
        typingSpeed = 2000; // Pause at end
      } else if (isDeleting && charIndex === 0) {
        isDeleting = false;
        currentInsightIndex = (currentInsightIndex + 1) % insights.length;
        typingSpeed = 500; // Pause before typing next
      }

      timeoutId = setTimeout(type, typingSpeed);
    };

    timeoutId = setTimeout(type, 1000);
    return () => clearTimeout(timeoutId);
  }, [overdueDocs.length]);

  // Chart Data
  const statusData = React.useMemo(() => [
    { name: 'چاوەڕوان', value: pending.length, color: '#f59e0b' },
    { name: 'پەسەندکراو', value: approved.length, color: '#10b981' },
    { name: 'ڕەتکراوە', value: rejected.length, color: '#ef4444' },
    { name: 'ئەرشیف', value: archived.length, color: '#6366f1' },
  ], [pending.length, approved.length, rejected.length, archived.length]);

  const activityData = React.useMemo(() => [
    { name: 'یەکشەممە', documents: 7, prediction: 8 },
    { name: 'دووشەممە', documents: 5, prediction: 6 },
    { name: 'سێشەممە', documents: 12, prediction: 10 },
    { name: 'چوارشەممە', documents: 9, prediction: 11 },
    { name: 'پێنجشەممە', documents: 6, prediction: 7 },
  ], []);

  const workflowSteps = React.useMemo(() => [
    { id: 'DISPATCH', label: 'بەشی نوسراو', count: allDocs.filter(d => d.workflowStage === 'DISPATCH').length, icon: FileText, color: 'blue' },
    { id: 'DEPT_HEAD_IN', label: 'بەڕێوەبەری بەش', count: allDocs.filter(d => d.workflowStage === 'DEPT_HEAD_IN').length, icon: Users, color: 'purple' },
    { id: 'UNIT_HEAD_IN', label: 'بەڕێوەبەری هۆبە', count: allDocs.filter(d => d.workflowStage === 'UNIT_HEAD_IN').length, icon: Building2, color: 'emerald' },
    { id: 'ARCHIVED', label: 'ئەرشیف', count: allDocs.filter(d => d.workflowStage === 'ARCHIVED').length, icon: Archive, color: 'slate' },
  ], [allDocs]);

  // Additional Chart Data
  const departmentActivityData = React.useMemo(() => departments.map(dept => ({
    name: dept.name,
    count: allDocs.filter(d => d.senderDepartment === dept.id).length,
    fill: '#8884d8'
  })).sort((a, b) => b.count - a.count).slice(0, 5), [departments, allDocs]);

  const priorityData = React.useMemo(() => [
    { name: 'ئاسایی', value: allDocs.filter(d => d.priority === 'Normal').length, fill: '#3b82f6' },
    { name: 'بەپەلە', value: allDocs.filter(d => d.priority === 'Urgent').length, fill: '#f59e0b' },
    { name: 'نهێنی', value: allDocs.filter(d => d.priority === 'Top Secret').length, fill: '#ef4444' },
  ], [allDocs]);

  const monthlyTrends = React.useMemo(() => [
    { name: 'کانوونی دووەم', sent: 40, received: 24 },
    { name: 'شوبات', sent: 30, received: 13 },
    { name: 'ئازار', sent: 20, received: 58 },
    { name: 'نیسان', sent: 27, received: 39 },
    { name: 'ئایار', sent: 18, received: 48 },
    { name: 'حوزەیران', sent: 23, received: 38 },
  ], []);

  // Active Users Calculation (Mock logic based on recent activity)
  const activeUsers = React.useMemo(() => activityLogs
    .reduce((acc: any[], log) => {
      if (!acc.find(u => u.userId === log.userId)) {
        acc.push({ userId: log.userId, userName: log.userName, lastAction: log.action, time: log.timestamp });
      }
      return acc;
    }, [])
    .slice(0, 5), [activityLogs]);

  // SLA Calculation (Based on doc.deadline)
  const slaDocs = React.useMemo(() => pending.map(doc => {
    const created = new Date(doc.createdAt);
    const deadline = doc.deadline ? new Date(doc.deadline) : new Date(created.getTime() + 3 * 24 * 60 * 60 * 1000);
    const timeLeft = deadline.getTime() - now.getTime();
    const daysLeft = Math.ceil(timeLeft / (1000 * 60 * 60 * 24));
    
    // Calculate total days between created and deadline
    const totalTime = deadline.getTime() - created.getTime();
    const totalDays = Math.ceil(totalTime / (1000 * 60 * 60 * 24)) || 3;
    
    const progress = Math.min(100, Math.max(0, ((totalDays - daysLeft) / totalDays) * 100));
    
    return { ...doc, daysLeft, progress, totalDays };
  }).sort((a, b) => a.daysLeft - b.daysLeft).slice(0, 5), [pending, now]);

  return (
    <div className="space-y-8 pb-10 max-w-[1800px] mx-auto relative z-10" dir="rtl">
      {/* Header Section */}
      <div className="glass-panel p-8 rounded-[2.5rem] border border-white/20 shadow-[0_8px_32px_rgba(0,0,0,0.3)] relative overflow-hidden">
        <div className="absolute inset-0 bg-gradient-to-r from-blue-600/20 to-purple-600/20 opacity-50" />
        <div className="relative z-10 flex flex-col md:flex-row justify-between items-start md:items-center gap-6">
          <div>
            <h2 className="text-4xl md:text-5xl font-black text-white neon-text tracking-tight mb-2 drop-shadow-[0_0_15px_rgba(255,255,255,0.3)]">
              بەخێربێیت، <span className="text-transparent bg-clip-text bg-gradient-to-r from-blue-400 via-indigo-400 to-purple-400 animate-pulse-glow">{currentUser?.name}</span>
            </h2>
            <p className="text-blue-200/80 text-lg font-medium flex items-center gap-2">
              <span className="w-2 h-2 rounded-full bg-emerald-400 shadow-[0_0_10px_rgba(52,211,153,0.8)] animate-pulse" />
              سیستەمی EDMS • بەڕێوەبردنی زیرەکی نوسراوەکان
            </p>
          </div>
          
          <div className="flex items-center gap-4">
            <div className="hidden md:flex items-center gap-2 px-4 py-2 bg-white/5 rounded-2xl border border-white/10 backdrop-blur-md shadow-[0_4px_15px_rgba(0,0,0,0.1)]">
              <Calendar size={18} className="text-blue-400" />
              <span className="text-slate-200 font-mono text-sm tracking-wide" dir="ltr">{new Date().toLocaleDateString('en-US', { weekday: 'long', year: 'numeric', month: 'short', day: 'numeric' })}</span>
            </div>
            <button onClick={() => onNavigate('search')} className="relative group p-4 rounded-2xl bg-white/5 border border-white/10 text-slate-300 hover:text-white hover:bg-white/10 transition-all duration-300 hover:-translate-y-1 hover:shadow-[0_10px_25px_rgba(59,130,246,0.3)] overflow-hidden backdrop-blur-md">
              <div className="absolute inset-0 bg-gradient-to-tr from-blue-500/20 to-transparent opacity-0 group-hover:opacity-100 transition-opacity duration-300" />
              <Search size={24} className="group-hover:scale-110 transition-transform duration-300" />
            </button>
            <button onClick={() => onNavigate('settings')} className="relative group p-4 rounded-2xl bg-white/5 border border-white/10 text-slate-300 hover:text-white hover:bg-white/10 transition-all duration-300 hover:-translate-y-1 hover:shadow-[0_10px_25px_rgba(168,85,247,0.3)] overflow-hidden backdrop-blur-md">
              <div className="absolute inset-0 bg-gradient-to-tr from-purple-500/20 to-transparent opacity-0 group-hover:opacity-100 transition-opacity duration-300" />
              <Zap size={24} className="group-hover:scale-110 transition-transform duration-300" />
            </button>
          </div>
        </div>
      </div>

      {/* AI Insight & System Status */}
      <div className="grid grid-cols-1 gap-6">
        <div className="relative group">
          <div className="absolute inset-0 bg-gradient-to-r from-blue-600/30 to-indigo-600/30 rounded-[2.5rem] blur-2xl opacity-60 group-hover:opacity-100 transition-opacity duration-150 ease-out" />
          <div className="relative glass-panel p-8 rounded-[2.5rem] border border-white/20 overflow-hidden shadow-[0_8px_32px_rgba(0,0,0,0.3)]">
            <div className="absolute top-0 right-0 p-8 opacity-5">
              <Cpu size={150} className="text-blue-200" />
            </div>
            
            <div className="flex items-start gap-6 relative z-10">
              <div className="w-16 h-16 rounded-2xl bg-gradient-to-br from-blue-500 to-indigo-600 flex items-center justify-center shadow-[0_0_30px_rgba(59,130,246,0.5)] animate-float shrink-0 border border-white/20">
                <Zap className="text-white" size={32} />
              </div>
              <div className="flex-1">
                <div className="flex items-center gap-3 mb-3">
                  <h3 className="text-2xl font-black text-white drop-shadow-md">شیکاری سیستەمی ئیدارەی ئەفسەران</h3>
                  <span className="px-2 py-0.5 rounded-full bg-blue-500/20 text-blue-300 text-[10px] font-bold border border-blue-400/50 shadow-[0_0_10px_rgba(59,130,246,0.3)] animate-pulse">ڕاستەوخۆ</span>
                </div>
                <div className="bg-black/20 rounded-2xl p-6 border border-white/10 backdrop-blur-md relative overflow-hidden group/text shadow-inner">
                  <div className="absolute left-0 top-0 bottom-0 w-1 bg-gradient-to-b from-blue-400 to-indigo-500 shadow-[0_0_10px_rgba(59,130,246,0.8)]" />
                  <p className="font-mono text-lg text-blue-50 leading-relaxed tracking-wide">
                    <span className="text-blue-400/70 mr-2 font-black select-none">{'>'}</span>
                    {aiInsight}
                    <span className="inline-block w-2.5 h-5 bg-blue-400 ml-1 animate-pulse align-middle shadow-[0_0_8px_rgba(59,130,246,0.8)]" />
                  </p>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>

      {/* Quick Actions - Large Gradient Buttons */}
      <div>
        <h3 className="text-2xl font-black text-white mb-6 flex items-center gap-3 drop-shadow-md">
          <Zap className="text-amber-400 drop-shadow-[0_0_10px_rgba(251,191,36,0.6)]" size={28} />
          کرداری خێرا
        </h3>
        <div className="grid grid-cols-1 md:grid-cols-4 gap-4">
          <button 
            onClick={() => onNavigate('dispatch')}
            className="group relative h-24 rounded-2xl overflow-hidden transition-all duration-150 ease-out hover:-translate-y-1 hover:shadow-[0_10px_20px_rgba(37,99,235,0.4)] border border-white/20"
          >
            <div className="absolute inset-0 bg-gradient-to-br from-blue-600/90 to-indigo-700/90 backdrop-blur-md transition-transform duration-150 ease-out group-hover:scale-105" />
            <div className="absolute inset-0 flex items-center justify-between p-5">
              <div className="text-right">
                <h4 className="text-lg font-black text-white mb-1 drop-shadow-md">نوسراوی نوێ</h4>
                <p className="text-blue-100 text-xs font-medium opacity-90 tracking-wide">دەستپێکردنی نوسراوێک</p>
              </div>
              <div className="w-12 h-12 rounded-xl bg-white/20 backdrop-blur-xl flex items-center justify-center text-white shadow-[0_4px_16px_rgba(0,0,0,0.2)] border border-white/30 group-hover:rotate-12 transition-transform duration-150 ease-out">
                <FileText size={24} />
              </div>
            </div>
          </button>

          <button 
            onClick={() => onNavigate('requests')}
            className="group relative h-24 rounded-2xl overflow-hidden transition-all duration-150 ease-out hover:-translate-y-1 hover:shadow-[0_10px_20px_rgba(16,185,129,0.4)] border border-white/20"
          >
            <div className="absolute inset-0 bg-gradient-to-br from-emerald-600/90 to-teal-700/90 backdrop-blur-md transition-transform duration-150 ease-out group-hover:scale-105" />
            <div className="absolute inset-0 flex items-center justify-between p-5">
              <div className="text-right">
                <h4 className="text-lg font-black text-white mb-1 drop-shadow-md">داواکاری نوێ</h4>
                <p className="text-emerald-100 text-xs font-medium opacity-90 tracking-wide">تۆمارکردنی داواکاری</p>
              </div>
              <div className="w-12 h-12 rounded-xl bg-white/20 backdrop-blur-xl flex items-center justify-center text-white shadow-[0_4px_16px_rgba(0,0,0,0.2)] border border-white/30 group-hover:rotate-12 transition-transform duration-150 ease-out">
                <Zap size={24} />
              </div>
            </div>
          </button>

          <button 
            onClick={() => onNavigate('circulars')}
            className="group relative h-24 rounded-2xl overflow-hidden transition-all duration-150 ease-out hover:-translate-y-1 hover:shadow-[0_10px_20px_rgba(168,85,247,0.4)] border border-white/20"
          >
            <div className="absolute inset-0 bg-gradient-to-br from-purple-600/90 to-fuchsia-700/90 backdrop-blur-md transition-transform duration-150 ease-out group-hover:scale-105" />
            <div className="absolute inset-0 flex items-center justify-between p-5">
              <div className="text-right">
                <h4 className="text-lg font-black text-white mb-1 drop-shadow-md">گشتاندنی نوێ</h4>
                <p className="text-purple-100 text-xs font-medium opacity-90 tracking-wide">بڵاوکردنەوەی گشتاندن</p>
              </div>
              <div className="w-12 h-12 rounded-xl bg-white/20 backdrop-blur-xl flex items-center justify-center text-white shadow-[0_4px_16px_rgba(0,0,0,0.2)] border border-white/30 group-hover:rotate-12 transition-transform duration-150 ease-out">
                <Share2 size={24} />
              </div>
            </div>
          </button>

          <button 
            onClick={() => onNavigate('archive')}
            className="group relative h-24 rounded-2xl overflow-hidden transition-all duration-150 ease-out hover:-translate-y-1 hover:shadow-[0_10px_20px_rgba(71,85,105,0.4)] border border-white/20"
          >
            <div className="absolute inset-0 bg-gradient-to-br from-slate-600/90 to-gray-700/90 backdrop-blur-md transition-transform duration-150 ease-out group-hover:scale-105" />
            <div className="absolute inset-0 flex items-center justify-between p-5">
              <div className="text-right">
                <h4 className="text-lg font-black text-white mb-1 drop-shadow-md">ئەرشیف کردن</h4>
                <p className="text-slate-100 text-xs font-medium opacity-90 tracking-wide">چوونە ناو ئەرشیف</p>
              </div>
              <div className="w-12 h-12 rounded-xl bg-white/20 backdrop-blur-xl flex items-center justify-center text-white shadow-[0_4px_16px_rgba(0,0,0,0.2)] border border-white/30 group-hover:rotate-12 transition-transform duration-150 ease-out">
                <Archive size={24} />
              </div>
            </div>
          </button>
        </div>
      </div>

      {/* Stats Grid - Bento Style */}
      <div className="grid grid-cols-2 md:grid-cols-4 lg:grid-cols-6 gap-5">
        {[
          { title: 'نوسراوەکان', count: allDocs.length, icon: FileText, color: 'blue', gradient: 'from-blue-500 to-indigo-600' },
          { title: 'چاوەڕوان', count: pending.length, icon: Clock, color: 'amber', gradient: 'from-amber-400 to-orange-500' },
          { title: 'پەسەندکراو', count: approved.length, icon: CheckCircle2, color: 'emerald', gradient: 'from-emerald-400 to-teal-500' },
          { title: 'ڕەتکراو', count: rejected.length, icon: XCircle, color: 'red', gradient: 'from-rose-400 to-red-600' },
          { title: 'ئەرشیف', count: archived.length, icon: Archive, color: 'slate', gradient: 'from-slate-400 to-slate-600' },
          { title: 'گشتاندن', count: circulars.length, icon: Share2, color: 'purple', gradient: 'from-purple-400 to-fuchsia-500' },
        ].map((stat, idx) => (
          <div 
            key={idx}
            className="group relative p-6 rounded-[2rem] glass-panel border border-white/20 overflow-hidden hover:bg-white/10 transition-all duration-150 ease-out hover:-translate-y-2 hover:shadow-[0_15px_30px_rgba(0,0,0,0.4)] cursor-pointer"
            onClick={() => onNavigate('documents')}
          >
            <div className={`absolute -top-6 -right-6 w-32 h-32 bg-gradient-to-br ${stat.gradient} opacity-20 blur-3xl group-hover:opacity-40 transition-opacity duration-150 ease-out`} />
            <div className="relative z-10">
              <div className={`w-14 h-14 rounded-2xl bg-gradient-to-br ${stat.gradient} flex items-center justify-center text-white shadow-[0_8px_16px_rgba(0,0,0,0.3)] border border-white/20 mb-5 group-hover:scale-110 transition-transform duration-150 ease-out`}>
                <stat.icon size={26} />
              </div>
              <div className="text-4xl font-black text-white drop-shadow-md mb-1">{stat.count}</div>
              <div className="text-xs font-bold text-slate-300 uppercase tracking-widest">{stat.title}</div>
            </div>
          </div>
        ))}
      </div>

      {/* Main Content Grid */}
      <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
        {/* Charts Section */}
        <div className="lg:col-span-2 glass-panel p-8 rounded-[2.5rem] border border-white/10 shadow-2xl relative overflow-hidden">
          <div className="absolute top-0 left-0 w-full h-1 bg-gradient-to-r from-blue-500 via-purple-500 to-emerald-500" />
          <div className="flex items-center justify-between mb-8">
            <div>
              <h3 className="text-2xl font-black text-white flex items-center gap-3">
                <BarChart2 className="text-blue-400" size={28} />
                شیکاری و ئامار
              </h3>
              <p className="text-slate-500 text-sm mt-1">بەراوردکردنی داتای هەفتانە</p>
            </div>
            <div className="flex gap-2 bg-black/20 p-1 rounded-xl border border-white/5">
              <button className="px-4 py-2 rounded-lg bg-white/10 text-white text-xs font-bold shadow-sm">هەفتانە</button>
              <button className="px-4 py-2 rounded-lg text-slate-400 hover:text-white text-xs font-bold transition-colors">مانگانە</button>
            </div>
          </div>
          
          <div className="h-[350px] w-full" dir="ltr">
            <ResponsiveContainer width="100%" height="100%">
              <AreaChart data={activityData}>
                <defs>
                  <linearGradient id="colorDocs" x1="0" y1="0" x2="0" y2="1">
                    <stop offset="5%" stopColor="#3b82f6" stopOpacity={0.4}/>
                    <stop offset="95%" stopColor="#3b82f6" stopOpacity={0}/>
                  </linearGradient>
                  <linearGradient id="colorPred" x1="0" y1="0" x2="0" y2="1">
                    <stop offset="5%" stopColor="#a855f7" stopOpacity={0.4}/>
                    <stop offset="95%" stopColor="#a855f7" stopOpacity={0}/>
                  </linearGradient>
                </defs>
                <CartesianGrid strokeDasharray="3 3" stroke="rgba(255,255,255,0.05)" vertical={false} />
                <XAxis dataKey="name" stroke="#64748b" fontSize={12} tickLine={false} axisLine={false} dy={10} />
                <YAxis stroke="#64748b" fontSize={12} tickLine={false} axisLine={false} dx={-10} />
                <Tooltip 
                  contentStyle={{ backgroundColor: 'rgba(15, 23, 42, 0.9)', borderRadius: '16px', border: '1px solid rgba(255,255,255,0.1)', color: '#fff', backdropFilter: 'blur(10px)', boxShadow: '0 10px 30px rgba(0,0,0,0.5)' }}
                  itemStyle={{ fontSize: '13px', fontWeight: 'bold' }}
                  cursor={{ stroke: 'rgba(255,255,255,0.1)', strokeWidth: 2 }}
                />
                <Area type="monotone" dataKey="documents" stroke="#3b82f6" strokeWidth={4} fillOpacity={1} fill="url(#colorDocs)" name="نوسراوی ڕاستەقینە" />
                <Area type="monotone" dataKey="prediction" stroke="#a855f7" strokeWidth={3} strokeDasharray="8 8" fillOpacity={1} fill="url(#colorPred)" name="پێشبینی AI" />
              </AreaChart>
            </ResponsiveContainer>
          </div>
        </div>

        {/* Storage Analysis (New) */}
        <div className="glass-panel p-8 rounded-[2.5rem] border border-white/10 shadow-2xl flex flex-col relative overflow-hidden">
          <div className="absolute top-0 left-0 w-full h-1 bg-gradient-to-r from-purple-500 to-pink-500" />
          <h3 className="text-xl font-black text-white mb-6 flex items-center gap-3">
            <PieChartIcon className="text-purple-400" size={24} />
            شیکاری فایلەکان
          </h3>
          
          <div className="flex-1 flex items-center justify-center relative">
            <div className="absolute inset-0 flex items-center justify-center flex-col pointer-events-none">
              <span className="text-3xl font-black text-white neon-text">85%</span>
              <span className="text-xs text-slate-400">بەکارهاتوو</span>
            </div>
            <div className="w-full h-[200px]">
              <ResponsiveContainer width="100%" height="100%">
                <PieChart>
                  <Pie
                    data={storageData}
                    cx="50%"
                    cy="50%"
                    innerRadius={60}
                    outerRadius={80}
                    paddingAngle={5}
                    dataKey="value"
                    stroke="none"
                  >
                    {storageData.map((entry, index) => (
                      <Cell key={`cell-${index}`} fill={entry.color} />
                    ))}
                  </Pie>
                  <Tooltip 
                    contentStyle={{ backgroundColor: 'rgba(15, 23, 42, 0.9)', borderRadius: '12px', border: 'none', color: '#fff' }}
                    itemStyle={{ fontSize: '12px' }}
                  />
                </PieChart>
              </ResponsiveContainer>
            </div>
          </div>
          
          <div className="grid grid-cols-2 gap-4 mt-6">
            {storageData.map((item, idx) => (
              <div key={idx} className="flex items-center gap-2">
                <div className="w-3 h-3 rounded-full" style={{ backgroundColor: item.color }} />
                <span className="text-xs text-slate-300 font-medium">{item.name}</span>
                <span className="text-xs text-slate-500 ml-auto">{item.value}%</span>
              </div>
            ))}
          </div>
        </div>

        {/* Document Analysis */}
        <div className="glass-panel p-8 rounded-[2.5rem] border border-white/10 shadow-2xl flex flex-col relative overflow-hidden">
          <div className="absolute top-0 left-0 w-full h-1 bg-gradient-to-r from-blue-500 to-indigo-500" />
          <h3 className="text-xl font-black text-white mb-6 flex items-center gap-3">
            <FileText className="text-blue-400" size={24} />
            شیکاری نوسراوەکان
          </h3>
          
          <div className="flex-1 flex items-center justify-center relative">
            <div className="absolute inset-0 flex items-center justify-center flex-col pointer-events-none">
              <span className="text-3xl font-black text-white neon-text">{allDocs.length}</span>
              <span className="text-xs text-slate-400">کۆی گشتی</span>
            </div>
            <div className="w-full h-[200px]">
              <ResponsiveContainer width="100%" height="100%">
                <PieChart>
                  <Pie
                    data={statusData}
                    cx="50%"
                    cy="50%"
                    innerRadius={60}
                    outerRadius={80}
                    paddingAngle={5}
                    dataKey="value"
                    stroke="none"
                  >
                    {statusData.map((entry, index) => (
                      <Cell key={`cell-${index}`} fill={entry.color} />
                    ))}
                  </Pie>
                  <Tooltip 
                    contentStyle={{ backgroundColor: 'rgba(15, 23, 42, 0.9)', borderRadius: '12px', border: 'none', color: '#fff' }}
                    itemStyle={{ fontSize: '12px' }}
                  />
                </PieChart>
              </ResponsiveContainer>
            </div>
          </div>
          
          <div className="grid grid-cols-2 gap-4 mt-6">
            {statusData.map((item, idx) => (
              <div key={idx} className="flex items-center gap-2">
                <div className="w-3 h-3 rounded-full" style={{ backgroundColor: item.color }} />
                <span className="text-xs text-slate-300 font-medium">{item.name}</span>
                <span className="text-xs text-slate-500 ml-auto">{item.value}</span>
              </div>
            ))}
          </div>
        </div>
      </div>

      {/* New Charts Row */}
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
        {/* Department Activity Bar Chart */}
        <div className="glass-panel p-8 rounded-[2.5rem] border border-white/10 shadow-xl relative overflow-hidden">
          <h3 className="text-xl font-black text-white mb-6 flex items-center gap-3">
            <Building2 className="text-indigo-400" size={24} />
            چالاکی بەشەکان
          </h3>
          <div className="h-[250px] w-full" dir="ltr">
            <ResponsiveContainer width="100%" height="100%">
              <BarChart data={departmentActivityData} layout="vertical">
                <CartesianGrid strokeDasharray="3 3" stroke="rgba(255,255,255,0.05)" horizontal={false} />
                <XAxis type="number" stroke="#64748b" fontSize={10} tickLine={false} axisLine={false} />
                <YAxis dataKey="name" type="category" stroke="#94a3b8" fontSize={10} tickLine={false} axisLine={false} width={80} />
                <Tooltip 
                  cursor={{fill: 'rgba(255,255,255,0.05)'}}
                  contentStyle={{ backgroundColor: 'rgba(15, 23, 42, 0.9)', borderRadius: '12px', border: 'none', color: '#fff' }}
                />
                <Bar dataKey="count" fill="#6366f1" radius={[0, 4, 4, 0]} barSize={20} />
              </BarChart>
            </ResponsiveContainer>
          </div>
        </div>

        {/* Priority Distribution Pie Chart */}
        <div className="glass-panel p-8 rounded-[2.5rem] border border-white/10 shadow-xl relative overflow-hidden">
          <h3 className="text-xl font-black text-white mb-6 flex items-center gap-3">
            <AlertCircle className="text-rose-400" size={24} />
            دابەشبوونی گرنگی
          </h3>
          <div className="h-[250px] w-full flex items-center justify-center">
            <ResponsiveContainer width="100%" height="100%">
              <PieChart>
                <Pie
                  data={priorityData}
                  cx="50%"
                  cy="50%"
                  innerRadius={60}
                  outerRadius={80}
                  paddingAngle={5}
                  dataKey="value"
                >
                  {priorityData.map((entry, index) => (
                    <Cell key={`cell-${index}`} fill={entry.fill} />
                  ))}
                </Pie>
                <Tooltip contentStyle={{ backgroundColor: 'rgba(15, 23, 42, 0.9)', borderRadius: '12px', border: 'none', color: '#fff' }} />
              </PieChart>
            </ResponsiveContainer>
          </div>
          <div className="flex justify-center gap-4 mt-[-20px]">
            {priorityData.map((entry, index) => (
              <div key={index} className="flex items-center gap-2 text-xs text-slate-400">
                <div className="w-2 h-2 rounded-full" style={{ backgroundColor: entry.fill }} />
                {entry.name}
              </div>
            ))}
          </div>
        </div>

        {/* Monthly Trends Line Chart */}
        <div className="glass-panel p-8 rounded-[2.5rem] border border-white/10 shadow-xl relative overflow-hidden">
          <h3 className="text-xl font-black text-white mb-6 flex items-center gap-3">
            <TrendingUp className="text-cyan-400" size={24} />
            ڕەوتی ڕۆژانە
          </h3>
          <div className="h-[250px] w-full" dir="ltr">
            <ResponsiveContainer width="100%" height="100%">
              <LineChart data={monthlyTrends}>
                <CartesianGrid strokeDasharray="3 3" stroke="rgba(255,255,255,0.05)" vertical={false} />
                <XAxis dataKey="name" stroke="#64748b" fontSize={10} tickLine={false} axisLine={false} dy={10} />
                <Tooltip contentStyle={{ backgroundColor: 'rgba(15, 23, 42, 0.9)', borderRadius: '12px', border: 'none', color: '#fff' }} />
                <Line type="monotone" dataKey="sent" stroke="#06b6d4" strokeWidth={3} dot={false} />
                <Line type="monotone" dataKey="received" stroke="#8b5cf6" strokeWidth={3} dot={false} />
              </LineChart>
            </ResponsiveContainer>
          </div>
        </div>
      </div>

      {/* Active Users & SLA Widget */}
      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
        {/* Active Users Widget */}
        <div className="glass-panel p-8 rounded-[2.5rem] border border-white/10 shadow-xl relative overflow-hidden">
          <div className="absolute top-0 left-0 w-full h-1 bg-gradient-to-r from-pink-500 to-rose-500" />
          <div className="flex items-center justify-between mb-6">
            <h3 className="text-xl font-black text-white flex items-center gap-3">
              <Users className="text-pink-400" size={24} />
              بەکارهێنەرە چالاکەکان
            </h3>
            <span className="px-3 py-1 bg-pink-500/10 text-pink-400 text-[10px] font-black rounded-full border border-pink-500/20 animate-pulse">
              {activeUsers.length} سەرهێڵ
            </span>
          </div>
          
          <div className="flex flex-col gap-3">
            {activeUsers.length === 0 ? (
              <div className="text-center text-slate-500 py-8">هیچ بەکارهێنەرێک چالاک نییە</div>
            ) : (
              activeUsers.map((user, idx) => (
                <div key={idx} className="bg-white/5 border border-white/5 rounded-2xl p-3 flex items-center gap-4 hover:bg-white/10 transition-colors group">
                  <div className="relative shrink-0">
                    <div className="w-10 h-10 rounded-full bg-gradient-to-br from-pink-500 to-rose-600 flex items-center justify-center text-white font-bold text-sm shadow-lg group-hover:scale-110 transition-transform">
                      {user.userName.charAt(0)}
                    </div>
                    <div className="absolute bottom-0 right-0 w-2.5 h-2.5 bg-emerald-500 border-2 border-[#0f172a] rounded-full animate-pulse" />
                  </div>
                  <div className="flex-1 min-w-0">
                    <h4 className="text-white font-bold text-sm mb-0.5 truncate">{user.userName}</h4>
                    <p className="text-xs text-slate-400 truncate">{user.lastAction}</p>
                  </div>
                  <div className="text-[10px] text-slate-500 shrink-0 font-mono">
                    {new Date(user.time).toLocaleTimeString()}
                  </div>
                </div>
              ))
            )}
          </div>
        </div>

        {/* SLA Timer Widget */}
        <div className="glass-panel p-8 rounded-[2.5rem] border border-white/10 shadow-xl relative overflow-hidden">
          <div className="absolute top-0 left-0 w-full h-1 bg-gradient-to-r from-orange-500 to-red-500" />
          <div className="flex items-center justify-between mb-6">
            <h3 className="text-xl font-black text-white flex items-center gap-3">
              <Clock className="text-orange-400" size={24} />
              چاودێری کات (SLA)
            </h3>
            <span className="text-xs font-bold text-slate-500">وادەی دیاریکراو</span>
          </div>

          <div className="space-y-4">
            {slaDocs.length === 0 ? (
              <div className="text-center text-slate-500 py-8">هیچ نوسراوێک لە چاوەڕوانیدا نییە</div>
            ) : (
              slaDocs.map((doc, idx) => (
                <div key={idx} className="group p-4 rounded-2xl bg-white/5 border border-white/5 hover:bg-white/10 transition-colors cursor-pointer" onClick={() => onViewDoc(doc)}>
                  <div className="flex justify-between items-center mb-2">
                    <h4 className="text-white font-bold text-sm truncate max-w-[200px]">{doc.title}</h4>
                    <span className={`text-xs font-black px-2 py-0.5 rounded-full ${
                      doc.daysLeft <= 1 ? 'bg-red-500/20 text-red-400 animate-pulse' :
                      doc.daysLeft <= 3 ? 'bg-orange-500/20 text-orange-400' :
                      'bg-emerald-500/20 text-emerald-400'
                    }`}>
                      {doc.daysLeft <= 0 ? 'بەسەرچوو' : `${doc.daysLeft} ڕۆژ ماوە`}
                    </span>
                  </div>
                  
                  <div className="relative h-2 bg-white/10 rounded-full overflow-hidden">
                    <div 
                      className={`absolute top-0 right-0 h-full rounded-full transition-all duration-1000 ${
                        doc.daysLeft <= 1 ? 'bg-red-500' :
                        doc.daysLeft <= 3 ? 'bg-orange-500' :
                        'bg-emerald-500'
                      }`}
                      style={{ width: `${doc.progress}%` }}
                    />
                  </div>
                  <div className="flex justify-between mt-1 text-[10px] text-slate-500">
                    <span>{doc.senderName}</span>
                    <span className="font-mono" dir="ltr">{Math.round(doc.progress)}% کات ڕۆیشتووە</span>
                  </div>
                </div>
              ))
            )}
          </div>
        </div>
      </div>

      {/* Activity Feed & Deadlines */}
      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
        {/* Activity Feed */}
        <div className="glass-panel p-8 rounded-[2.5rem] border border-white/10 shadow-xl flex flex-col h-[500px]">
          <div className="flex items-center justify-between mb-6">
            <h3 className="text-xl font-black text-white flex items-center gap-3">
              <Activity className="text-blue-400" size={24} />
              تۆماری چالاکیەکان
            </h3>
            <span className="px-3 py-1 bg-blue-500/10 text-blue-400 text-[10px] font-black rounded-full border border-blue-500/20 animate-pulse">ڕاستەوخۆ</span>
          </div>
          
          <div className="flex-1 overflow-y-auto custom-scrollbar space-y-4 pr-2">
            {activityLogs.length === 0 ? (
              <div className="text-center text-slate-500 py-10">هیچ چالاکییەک تۆمار نەکراوە</div>
            ) : (
              activityLogs.map((log) => (
                <div key={log.id} className="flex gap-4 p-4 rounded-2xl bg-white/5 border border-white/5 hover:bg-white/10 transition-colors">
                  <div className={`w-10 h-10 rounded-full flex items-center justify-center shrink-0 ${
                    log.type === 'create' ? 'bg-blue-500/20 text-blue-400' :
                    log.type === 'approve' ? 'bg-emerald-500/20 text-emerald-400' :
                    log.type === 'reject' ? 'bg-red-500/20 text-red-400' :
                    'bg-slate-500/20 text-slate-400'
                  }`}>
                    {log.type === 'create' ? <Plus size={18} /> :
                     log.type === 'approve' ? <CheckCircle2 size={18} /> :
                     log.type === 'reject' ? <XCircle size={18} /> :
                     <Activity size={18} />}
                  </div>
                  <div>
                    <p className="text-sm text-white font-bold">
                      <span className="text-blue-400">{log.userName}</span> {log.action}
                    </p>
                    <p className="text-xs text-slate-400 mt-1">{log.target}</p>
                    <p className="text-[10px] text-slate-600 mt-2 font-mono">{new Date(log.timestamp).toLocaleTimeString()}</p>
                  </div>
                </div>
              ))
            )}
          </div>
        </div>

        {/* Upcoming Deadlines (New) */}
        <div className="glass-panel p-8 rounded-[2.5rem] border border-white/10 shadow-xl flex flex-col h-[500px] relative overflow-hidden">
          <div className="absolute top-0 left-0 w-full h-1 bg-gradient-to-r from-amber-500 to-orange-500" />
          <div className="flex items-center justify-between mb-6">
            <h3 className="text-xl font-black text-white flex items-center gap-3">
              <Clock className="text-amber-400" size={24} />
              وادەی نزیک
            </h3>
            <span className="text-xs font-bold text-slate-500">٧ ڕۆژی داهاتوو</span>
          </div>
          
          <div className="flex-1 overflow-y-auto custom-scrollbar space-y-4 pr-2">
            {upcomingDeadlines.length === 0 ? (
              <div className="text-center text-slate-500 py-10">هیچ وادەیەک نییە</div>
            ) : (
              upcomingDeadlines.map(doc => (
                <div key={doc.id} className="group p-4 rounded-2xl bg-white/5 border border-white/5 hover:bg-white/10 transition-colors cursor-pointer" onClick={() => onViewDoc(doc)}>
                  <div className="flex items-center gap-3 mb-2">
                    <div className="w-8 h-8 rounded-lg bg-amber-500/20 text-amber-400 flex items-center justify-center shrink-0">
                      <AlertCircle size={16} />
                    </div>
                    <h4 className="font-bold text-white text-sm truncate flex-1">{doc.title}</h4>
                  </div>
                  <div className="flex items-center justify-between text-xs text-slate-400">
                    <span>{doc.senderName}</span>
                    <span className="font-mono text-amber-300" dir="ltr">{new Date(doc.deadline!).toLocaleDateString()}</span>
                  </div>
                </div>
              ))
            )}
          </div>
        </div>
      </div>

      {/* Recent Documents & Workflow */}
      <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
        {/* Recent Documents (New) */}
        <div className="lg:col-span-2 glass-panel p-8 rounded-[2.5rem] border border-white/10 shadow-2xl relative overflow-hidden">
          <div className="flex items-center justify-between mb-6">
            <h3 className="text-2xl font-black text-white flex items-center gap-3">
              <FileText className="text-blue-400" size={28} />
              دواین نوسراوەکان
            </h3>
            <button onClick={() => onNavigate('documents')} className="text-sm text-blue-400 hover:text-blue-300 font-bold transition-colors flex items-center gap-1">
              بینینی هەموو <ArrowRight size={14} className="rotate-180" />
            </button>
          </div>
          <div className="overflow-x-auto">
            <table className="w-full text-right border-collapse">
              <thead>
                <tr className="border-b border-white/10 text-slate-400 text-sm">
                  <th className="pb-4 font-bold pr-4">بابەت</th>
                  <th className="pb-4 font-bold">نێرەر</th>
                  <th className="pb-4 font-bold">بەروار</th>
                  <th className="pb-4 font-bold">دۆخ</th>
                  <th className="pb-4 font-bold pl-4">کردار</th>
                </tr>
              </thead>
              <tbody className="text-white">
                {recentDocs.length === 0 ? (
                  <tr>
                    <td colSpan={5} className="py-8 text-center text-slate-500">هیچ نوسراوێک نییە</td>
                  </tr>
                ) : (
                  recentDocs.map(doc => (
                    <tr key={doc.id} className="group border-b border-white/5 hover:bg-white/5 transition-colors">
                      <td className="py-4 pr-4 font-medium text-sm">{doc.title}</td>
                      <td className="py-4 text-slate-400 text-sm">{doc.senderName}</td>
                      <td className="py-4 text-slate-400 font-mono text-xs" dir="ltr">{new Date(doc.createdAt).toLocaleDateString()}</td>
                      <td className="py-4">
                        <span className={`px-3 py-1 rounded-full text-[10px] font-black border ${
                          doc.status === 'Approved' ? 'bg-emerald-500/10 text-emerald-400 border-emerald-500/20' :
                          doc.status === 'Rejected' ? 'bg-red-500/10 text-red-400 border-red-500/20' :
                          doc.status === 'Archived' ? 'bg-blue-500/10 text-blue-400 border-blue-500/20' :
                          doc.status === 'Under Review' ? 'bg-purple-500/10 text-purple-400 border-purple-500/20' :
                          'bg-amber-500/10 text-amber-400 border-amber-500/20'
                        }`}>
                          {getStatusLabel(doc.status)}
                        </span>
                      </td>
                      <td className="py-4 pl-4">
                        <button onClick={() => onViewDoc(doc)} className="p-2 rounded-lg bg-white/5 hover:bg-white/10 text-slate-300 hover:text-white transition-colors group-hover:bg-blue-500 group-hover:text-white">
                          <ArrowRight size={16} className="rotate-180" />
                        </button>
                      </td>
                    </tr>
                  ))
                )}
              </tbody>
            </table>
          </div>
        </div>

        {/* Workflow Status */}
        <div className="glass-panel p-8 rounded-[2.5rem] border border-white/20 shadow-[0_8px_32px_rgba(0,0,0,0.3)] flex flex-col relative overflow-hidden">
          <div className="absolute top-0 left-0 w-full h-1.5 bg-gradient-to-r from-amber-400 via-pink-500 to-purple-500" />
          <h3 className="text-2xl font-black text-white mb-8 flex items-center gap-3 drop-shadow-md">
            <Layers className="text-amber-400 drop-shadow-[0_0_10px_rgba(251,191,36,0.6)]" size={28} />
            دۆخی ڕەوتی کار
          </h3>
          
          <div className="relative flex-1 flex flex-col justify-between py-2">
            {/* Connecting Line */}
            <div className="absolute right-[2.25rem] top-8 bottom-8 w-1.5 bg-gradient-to-b from-blue-500 via-pink-500 to-emerald-500 opacity-40 rounded-full shadow-[0_0_10px_rgba(255,255,255,0.2)]" />
            
            {workflowSteps.map((step, idx) => {
              const colors = [
                'from-blue-400 to-indigo-600 shadow-[0_0_20px_rgba(59,130,246,0.5)]',
                'from-pink-400 to-rose-600 shadow-[0_0_20px_rgba(244,63,94,0.5)]',
                'from-amber-400 to-orange-600 shadow-[0_0_20px_rgba(245,158,11,0.5)]',
                'from-emerald-400 to-teal-600 shadow-[0_0_20px_rgba(16,185,129,0.5)]'
              ];
              const colorClass = colors[idx % colors.length];
              
              return (
              <div key={idx} className="group relative flex items-center justify-between p-5 rounded-2xl glass-panel border border-white/10 hover:bg-white/10 transition-all duration-150 ease-out hover:-translate-x-2 hover:shadow-[0_15px_30px_rgba(0,0,0,0.4)] mb-5 z-10">
                <div className="flex items-center gap-6">
                  <div className={`relative w-16 h-16 rounded-2xl bg-gradient-to-br ${colorClass} flex items-center justify-center text-white group-hover:scale-110 group-hover:rotate-6 transition-all duration-150 ease-out border border-white/20`}>
                    <step.icon size={28} />
                    {/* Glowing dot on the line */}
                    <div className="absolute -right-[2.1rem] top-1/2 -translate-y-1/2 w-5 h-5 rounded-full bg-white border-4 border-slate-900 shadow-[0_0_15px_rgba(255,255,255,0.9)] group-hover:scale-125 transition-transform duration-150 ease-out" />
                  </div>
                  <div>
                    <div className="text-white font-black text-lg drop-shadow-md">{step.label}</div>
                    <div className="text-sm text-slate-300 font-medium tracking-wide mt-1">قۆناغی {idx + 1}</div>
                  </div>
                </div>
                <div className="text-4xl font-black text-transparent bg-clip-text bg-gradient-to-br from-white to-slate-400 drop-shadow-lg">{step.count}</div>
              </div>
            )})}
          </div>
          
          <button onClick={() => onNavigate('documents')} className="mt-4 w-full py-4 rounded-2xl bg-white/5 hover:bg-white/10 text-white text-sm font-black transition-all duration-300 border border-white/10 flex items-center justify-center gap-2 group shadow-[0_0_15px_rgba(0,0,0,0.2)] hover:shadow-[0_0_25px_rgba(255,255,255,0.1)]">
            بینینی وردەکاری
            <ChevronLeft size={18} className="group-hover:-translate-x-2 transition-transform duration-300" />
          </button>
        </div>
      </div>

      {/* Alerts Section */}
      {overdueDocs.length > 0 && (
        <div className="glass-panel p-8 rounded-[2.5rem] border border-red-500/30 bg-red-500/5 shadow-[0_0_50px_rgba(239,68,68,0.1)] relative overflow-hidden">
          <div className="absolute -right-10 -top-10 w-40 h-40 bg-red-500/20 rounded-full blur-[60px] animate-pulse" />
          
          <div className="flex items-center justify-between mb-6 relative z-10">
            <h3 className="text-2xl font-black text-white flex items-center gap-3">
              <AlertTriangle className="text-red-500 drop-shadow-[0_0_10px_rgba(239,68,68,0.6)]" size={28} />
              ئاگادارکردنەوەی گرنگ
            </h3>
            <span className="px-4 py-1.5 bg-red-500 text-white text-xs font-black rounded-full shadow-[0_0_15px_rgba(239,68,68,0.5)] animate-pulse">
              {overdueDocs.length} دواکەوتن
            </span>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4 relative z-10">
            {overdueDocs.slice(0, 3).map(doc => (
              <div key={doc.id} className="bg-black/40 border border-red-500/20 rounded-2xl p-5 flex items-center gap-4 group hover:border-red-500/50 transition-all hover:-translate-y-1">
                <div className="w-14 h-14 rounded-2xl bg-red-500/10 flex items-center justify-center text-red-500 shrink-0 shadow-inner">
                  <Clock size={24} />
                </div>
                <div className="flex-1 min-w-0">
                  <h4 className="font-bold text-white text-sm truncate mb-1">{doc.title}</h4>
                  <p className="text-xs text-red-300/80 font-medium truncate">
                    {doc.senderName} • {new Date(doc.deadline!).toLocaleDateString()}
                  </p>
                </div>
                <button onClick={() => onViewDoc(doc)} className="p-2 rounded-xl bg-red-500/20 text-red-400 hover:bg-red-500 hover:text-white transition-all">
                  <ArrowRight size={18} className="rotate-180" />
                </button>
              </div>
            ))}
          </div>
        </div>
      )}
    </div>
  );
};

