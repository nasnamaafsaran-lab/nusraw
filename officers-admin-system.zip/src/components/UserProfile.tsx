import React, { useState, useRef } from 'react';
import { useApp } from '../context';
import { User, Lock, Upload, Save, Shield, Key, PenTool, CheckCircle2, XCircle } from 'lucide-react';

export const UserProfile: React.FC = () => {
  const { currentUser, updateUser, showToast } = useApp();
  const [activeTab, setActiveTab] = useState('general');
  const [currentPassword, setCurrentPassword] = useState('');
  const [newPassword, setNewPassword] = useState('');
  const [confirmPassword, setConfirmPassword] = useState('');
  const [loading, setLoading] = useState(false);
  const fileInputRef = useRef<HTMLInputElement>(null);
  const [signaturePreview, setSignaturePreview] = useState<string | null>(currentUser?.signature || null);

  const handlePasswordChange = async (e: React.FormEvent) => {
    e.preventDefault();
    if (newPassword !== confirmPassword) {
      showToast('وشەی نهێنی نوێ و دووبارەکردنەوەکەی وەک یەک نین', 'error');
      return;
    }
    
    setLoading(true);
    try {
      const res = await fetch('/api/users/change-password', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ 
          userId: currentUser?.id, 
          currentPassword, 
          newPassword 
        })
      });
      
      const data = await res.json();
      if (data.success) {
        showToast('وشەی نهێنی بە سەرکەوتوویی گۆڕدرا', 'success');
        setCurrentPassword('');
        setNewPassword('');
        setConfirmPassword('');
      } else {
        showToast(data.error || 'هەڵە لە گۆڕینی وشەی نهێنی', 'error');
      }
    } catch (error) {
      showToast('هەڵە لە پەیوەندی بە سێرڤەر', 'error');
    } finally {
      setLoading(false);
    }
  };

  const handleSignatureUpload = async (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (!file) return;

    // Convert to base64
    const reader = new FileReader();
    reader.onloadend = async () => {
      const base64 = reader.result as string;
      setSignaturePreview(base64);
      
      try {
        // Update user profile with new signature
        // In a real app, we might upload to a file server, but here we store base64 or path
        // For now, let's assume we send base64 to update endpoint
        const res = await fetch(`/api/users/${currentUser?.id}/signature`, {
          method: 'POST',
          headers: { 'Content-Type': 'application/json' },
          body: JSON.stringify({ signature: base64 })
        });
        
        if (res.ok) {
            showToast('واژۆ بە سەرکەوتوویی نوێکرایەوە', 'success');
            // Update local context if needed, though a refresh might be required or context update
            // updateUser(currentUser.id, { signature: base64 }); // Assuming this exists or we reload
        }
      } catch (error) {
        showToast('هەڵە لە بەرزکردنەوەی واژۆ', 'error');
      }
    };
    reader.readAsDataURL(file);
  };

  return (
    <div className="max-w-4xl mx-auto space-y-8 pb-10" dir="rtl">
      <div className="flex items-center gap-4 mb-8">
        <div className="w-20 h-20 rounded-2xl bg-gradient-to-br from-blue-600 to-indigo-600 flex items-center justify-center shadow-2xl shadow-blue-600/20 border border-white/10">
          <User size={40} className="text-white" />
        </div>
        <div>
          <h1 className="text-3xl font-black text-white neon-text">{currentUser?.name}</h1>
          <p className="text-slate-400 text-lg flex items-center gap-2">
            <Shield size={16} className="text-blue-400" />
            {currentUser?.role} - {currentUser?.department}
          </p>
        </div>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
        {/* Sidebar */}
        <div className="space-y-2">
          <button
            onClick={() => setActiveTab('general')}
            className={`w-full flex items-center gap-3 px-4 py-4 rounded-xl transition-all font-bold ${
              activeTab === 'general' 
                ? 'bg-blue-600 text-white shadow-lg shadow-blue-600/20' 
                : 'bg-white/5 text-slate-400 hover:bg-white/10 hover:text-white'
            }`}
          >
            <User size={20} />
            زانیاری گشتی
          </button>
          <button
            onClick={() => setActiveTab('security')}
            className={`w-full flex items-center gap-3 px-4 py-4 rounded-xl transition-all font-bold ${
              activeTab === 'security' 
                ? 'bg-blue-600 text-white shadow-lg shadow-blue-600/20' 
                : 'bg-white/5 text-slate-400 hover:bg-white/10 hover:text-white'
            }`}
          >
            <Lock size={20} />
            سکیوریتی و وشەی نهێنی
          </button>
          <button
            onClick={() => setActiveTab('signature')}
            className={`w-full flex items-center gap-3 px-4 py-4 rounded-xl transition-all font-bold ${
              activeTab === 'signature' 
                ? 'bg-blue-600 text-white shadow-lg shadow-blue-600/20' 
                : 'bg-white/5 text-slate-400 hover:bg-white/10 hover:text-white'
            }`}
          >
            <PenTool size={20} />
            واژۆی ئەلیکترۆنی
          </button>
        </div>

        {/* Content */}
        <div className="md:col-span-2 space-y-6">
          
          {/* General Info */}
          {activeTab === 'general' && (
            <div className="glass-panel p-8 rounded-3xl border border-white/10 space-y-6 animate-in fade-in slide-in-from-bottom-4 duration-300">
              <h3 className="text-xl font-bold text-white flex items-center gap-2 border-b border-white/10 pb-4">
                <User className="text-blue-400" />
                زانیاری کەسی
              </h3>
              
              <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                <div className="space-y-2">
                  <label className="text-slate-400 text-sm">ناوی تەواو</label>
                  <div className="bg-black/30 border border-white/10 rounded-xl px-4 py-3 text-white font-medium">
                    {currentUser?.name}
                  </div>
                </div>
                <div className="space-y-2">
                  <label className="text-slate-400 text-sm">ناونیشانی وەزیفی</label>
                  <div className="bg-black/30 border border-white/10 rounded-xl px-4 py-3 text-white font-medium">
                    {currentUser?.title}
                  </div>
                </div>
                <div className="space-y-2">
                  <label className="text-slate-400 text-sm">ناوی بەکارهێنەر</label>
                  <div className="bg-black/30 border border-white/10 rounded-xl px-4 py-3 text-white font-medium font-mono">
                    {currentUser?.username}
                  </div>
                </div>
                <div className="space-y-2">
                  <label className="text-slate-400 text-sm">بەش / فەرمانگە</label>
                  <div className="bg-black/30 border border-white/10 rounded-xl px-4 py-3 text-white font-medium">
                    {currentUser?.department}
                  </div>
                </div>
              </div>
            </div>
          )}

          {/* Security */}
          {activeTab === 'security' && (
            <div className="glass-panel p-8 rounded-3xl border border-white/10 space-y-6 animate-in fade-in slide-in-from-bottom-4 duration-300">
              <h3 className="text-xl font-bold text-white flex items-center gap-2 border-b border-white/10 pb-4">
                <Key className="text-orange-400" />
                گۆڕینی وشەی نهێنی
              </h3>

              <form onSubmit={handlePasswordChange} className="space-y-4">
                <div className="space-y-2">
                  <label className="text-slate-400 text-sm">وشەی نهێنی ئێستا</label>
                  <input 
                    type="password" 
                    value={currentPassword}
                    onChange={e => setCurrentPassword(e.target.value)}
                    className="w-full bg-black/30 border border-white/10 rounded-xl px-4 py-3 text-white focus:border-orange-500 outline-none transition-colors"
                    required
                  />
                </div>
                <div className="space-y-2">
                  <label className="text-slate-400 text-sm">وشەی نهێنی نوێ</label>
                  <input 
                    type="password" 
                    value={newPassword}
                    onChange={e => setNewPassword(e.target.value)}
                    className="w-full bg-black/30 border border-white/10 rounded-xl px-4 py-3 text-white focus:border-orange-500 outline-none transition-colors"
                    required
                    minLength={6}
                  />
                </div>
                <div className="space-y-2">
                  <label className="text-slate-400 text-sm">دووبارە وشەی نهێنی نوێ</label>
                  <input 
                    type="password" 
                    value={confirmPassword}
                    onChange={e => setConfirmPassword(e.target.value)}
                    className="w-full bg-black/30 border border-white/10 rounded-xl px-4 py-3 text-white focus:border-orange-500 outline-none transition-colors"
                    required
                    minLength={6}
                  />
                </div>

                <div className="pt-4">
                  <button 
                    type="submit"
                    disabled={loading}
                    className="w-full py-3 bg-orange-600 hover:bg-orange-500 text-white rounded-xl font-bold transition-colors shadow-lg shadow-orange-600/20 flex items-center justify-center gap-2 disabled:opacity-50"
                  >
                    {loading ? 'چاوەڕێبە...' : (
                      <>
                        <Save size={20} />
                        گۆڕینی وشەی نهێنی
                      </>
                    )}
                  </button>
                </div>
              </form>
            </div>
          )}

          {/* Signature */}
          {activeTab === 'signature' && (
            <div className="glass-panel p-8 rounded-3xl border border-white/10 space-y-6 animate-in fade-in slide-in-from-bottom-4 duration-300">
              <h3 className="text-xl font-bold text-white flex items-center gap-2 border-b border-white/10 pb-4">
                <PenTool className="text-purple-400" />
                واژۆی ئەلیکترۆنی
              </h3>

              <div className="space-y-6">
                <div className="bg-white/5 border border-dashed border-white/20 rounded-2xl p-8 flex flex-col items-center justify-center text-center hover:bg-white/10 transition-colors relative group">
                  {signaturePreview ? (
                    <div className="relative w-full h-40 flex items-center justify-center">
                      <img src={signaturePreview} alt="Signature" className="max-h-full max-w-full object-contain filter invert" />
                      <div className="absolute inset-0 bg-black/60 opacity-0 group-hover:opacity-100 transition-opacity flex items-center justify-center rounded-xl">
                        <p className="text-white font-bold">کلیک بکە بۆ گۆڕین</p>
                      </div>
                    </div>
                  ) : (
                    <div className="space-y-2 pointer-events-none">
                      <div className="w-16 h-16 bg-purple-500/20 rounded-full flex items-center justify-center text-purple-400 mx-auto mb-4">
                        <Upload size={32} />
                      </div>
                      <h4 className="text-white font-bold">واژۆیەک باربکە</h4>
                      <p className="text-sm text-slate-400">PNG (Transparent) باشترە</p>
                    </div>
                  )}
                  <input 
                    type="file" 
                    ref={fileInputRef}
                    onChange={handleSignatureUpload}
                    className="absolute inset-0 w-full h-full opacity-0 cursor-pointer"
                    accept="image/*"
                  />
                </div>

                <div className="bg-blue-500/10 border border-blue-500/20 rounded-xl p-4 flex items-start gap-3">
                  <CheckCircle2 className="text-blue-400 shrink-0 mt-0.5" size={18} />
                  <div className="space-y-1">
                    <p className="text-sm font-bold text-blue-200">گرنگی واژۆی ئەلیکترۆنی</p>
                    <p className="text-xs text-blue-300/80 leading-relaxed">
                      ئەم واژۆیە بەکاردێت بۆ واژۆکردنی نوسراوەکان و داواکارییەکان بە شێوەی ئەلیکترۆنی. تکایە دڵنیابەرەوە کە وێنەکە ڕوونە و پاشبنەمای (Background) نییە.
                    </p>
                  </div>
                </div>
              </div>
            </div>
          )}

        </div>
      </div>
    </div>
  );
};
