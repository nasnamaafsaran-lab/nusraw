import React, { useState } from 'react';
import { useApp } from '../context';
import { 
  Bell, Check, Info, AlertTriangle, XCircle, CheckCheck, 
  Filter, Clock, Calendar, Trash2, Eye, FileText, MessageSquare 
} from 'lucide-react';
import { Document } from '../types';

export const NotificationCenter: React.FC<{ onViewDoc: (doc: Document) => void }> = ({ onViewDoc }) => {
  const { notifications, currentUser, markNotificationAsRead, documents } = useApp();
  const [filter, setFilter] = useState<'all' | 'unread' | 'urgent' | 'system'>('all');

  if (!currentUser) return null;

  const myNotifications = notifications.filter(n => n.userId === currentUser.id).sort((a, b) => 
    new Date(b.timestamp).getTime() - new Date(a.timestamp).getTime()
  );

  const unreadCount = myNotifications.filter(n => !n.read).length;
  const urgentCount = myNotifications.filter(n => n.type === 'warning' || n.type === 'error').length;
  const systemCount = myNotifications.filter(n => n.type === 'info').length;

  const handleNotificationClick = (notif: typeof notifications[0]) => {
    markNotificationAsRead(notif.id);
    if (notif.docId) {
      const doc = documents.find(d => d.id === notif.docId);
      if (doc) {
        onViewDoc(doc);
      }
    }
  };

  const markAllAsRead = () => {
    myNotifications.forEach(n => {
      if (!n.read) markNotificationAsRead(n.id);
    });
  };

  const filteredNotifications = myNotifications.filter(n => {
    if (filter === 'unread') return !n.read;
    if (filter === 'urgent') return n.type === 'warning' || n.type === 'error';
    if (filter === 'system') return n.type === 'info';
    return true;
  });

  const formatTimeAgo = (dateString: string) => {
    const date = new Date(dateString);
    const now = new Date();
    const diffInSeconds = Math.floor((now.getTime() - date.getTime()) / 1000);

    if (diffInSeconds < 60) return 'کەمێک لەمەوبەر';
    if (diffInSeconds < 3600) return `${Math.floor(diffInSeconds / 60)} خولەک لەمەوبەر`;
    if (diffInSeconds < 86400) return `${Math.floor(diffInSeconds / 3600)} کاتژمێر لەمەوبەر`;
    return date.toLocaleDateString('en-US');
  };

  return (
    <div className="max-w-6xl mx-auto space-y-8" dir="rtl">
      {/* Header Section */}
      <div className="flex flex-col md:flex-row md:items-center justify-between gap-4">
        <div>
          <h2 className="text-3xl font-bold text-white flex items-center gap-3 neon-text mb-2">
            <div className="p-3 bg-blue-600/20 rounded-2xl border border-blue-500/30 shadow-[0_0_15px_rgba(59,130,246,0.3)]">
              <Bell className="text-blue-400" size={28} />
            </div>
            سەنتەری ئاگادارکردنەوەکان
          </h2>
          <p className="text-slate-400 mr-16">ئاگادارکردنەوەکان و چالاکییە نوێیەکان لێرە ببینە</p>
        </div>
        
        <div className="flex gap-3">
          {unreadCount > 0 && (
            <button 
              onClick={markAllAsRead}
              className="btn-vibrant-secondary flex items-center gap-2 px-4 py-2.5"
            >
              <CheckCheck size={18} />
              <span>دیاریکردنی هەمووی وەک خوێندراوە</span>
            </button>
          )}
        </div>
      </div>

      {/* Stats Cards */}
      <div className="grid grid-cols-1 md:grid-cols-4 gap-4">
        <div className="glass-panel p-5 rounded-2xl border border-white/10 relative overflow-hidden group">
          <div className="absolute top-0 left-0 w-full h-1 bg-blue-500/50"></div>
          <div className="flex justify-between items-start relative z-10">
            <div>
              <p className="text-slate-400 text-sm font-medium mb-1">گشتی</p>
              <h3 className="text-3xl font-bold text-white">{myNotifications.length}</h3>
            </div>
            <div className="p-3 bg-blue-500/10 rounded-xl text-blue-400 group-hover:scale-110 transition-transform">
              <Bell size={24} />
            </div>
          </div>
        </div>

        <div className="glass-panel p-5 rounded-2xl border border-white/10 relative overflow-hidden group">
          <div className="absolute top-0 left-0 w-full h-1 bg-red-500/50"></div>
          <div className="flex justify-between items-start relative z-10">
            <div>
              <p className="text-slate-400 text-sm font-medium mb-1">نەخوێندراوە</p>
              <h3 className="text-3xl font-bold text-white">{unreadCount}</h3>
            </div>
            <div className="p-3 bg-red-500/10 rounded-xl text-red-400 group-hover:scale-110 transition-transform">
              <div className="relative">
                <Bell size={24} />
                <div className="absolute top-0 right-0 w-2.5 h-2.5 bg-red-500 rounded-full border-2 border-[#0f172a]"></div>
              </div>
            </div>
          </div>
        </div>

        <div className="glass-panel p-5 rounded-2xl border border-white/10 relative overflow-hidden group">
          <div className="absolute top-0 left-0 w-full h-1 bg-amber-500/50"></div>
          <div className="flex justify-between items-start relative z-10">
            <div>
              <p className="text-slate-400 text-sm font-medium mb-1">بەپەلە</p>
              <h3 className="text-3xl font-bold text-white">{urgentCount}</h3>
            </div>
            <div className="p-3 bg-amber-500/10 rounded-xl text-amber-400 group-hover:scale-110 transition-transform">
              <AlertTriangle size={24} />
            </div>
          </div>
        </div>

        <div className="glass-panel p-5 rounded-2xl border border-white/10 relative overflow-hidden group">
          <div className="absolute top-0 left-0 w-full h-1 bg-emerald-500/50"></div>
          <div className="flex justify-between items-start relative z-10">
            <div>
              <p className="text-slate-400 text-sm font-medium mb-1">سیستەم</p>
              <h3 className="text-3xl font-bold text-white">{systemCount}</h3>
            </div>
            <div className="p-3 bg-emerald-500/10 rounded-xl text-emerald-400 group-hover:scale-110 transition-transform">
              <Info size={24} />
            </div>
          </div>
        </div>
      </div>

      {/* Main Content */}
      <div className="glass-panel rounded-3xl border border-white/10 overflow-hidden min-h-[500px] flex flex-col">
        {/* Filter Tabs */}
        <div className="border-b border-white/10 p-4 flex flex-wrap gap-2 bg-white/5">
          {[
            { id: 'all', label: 'هەمووی', icon: Filter },
            { id: 'unread', label: 'نەخوێندراوەکان', icon: Bell },
            { id: 'urgent', label: 'بەپەلەکان', icon: AlertTriangle },
            { id: 'system', label: 'سیستەم', icon: Info },
          ].map((tab) => (
            <button
              key={tab.id}
              onClick={() => setFilter(tab.id as any)}
              className={`flex items-center gap-2 px-5 py-2.5 rounded-xl text-sm font-medium transition-all duration-300 ${
                filter === tab.id 
                  ? 'btn-vibrant-primary shadow-[0_0_15px_rgba(37,99,235,0.4)] scale-105' 
                  : 'btn-vibrant-secondary text-slate-400 hover:text-white'
              }`}
            >
              <tab.icon size={16} />
              {tab.label}
            </button>
          ))}
        </div>

        {/* Notification List */}
        <div className="flex-1 overflow-y-auto custom-scrollbar p-4 space-y-3">
          {filteredNotifications.length === 0 ? (
            <div className="flex flex-col items-center justify-center h-full py-20 text-slate-400">
              <div className="w-24 h-24 bg-white/5 rounded-full flex items-center justify-center mb-6 animate-pulse">
                <Bell className="text-slate-600" size={48} />
              </div>
              <h3 className="text-xl font-bold text-white mb-2">هیچ ئاگادارکردنەوەیەک نییە</h3>
              <p className="text-slate-500">کاتێک ئاگادارکردنەوەیەکت بۆ دێت، لێرە دەردەکەوێت</p>
            </div>
          ) : (
            filteredNotifications.map((notif, index) => (
              <div 
                key={notif.id} 
                className={`group relative p-5 rounded-2xl border transition-all duration-300 hover:-translate-y-1 hover:shadow-lg ${
                  notif.read 
                    ? 'bg-white/5 border-white/5 hover:border-white/10' 
                    : 'bg-gradient-to-r from-blue-900/20 to-indigo-900/20 border-blue-500/30 hover:border-blue-500/50 shadow-[0_0_10px_rgba(59,130,246,0.1)]'
                }`}
                style={{ animationDelay: `${index * 50}ms` }}
              >
                <div className="flex items-start gap-5">
                  {/* Icon */}
                  <div className={`p-3 rounded-2xl flex-shrink-0 shadow-lg ${
                    notif.type === 'success' ? 'bg-gradient-to-br from-emerald-500 to-teal-600 text-white' :
                    notif.type === 'error' ? 'bg-gradient-to-br from-red-500 to-rose-600 text-white' :
                    notif.type === 'warning' ? 'bg-gradient-to-br from-amber-500 to-orange-600 text-white' :
                    'bg-gradient-to-br from-blue-500 to-indigo-600 text-white'
                  }`}>
                    {notif.type === 'success' ? <CheckCheck size={24} /> :
                     notif.type === 'error' ? <AlertTriangle size={24} /> :
                     notif.type === 'warning' ? <Clock size={24} /> :
                     <MessageSquare size={24} />}
                  </div>
                  
                  {/* Content */}
                  <div className="flex-1 min-w-0">
                    <div className="flex justify-between items-start mb-1">
                      <h4 className={`text-lg truncate pl-4 ${!notif.read ? 'font-bold text-white' : 'font-medium text-slate-300'}`}>
                        {notif.title || 'ئاگادارکردنەوەی نوێ'}
                      </h4>
                      <span className="text-xs font-mono text-slate-500 whitespace-nowrap flex items-center gap-1 bg-black/20 px-2 py-1 rounded-lg">
                        <Calendar size={12} />
                        {formatTimeAgo(notif.timestamp)}
                      </span>
                    </div>
                    
                    <p className={`text-sm leading-relaxed mb-4 ${!notif.read ? 'text-slate-200' : 'text-slate-400'}`}>
                      {notif.message}
                    </p>
                    
                    {/* Actions */}
                    <div className="flex items-center gap-3">
                      {notif.docId && (
                        <button 
                          onClick={() => handleNotificationClick(notif)}
                          className="btn-vibrant-secondary flex items-center gap-2 text-xs font-medium px-4 py-2"
                        >
                          <Eye size={14} />
                          بینینی نوسراو
                        </button>
                      )}
                      
                      {!notif.read && (
                        <button 
                          onClick={() => markNotificationAsRead(notif.id)}
                          className="btn-vibrant-secondary flex items-center gap-2 text-xs font-medium px-4 py-2"
                        >
                          <Check size={14} />
                          دیاریکردن وەک خوێندراوە
                        </button>
                      )}
                    </div>
                  </div>

                  {/* Unread Indicator */}
                  {!notif.read && (
                    <div className="absolute top-5 left-5 w-3 h-3 bg-blue-500 rounded-full shadow-[0_0_10px_rgba(59,130,246,0.8)] animate-pulse"></div>
                  )}
                </div>
              </div>
            ))
          )}
        </div>
      </div>
    </div>
  );
};
