import React, { useState, useRef } from 'react';
import { useApp } from '../context';
import { User, Search, Filter, Calendar, FileText, ExternalLink, X, Plus, Camera, Upload, Check, Printer } from 'lucide-react';
import { format } from 'date-fns';
import { motion, AnimatePresence } from 'framer-motion';
import { Document } from '../types';

export const HandDeliveryPanel: React.FC = () => {
  const { handDeliveryRecords, documents, handDeliverDocument, currentUser, uploadFiles } = useApp();
  const [searchTerm, setSearchTerm] = useState('');
  const [selectedRecord, setSelectedRecord] = useState<string | null>(null);
  const [showWizard, setShowWizard] = useState(false);
  const [showReportModal, setShowReportModal] = useState(false);

  // Wizard State
  const [wizardStep, setWizardStep] = useState(1);
  const [selectedDoc, setSelectedDoc] = useState<Document | null>(null);
  const [receiverName, setReceiverName] = useState('');
  const [receiverRank, setReceiverRank] = useState('');
  const [receiverPhone, setReceiverPhone] = useState('');
  const [receiverId, setReceiverId] = useState('');
  const [receiverDept, setReceiverDept] = useState('');
  const [notes, setNotes] = useState('');
  const [receiverPhoto, setReceiverPhoto] = useState<File | null>(null);
  const [docPhoto, setDocPhoto] = useState<File | null>(null);
  const [isSubmitting, setIsSubmitting] = useState(false);

  // Search for documents to deliver
  const [docSearchTerm, setDocSearchTerm] = useState('');
  const availableDocs = documents.filter(d => 
    (d.status === 'Approved' || d.status === 'Archived') && // Must be completed
    (d.referenceNumber.includes(docSearchTerm) || d.title.includes(docSearchTerm) || d.senderName.includes(docSearchTerm))
  );

  const filteredRecords = handDeliveryRecords.filter(record => {
    const doc = documents.find(d => d.id === record.documentId);
    const searchString = `${record.receiverName} ${record.receiverId} ${record.deliveredBy} ${doc?.title || ''} ${doc?.referenceNumber || ''}`.toLowerCase();
    return searchString.includes(searchTerm.toLowerCase());
  });

  const handleFileChange = (e: React.ChangeEvent<HTMLInputElement>, setFile: (f: File | null) => void) => {
    if (e.target.files && e.target.files[0]) {
      setFile(e.target.files[0]);
    }
  };

  const handleSubmit = async () => {
    if (!selectedDoc || !receiverName || !receiverRank || !receiverPhoto || !docPhoto || !currentUser) return;
    
    setIsSubmitting(true);
    try {
      // Upload photos
      const uploadedReceiver = await uploadFiles([receiverPhoto]);
      const uploadedDoc = await uploadFiles([docPhoto]);

      await handDeliverDocument(selectedDoc.id, {
        id: Math.random().toString(36).substr(2, 9),
        documentId: selectedDoc.id,
        receiverName,
        receiverId: receiverId || 'نییە',
        receiverDept: receiverDept || 'نییە',
        receiverRank,
        receiverPhone,
        receiverPhotoUrl: uploadedReceiver[0]?.url || '',
        documentPhotoUrl: uploadedDoc[0]?.url || '',
        deliveredBy: currentUser.name,
        timestamp: new Date().toISOString(),
        notes
      });

      setShowWizard(false);
      resetWizard();
    } catch (error) {
      console.error(error);
    } finally {
      setIsSubmitting(false);
    }
  };

  const resetWizard = () => {
    setWizardStep(1);
    setSelectedDoc(null);
    setReceiverName('');
    setReceiverRank('');
    setReceiverPhone('');
    setReceiverId('');
    setReceiverDept('');
    setNotes('');
    setReceiverPhoto(null);
    setDocPhoto(null);
    setDocSearchTerm('');
  };

  return (
    <div className="space-y-6" dir="rtl">
      <div className="flex items-center justify-between">
        <div>
          <h2 className="text-2xl font-bold text-white flex items-center gap-3 neon-text">
            <span className="p-2 bg-blue-500/20 rounded-lg text-blue-400 border border-blue-500/30">
              <User size={24} />
            </span>
            تۆماری زمە (ڕادەستکردن بە دەست)
          </h2>
          <p className="text-slate-400 mt-1">بەڕێوەبردنی نوسراوە ڕادەستکراوەکان بە دەست</p>
        </div>
        
        <div className="flex gap-3">
          <div className="relative">
            <Search className="absolute left-3 top-1/2 -translate-y-1/2 text-slate-400" size={20} />
            <input 
              type="text" 
              placeholder="گەڕان..." 
              value={searchTerm}
              onChange={e => setSearchTerm(e.target.value)}
              className="w-64 bg-black/20 border border-white/10 rounded-xl py-2 pl-10 pr-4 text-white focus:border-blue-500/50 outline-none transition-colors"
            />
          </div>
          <button 
            onClick={() => setShowReportModal(true)}
            className="flex items-center gap-2 bg-purple-600 hover:bg-purple-500 text-white px-4 py-2 rounded-xl transition-all shadow-lg shadow-purple-600/20"
          >
            <FileText size={20} />
            ڕاپۆرتی ڕۆژانە
          </button>
          <button 
            onClick={() => setShowWizard(true)}
            className="flex items-center gap-2 bg-blue-600 hover:bg-blue-500 text-white px-4 py-2 rounded-xl transition-all shadow-lg shadow-blue-600/20"
          >
            <Plus size={20} />
            زمەی نوێ
          </button>
        </div>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
        {filteredRecords.map((record, idx) => {
          const doc = documents.find(d => d.id === record.documentId);
          return (
            <motion.div
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ delay: idx * 0.05 }}
              key={record.id}
              className="glass-panel p-5 rounded-2xl border border-white/10 hover:border-blue-500/30 transition-all group relative overflow-hidden"
            >
              <div className="flex justify-between items-start mb-4">
                <div className="flex items-center gap-3">
                  <div className="w-12 h-12 rounded-full bg-blue-500/10 flex items-center justify-center text-blue-400 border border-blue-500/20 overflow-hidden">
                    {record.receiverPhotoUrl ? (
                        <img src={record.receiverPhotoUrl} className="w-full h-full object-cover" />
                    ) : <User size={24} />}
                  </div>
                  <div>
                    <h3 className="font-bold text-white">{record.receiverName}</h3>
                    <p className="text-xs text-slate-400">{record.receiverRank} - {record.receiverPhone}</p>
                  </div>
                </div>
                <span className="text-xs bg-white/5 px-2 py-1 rounded text-slate-400 border border-white/5 font-mono">
                  {format(new Date(record.timestamp), 'yyyy/MM/dd HH:mm')}
                </span>
              </div>

              <div className="bg-black/20 rounded-xl p-3 mb-4 border border-white/5">
                <div className="flex items-center gap-2 mb-1 text-slate-300 text-sm">
                  <FileText size={14} className="text-blue-400" />
                  <span className="font-medium truncate">{doc?.title || 'نوسراوی نەناسراو'}</span>
                </div>
                <p className="text-xs text-slate-500 font-mono mb-1">ژمارە: {doc?.referenceNumber}</p>
              </div>

              <div className="flex items-center justify-between text-xs text-slate-500 mt-2">
                <span>ڕادەستکار: <span className="text-slate-300">{record.deliveredBy}</span></span>
                <button 
                  onClick={() => setSelectedRecord(record.id)}
                  className="text-blue-400 hover:text-blue-300 flex items-center gap-1 transition-all hover:underline hover:shadow-[0_0_10px_rgba(59,130,246,0.2)] px-2 py-1 rounded"
                >
                  وردەکاری <ExternalLink size={12} />
                </button>
              </div>
            </motion.div>
          );
        })}
      </div>

      {/* Wizard Modal */}
      <AnimatePresence>
        {showWizard && (
          <motion.div 
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            exit={{ opacity: 0 }}
            className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/80 backdrop-blur-sm"
          >
            <motion.div 
              initial={{ scale: 0.95, opacity: 0 }}
              animate={{ scale: 1, opacity: 1 }}
              exit={{ scale: 0.95, opacity: 0 }}
              className="glass-panel w-full max-w-4xl max-h-[90vh] overflow-hidden rounded-2xl border border-white/10 shadow-2xl flex flex-col"
            >
              <div className="p-6 border-b border-white/10 flex justify-between items-center bg-white/5">
                <h3 className="text-xl font-bold text-white flex items-center gap-2">
                  <User className="text-blue-400" />
                  ڕادەستکردنی نوێ (زمە)
                </h3>
                <button onClick={() => { setShowWizard(false); resetWizard(); }} className="text-slate-400 hover:text-white">
                  <X size={24} />
                </button>
              </div>

              <div className="flex-1 overflow-y-auto p-6 custom-scrollbar">
                {/* Steps Indicator */}
                <div className="flex items-center justify-center mb-8">
                  {[1, 2, 3].map((step) => (
                    <div key={step} className="flex items-center">
                      <div className={`w-10 h-10 rounded-full flex items-center justify-center font-bold transition-all ${
                        wizardStep >= step ? 'bg-blue-600 text-white shadow-[0_0_15px_rgba(37,99,235,0.5)]' : 'bg-white/10 text-slate-500'
                      }`}>
                        {step}
                      </div>
                      {step < 3 && (
                        <div className={`w-20 h-1 mx-2 ${wizardStep > step ? 'bg-blue-600' : 'bg-white/10'}`}></div>
                      )}
                    </div>
                  ))}
                </div>

                {wizardStep === 1 && (
                  <div className="space-y-6">
                    <div className="text-center mb-6">
                      <h4 className="text-xl font-bold text-white mb-2">هەڵبژاردنی نوسراو</h4>
                      <p className="text-slate-400">تکایە نوسراوەکە هەڵبژێرە بەپێی ژمارە یان ناونیشان</p>
                    </div>

                    <div className="relative max-w-xl mx-auto mb-6">
                      <Search className="absolute left-4 top-1/2 -translate-y-1/2 text-slate-400" />
                      <input 
                        type="text" 
                        placeholder="گەڕان بەپێی ژمارەی نوسراو یان ناونیشان..." 
                        value={docSearchTerm}
                        onChange={e => setDocSearchTerm(e.target.value)}
                        className="w-full bg-black/30 border border-white/10 rounded-xl py-4 pl-12 pr-4 text-white focus:border-blue-500/50 outline-none text-lg"
                        autoFocus
                      />
                    </div>

                    <div className="grid gap-3 max-h-[400px] overflow-y-auto custom-scrollbar">
                      {availableDocs.map(doc => (
                        <div 
                          key={doc.id}
                          onClick={() => setSelectedDoc(doc)}
                          className={`p-4 rounded-xl border cursor-pointer transition-all flex items-center justify-between ${
                            selectedDoc?.id === doc.id 
                              ? 'bg-blue-600/20 border-blue-500 shadow-[0_0_15px_rgba(37,99,235,0.2)]' 
                              : 'bg-white/5 border-white/5 hover:bg-white/10'
                          }`}
                        >
                          <div>
                            <div className="flex items-center gap-2 mb-1">
                              <span className="bg-white/10 text-slate-300 text-xs px-2 py-0.5 rounded font-mono">
                                {doc.referenceNumber}
                              </span>
                              <h5 className="text-white font-bold">{doc.title}</h5>
                            </div>
                            <p className="text-slate-400 text-sm truncate max-w-md">{doc.content}</p>
                          </div>
                          {selectedDoc?.id === doc.id && <Check className="text-blue-400" />}
                        </div>
                      ))}
                      {availableDocs.length === 0 && (
                        <p className="text-center text-slate-500 py-8">هیچ نوسراوێکی تەواو بوو نەدۆزرایەوە</p>
                      )}
                    </div>
                  </div>
                )}

                {wizardStep === 2 && (
                  <div className="space-y-6 max-w-2xl mx-auto">
                    <div className="text-center mb-6">
                      <h4 className="text-xl font-bold text-white mb-2">زانیاری وەرگر</h4>
                      <p className="text-slate-400">تکایە زانیاری کەسی وەرگر پڕبکەرەوە</p>
                    </div>

                    <div className="grid grid-cols-2 gap-4">
                      <div className="col-span-2">
                        <label className="block text-slate-400 text-sm mb-2">ناوی سیانی وەرگر</label>
                        <input 
                          type="text" 
                          value={receiverName}
                          onChange={e => setReceiverName(e.target.value)}
                          className="w-full bg-black/30 border border-white/10 rounded-xl p-3 text-white focus:border-blue-500/50 outline-none"
                          placeholder="ناوی تەواو بنووسە"
                        />
                      </div>
                      <div>
                        <label className="block text-slate-400 text-sm mb-2">پلەی سەربازی</label>
                        <input 
                          type="text" 
                          value={receiverRank}
                          onChange={e => setReceiverRank(e.target.value)}
                          className="w-full bg-black/30 border border-white/10 rounded-xl p-3 text-white focus:border-blue-500/50 outline-none"
                          placeholder="نم: نەقیب"
                        />
                      </div>
                      <div>
                        <label className="block text-slate-400 text-sm mb-2">ژمارەی مۆبایل</label>
                        <input 
                          type="text" 
                          value={receiverPhone}
                          onChange={e => setReceiverPhone(e.target.value)}
                          className="w-full bg-black/30 border border-white/10 rounded-xl p-3 text-white focus:border-blue-500/50 outline-none"
                          placeholder="0750xxxxxxx"
                        />
                      </div>
                      <div>
                        <label className="block text-slate-400 text-sm mb-2">ژمارەی ناسنامە / سەربازی (ئارەزوومەندانە)</label>
                        <input 
                          type="text" 
                          value={receiverId}
                          onChange={e => setReceiverId(e.target.value)}
                          className="w-full bg-black/30 border border-white/10 rounded-xl p-3 text-white focus:border-blue-500/50 outline-none"
                        />
                      </div>
                      <div>
                        <label className="block text-slate-400 text-sm mb-2">بەش / شوێنی کار (ئارەزوومەندانە)</label>
                        <input 
                          type="text" 
                          value={receiverDept}
                          onChange={e => setReceiverDept(e.target.value)}
                          className="w-full bg-black/30 border border-white/10 rounded-xl p-3 text-white focus:border-blue-500/50 outline-none"
                        />
                      </div>
                      <div className="col-span-2">
                        <label className="block text-slate-400 text-sm mb-2">تێبینی</label>
                        <textarea 
                          value={notes}
                          onChange={e => setNotes(e.target.value)}
                          className="w-full bg-black/30 border border-white/10 rounded-xl p-3 text-white focus:border-blue-500/50 outline-none h-24 resize-none"
                        />
                      </div>
                    </div>
                  </div>
                )}

                {wizardStep === 3 && (
                  <div className="space-y-6 max-w-3xl mx-auto">
                    <div className="text-center mb-6">
                      <h4 className="text-xl font-bold text-white mb-2">وێنە و بەڵگەکان</h4>
                      <p className="text-slate-400">تکایە وێنەی وەرگر و نوسراوەکە بگرە</p>
                    </div>

                    <div className="grid grid-cols-1 md:grid-cols-2 gap-8">
                      {/* Receiver Photo */}
                      <div className="space-y-4">
                        <div className="text-center">
                          <h5 className="text-white font-bold mb-1">وێنەی وەرگر</h5>
                          <p className="text-xs text-slate-500">وێنەی ڕوخساری وەرگر بگرە</p>
                        </div>
                        <div className="aspect-square bg-black/30 rounded-2xl border-2 border-dashed border-white/20 flex flex-col items-center justify-center relative overflow-hidden group hover:border-blue-500/50 transition-colors">
                          {receiverPhoto ? (
                            <>
                              <img src={URL.createObjectURL(receiverPhoto)} className="w-full h-full object-cover" />
                              <button 
                                onClick={() => setReceiverPhoto(null)}
                                className="absolute inset-0 bg-black/60 flex items-center justify-center opacity-0 group-hover:opacity-100 transition-opacity"
                              >
                                <X className="text-white" size={32} />
                              </button>
                            </>
                          ) : (
                            <>
                              <Camera className="text-slate-500 mb-2" size={48} />
                              <label className="cursor-pointer bg-blue-600 hover:bg-blue-500 text-white px-4 py-2 rounded-lg text-sm transition-colors">
                                هەڵبژاردنی وێنە
                                <input type="file" accept="image/*" className="hidden" onChange={e => handleFileChange(e, setReceiverPhoto)} />
                              </label>
                            </>
                          )}
                        </div>
                      </div>

                      {/* Document Photo */}
                      <div className="space-y-4">
                        <div className="text-center">
                          <h5 className="text-white font-bold mb-1">وێنەی نوسراو</h5>
                          <p className="text-xs text-slate-500">وێنەی نوسراوەکە بگرە دوای چاپکردن</p>
                        </div>
                        <div className="aspect-square bg-black/30 rounded-2xl border-2 border-dashed border-white/20 flex flex-col items-center justify-center relative overflow-hidden group hover:border-blue-500/50 transition-colors">
                          {docPhoto ? (
                            <>
                              <img src={URL.createObjectURL(docPhoto)} className="w-full h-full object-cover" />
                              <button 
                                onClick={() => setDocPhoto(null)}
                                className="absolute inset-0 bg-black/60 flex items-center justify-center opacity-0 group-hover:opacity-100 transition-opacity"
                              >
                                <X className="text-white" size={32} />
                              </button>
                            </>
                          ) : (
                            <>
                              <FileText className="text-slate-500 mb-2" size={48} />
                              <label className="cursor-pointer bg-blue-600 hover:bg-blue-500 text-white px-4 py-2 rounded-lg text-sm transition-colors">
                                هەڵبژاردنی وێنە
                                <input type="file" accept="image/*" className="hidden" onChange={e => handleFileChange(e, setDocPhoto)} />
                              </label>
                            </>
                          )}
                        </div>
                      </div>
                    </div>
                  </div>
                )}
              </div>

              <div className="p-6 border-t border-white/10 bg-white/5 flex justify-between items-center">
                <button 
                  onClick={() => setWizardStep(prev => Math.max(1, prev - 1))}
                  disabled={wizardStep === 1}
                  className={`px-6 py-2 rounded-xl text-sm font-medium transition-colors ${
                    wizardStep === 1 ? 'text-slate-600 cursor-not-allowed' : 'text-white hover:bg-white/10'
                  }`}
                >
                  گەڕانەوە
                </button>

                {wizardStep < 3 ? (
                  <button 
                    onClick={() => setWizardStep(prev => prev + 1)}
                    disabled={
                      (wizardStep === 1 && !selectedDoc) ||
                      (wizardStep === 2 && (!receiverName || !receiverRank || !receiverPhone))
                    }
                    className="bg-blue-600 hover:bg-blue-500 disabled:bg-slate-700 disabled:text-slate-500 text-white px-8 py-2 rounded-xl transition-all shadow-lg shadow-blue-600/20 disabled:shadow-none"
                  >
                    دواتر
                  </button>
                ) : (
                  <button 
                    onClick={handleSubmit}
                    disabled={!receiverPhoto || !docPhoto || isSubmitting}
                    className="bg-emerald-600 hover:bg-emerald-500 disabled:bg-slate-700 disabled:text-slate-500 text-white px-8 py-2 rounded-xl transition-all shadow-lg shadow-emerald-600/20 disabled:shadow-none flex items-center gap-2"
                  >
                    {isSubmitting ? 'جێبەجێکردن...' : 'پەسەندکردن و زمەکردن'}
                    {!isSubmitting && <Check size={18} />}
                  </button>
                )}
              </div>
            </motion.div>
          </motion.div>
        )}

        {/* Report Modal */}
        <AnimatePresence>
          {showReportModal && (
            <motion.div 
              initial={{ opacity: 0 }}
              animate={{ opacity: 1 }}
              exit={{ opacity: 0 }}
              className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/80 backdrop-blur-sm"
            >
              <motion.div 
                initial={{ scale: 0.95, opacity: 0 }}
                animate={{ scale: 1, opacity: 1 }}
                exit={{ scale: 0.95, opacity: 0 }}
                className="glass-panel w-full max-w-4xl max-h-[90vh] overflow-hidden rounded-2xl border border-white/10 shadow-2xl flex flex-col"
              >
                <div className="p-6 border-b border-white/10 flex justify-between items-center bg-white/5">
                  <h3 className="text-xl font-bold text-white flex items-center gap-2">
                    <FileText className="text-purple-400" />
                    ڕاپۆرتی ڕۆژانەی زمە
                  </h3>
                  <button onClick={() => setShowReportModal(false)} className="text-slate-400 hover:text-white">
                    <X size={24} />
                  </button>
                </div>

                <div className="flex-1 overflow-y-auto p-6 custom-scrollbar">
                  {/* Report Content */}
                  {(() => {
                    const today = new Date();
                    const todayRecords = handDeliveryRecords.filter(r => {
                      const recordDate = new Date(r.timestamp);
                      return recordDate.getDate() === today.getDate() &&
                             recordDate.getMonth() === today.getMonth() &&
                             recordDate.getFullYear() === today.getFullYear();
                    });

                    return (
                      <div className="space-y-6">
                        <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
                          <div className="bg-white/5 p-4 rounded-xl border border-white/10 text-center">
                            <h4 className="text-slate-400 text-sm mb-1">کۆی گشتی ئەمڕۆ</h4>
                            <p className="text-3xl font-bold text-white">{todayRecords.length}</p>
                          </div>
                          <div className="bg-white/5 p-4 rounded-xl border border-white/10 text-center">
                            <h4 className="text-slate-400 text-sm mb-1">بەروار</h4>
                            <p className="text-xl font-bold text-white font-mono">{format(today, 'yyyy/MM/dd')}</p>
                          </div>
                          <div className="bg-white/5 p-4 rounded-xl border border-white/10 text-center">
                            <h4 className="text-slate-400 text-sm mb-1">ڕادەستکار</h4>
                            <p className="text-xl font-bold text-white">{currentUser?.name}</p>
                          </div>
                        </div>

                        <div className="overflow-x-auto">
                          <table className="w-full text-right border-collapse">
                            <thead>
                              <tr className="border-b border-white/10 text-slate-400 text-sm">
                                <th className="p-3">#</th>
                                <th className="p-3">وەرگر</th>
                                <th className="p-3">نوسراو</th>
                                <th className="p-3">کات</th>
                                <th className="p-3">تێبینی</th>
                              </tr>
                            </thead>
                            <tbody className="text-slate-300 text-sm">
                              {todayRecords.map((record, idx) => {
                                const doc = documents.find(d => d.id === record.documentId);
                                return (
                                  <tr key={record.id} className="border-b border-white/5 hover:bg-white/5">
                                    <td className="p-3">{idx + 1}</td>
                                    <td className="p-3">
                                      <div className="font-bold text-white">{record.receiverName}</div>
                                      <div className="text-xs text-slate-500">{record.receiverRank}</div>
                                    </td>
                                    <td className="p-3">
                                      <div className="text-white">{doc?.title || 'نەناسراو'}</div>
                                      <div className="text-xs text-slate-500 font-mono">{doc?.referenceNumber}</div>
                                    </td>
                                    <td className="p-3 font-mono">{format(new Date(record.timestamp), 'HH:mm')}</td>
                                    <td className="p-3 text-xs italic">{record.notes || '-'}</td>
                                  </tr>
                                );
                              })}
                              {todayRecords.length === 0 && (
                                <tr>
                                  <td colSpan={5} className="p-8 text-center text-slate-500">
                                    هیچ تۆمارێک بۆ ئەمڕۆ نییە
                                  </td>
                                </tr>
                              )}
                            </tbody>
                          </table>
                        </div>
                      </div>
                    );
                  })()}
                </div>

                <div className="p-6 border-t border-white/10 bg-white/5 flex justify-end">
                  <button 
                    onClick={() => window.print()}
                    className="flex items-center gap-2 bg-blue-600 hover:bg-blue-500 text-white px-6 py-2 rounded-xl transition-all shadow-lg shadow-blue-600/20"
                  >
                    <Printer size={20} />
                    چاپکردن
                  </button>
                </div>
              </motion.div>
            </motion.div>
          )}
        </AnimatePresence>

        {/* Detail Modal */}
        {selectedRecord && (
          <motion.div 
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            exit={{ opacity: 0 }}
            className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/80 backdrop-blur-sm"
            onClick={() => setSelectedRecord(null)}
          >
            <motion.div 
              initial={{ scale: 0.9, opacity: 0 }}
              animate={{ scale: 1, opacity: 1 }}
              exit={{ scale: 0.9, opacity: 0 }}
              onClick={e => e.stopPropagation()}
              className="glass-panel w-full max-w-3xl max-h-[90vh] overflow-y-auto rounded-2xl border border-white/10 shadow-2xl custom-scrollbar"
            >
              {(() => {
                const record = handDeliveryRecords.find(r => r.id === selectedRecord);
                if (!record) return null;
                const doc = documents.find(d => d.id === record.documentId);

                return (
                  <div>
                    <div className="p-6 border-b border-white/10 flex justify-between items-center sticky top-0 bg-black/80 backdrop-blur-xl z-10">
                      <h3 className="text-xl font-bold text-white flex items-center gap-2">
                        <User className="text-blue-400" />
                        وردەکاری ڕادەستکردن
                      </h3>
                      <button onClick={() => setSelectedRecord(null)} className="text-slate-400 hover:text-white p-2 hover:bg-white/10 rounded-full transition-all hover:shadow-[0_0_10px_rgba(255,255,255,0.1)]">
                        <X size={24} />
                      </button>
                    </div>

                    <div className="p-6 space-y-8">
                      {/* Receiver Info */}
                      <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                        <div className="space-y-4">
                          <h4 className="text-sm font-bold text-slate-400 uppercase tracking-wider border-b border-white/10 pb-2">زانیاری وەرگر</h4>
                          <div className="space-y-3">
                            <div>
                              <label className="text-xs text-slate-500 block">ناوی سیانی</label>
                              <p className="text-white font-medium text-lg">{record.receiverName}</p>
                            </div>
                            <div>
                              <label className="text-xs text-slate-500 block">پلە و ژمارەی مۆبایل</label>
                              <p className="text-white font-mono">{record.receiverRank || 'نییە'} - {record.receiverPhone || 'نییە'}</p>
                            </div>
                            <div>
                              <label className="text-xs text-slate-500 block">بەش / شوێنی کار</label>
                              <p className="text-white">{record.receiverDept || 'نییە'}</p>
                            </div>
                          </div>
                        </div>

                        <div className="space-y-4">
                          <h4 className="text-sm font-bold text-slate-400 uppercase tracking-wider border-b border-white/10 pb-2">زانیاری ڕادەستکردن</h4>
                          <div className="space-y-3">
                            <div>
                              <label className="text-xs text-slate-500 block">ڕادەستکار</label>
                              <p className="text-white font-medium">{record.deliveredBy}</p>
                            </div>
                            <div>
                              <label className="text-xs text-slate-500 block">کات و بەروار</label>
                              <p className="text-white font-mono">{format(new Date(record.timestamp), 'yyyy/MM/dd - HH:mm:ss')}</p>
                            </div>
                            <div>
                              <label className="text-xs text-slate-500 block">تێبینی</label>
                              <p className="text-slate-300 italic">{record.notes || 'نییە'}</p>
                            </div>
                          </div>
                        </div>
                      </div>

                      {/* Document Info */}
                      <div>
                        <h4 className="text-sm font-bold text-slate-400 uppercase tracking-wider border-b border-white/10 pb-2 mb-4">زانیاری نوسراو</h4>
                        <div className="bg-white/5 rounded-xl p-4 border border-white/10">
                          <div className="flex justify-between mb-2">
                             <h5 className="text-white font-bold">{doc?.title || 'نوسراوی نەناسراو'}</h5>
                             <span className="font-mono text-xs bg-white/10 px-2 py-1 rounded text-slate-300">{doc?.referenceNumber}</span>
                          </div>
                          <p className="text-slate-400 text-sm leading-relaxed">{doc?.content}</p>
                        </div>
                      </div>

                      {/* Photos */}
                      <div>
                        <h4 className="text-sm font-bold text-slate-400 uppercase tracking-wider border-b border-white/10 pb-2 mb-4">وێنەکان</h4>
                        <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                          <div className="space-y-2">
                            <label className="text-sm text-slate-400 block text-center">وێنەی وەرگر</label>
                            <div className="aspect-square rounded-xl overflow-hidden border-2 border-white/10 bg-black/40">
                              <img src={record.receiverPhotoUrl} alt="Receiver" className="w-full h-full object-cover" />
                            </div>
                          </div>
                          <div className="space-y-2">
                            <label className="text-sm text-slate-400 block text-center">وێنەی نوسراو</label>
                            <div className="aspect-square rounded-xl overflow-hidden border-2 border-white/10 bg-black/40">
                              <img src={record.documentPhotoUrl} alt="Document" className="w-full h-full object-cover" />
                            </div>
                          </div>
                        </div>
                      </div>
                    </div>
                  </div>
                );
              })()}
            </motion.div>
          </motion.div>
        )}
      </AnimatePresence>
    </div>
  );
};
