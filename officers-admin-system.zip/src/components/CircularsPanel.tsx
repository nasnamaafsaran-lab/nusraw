import React, { useState } from 'react';
import { useApp } from '../context';
import { FileText, Plus, Eye, Clock, AlertCircle, Paperclip, XCircle, File } from 'lucide-react';
import { format } from 'date-fns';
import { motion } from 'framer-motion';

export const CircularsPanel: React.FC = () => {
  const { documents, createDocument, currentUser, uploadFiles } = useApp();
  const [showCreateModal, setShowCreateModal] = useState(false);
  const [selectedCircular, setSelectedCircular] = useState<any>(null);
  const [newCircular, setNewCircular] = useState({ 
    title: '', 
    content: '',
    incomingNumber: '',
    incomingDate: '',
    source: ''
  });
  const [selectedFiles, setSelectedFiles] = useState<File[]>([]);
  const [loading, setLoading] = useState(false);

  // Filter and sort circulars (newest first)
  const circulars = documents
    .filter(doc => doc.isCircular)
    .sort((a, b) => new Date(b.createdAt).getTime() - new Date(a.createdAt).getTime());

  const handleFileChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    if (e.target.files && e.target.files.length > 0) {
      setSelectedFiles(prev => [...prev, ...Array.from(e.target.files!)]);
    }
  };

  const removeFile = (index: number) => {
    setSelectedFiles(prev => prev.filter((_, i) => i !== index));
  };

  const handleCreate = async () => {
      if (!newCircular.title || !newCircular.content) return;
      
      setLoading(true);
      try {
        const uploadedAttachments = await uploadFiles(selectedFiles);

        await createDocument(
            newCircular.title,
            newCircular.content,
            'ALL', // Special target ID for broadcast
            uploadedAttachments,
            'Normal',
            'Normal',
            true,
            newCircular.incomingNumber,
            newCircular.incomingDate,
            newCircular.source
        );
        setShowCreateModal(false);
        setNewCircular({ title: '', content: '', incomingNumber: '', incomingDate: '', source: '' });
        setSelectedFiles([]);
      } catch (error) {
        console.error('Failed to create circular', error);
      } finally {
        setLoading(false);
      }
  };

  const canCreateCircular = currentUser?.role === 'super_admin' || currentUser?.role === 'dispatch_staff';

  return (
    <div className="space-y-6">
      <div className="flex items-center justify-between">
        <div>
          <h2 className="text-2xl font-bold text-white flex items-center gap-3">
            <span className="p-2 bg-amber-500/20 rounded-lg text-amber-400 border border-amber-500/30">
              <FileText size={24} />
            </span>
            گشتاندنەکان
          </h2>
          <p className="text-slate-400 mt-1">ئاگاداری و ڕینماییە گشتییەکان بۆ هەموو بەشەکان</p>
        </div>
        
        {canCreateCircular && (
            <button 
            onClick={() => setShowCreateModal(true)}
            className="bg-gradient-to-r from-amber-600 to-orange-600 hover:from-amber-500 hover:to-orange-500 text-white px-6 py-3 rounded-xl flex items-center gap-2 font-bold shadow-[0_0_20px_rgba(245,158,11,0.4)] transition-all hover:-translate-y-1 border border-white/10"
            >
            <Plus size={20} />
            گشتاندنی نوێ
            </button>
        )}
      </div>

      <div className="bg-black/20 border border-white/10 rounded-2xl overflow-hidden">
        {/* Header Row */}
        <div className="hidden lg:grid grid-cols-12 gap-4 px-6 py-4 bg-white/5 border-b border-white/10 text-sm font-bold text-slate-400">
          <div className="col-span-1">ژمارەی نوسراو</div>
          <div className="col-span-1">بەرواری نوسراو</div>
          <div className="col-span-2">لەکوێوە هاتووە</div>
          <div className="col-span-2">نێردەر</div>
          <div className="col-span-1">بەرواری ناردن</div>
          <div className="col-span-4">ناوەڕۆک</div>
          <div className="col-span-1 text-center">کردارەکان</div>
        </div>

        {/* Data Rows */}
        <div className="divide-y divide-white/5">
          {circulars.map((doc, idx) => (
            <motion.div
              initial={{ opacity: 0, y: 10 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ delay: idx * 0.05 }}
              key={doc.id}
              className="grid grid-cols-1 lg:grid-cols-12 gap-4 px-6 py-4 items-center hover:bg-white/5 transition-colors group"
            >
              {/* Mobile Labels (hidden on lg) */}
              <div className="lg:hidden flex justify-between items-center mb-2">
                <span className="text-xs text-slate-500 font-bold">ژمارەی نوسراو:</span>
                <span className="text-sm font-mono text-amber-400">{doc.incomingNumber || doc.referenceNumber}</span>
              </div>
              <div className="hidden lg:block col-span-1 text-sm font-mono text-amber-400">
                {doc.incomingNumber || doc.referenceNumber}
              </div>

              <div className="lg:hidden flex justify-between items-center mb-2">
                <span className="text-xs text-slate-500 font-bold">بەرواری نوسراو:</span>
                <span className="text-sm text-slate-300">{doc.incomingDate || '-'}</span>
              </div>
              <div className="hidden lg:block col-span-1 text-sm text-slate-300">
                {doc.incomingDate || '-'}
              </div>

              <div className="lg:hidden flex justify-between items-center mb-2">
                <span className="text-xs text-slate-500 font-bold">لەکوێوە هاتووە:</span>
                <span className="text-sm text-slate-300">{doc.source || '-'}</span>
              </div>
              <div className="hidden lg:block col-span-2 text-sm text-slate-300 truncate">
                {doc.source || '-'}
              </div>

              <div className="lg:hidden flex justify-between items-center mb-2">
                <span className="text-xs text-slate-500 font-bold">نێردەر:</span>
                <span className="text-sm text-slate-300">{doc.senderName}</span>
              </div>
              <div className="hidden lg:block col-span-2 text-sm text-slate-300 truncate">
                {doc.senderName}
              </div>

              <div className="lg:hidden flex justify-between items-center mb-2">
                <span className="text-xs text-slate-500 font-bold">بەرواری ناردن:</span>
                <span className="text-sm text-slate-300">{format(new Date(doc.createdAt), 'yyyy/MM/dd')}</span>
              </div>
              <div className="hidden lg:block col-span-1 text-sm text-slate-300">
                {format(new Date(doc.createdAt), 'yyyy/MM/dd')}
              </div>

              <div className="lg:hidden flex flex-col mb-4">
                <span className="text-xs text-slate-500 font-bold mb-1">ناوەڕۆک:</span>
                <span className="text-sm text-slate-400 line-clamp-2">{doc.content}</span>
              </div>
              <div className="hidden lg:block col-span-4 text-sm text-slate-400 line-clamp-2">
                {doc.content}
              </div>

              <div className="col-span-1 flex justify-end lg:justify-center mt-2 lg:mt-0">
                <button 
                    onClick={() => setSelectedCircular(doc)}
                    className="w-full lg:w-auto px-4 py-2 bg-white/5 hover:bg-amber-500/20 text-slate-300 hover:text-amber-400 rounded-lg transition-all text-sm font-medium flex items-center justify-center gap-2 hover:shadow-[0_0_10px_rgba(245,158,11,0.2)] border border-white/5 hover:border-amber-500/30"
                >
                    <Eye size={16} />
                    <span className="lg:hidden">بینینی وردەکاری</span>
                </button>
              </div>
            </motion.div>
          ))}

          {circulars.length === 0 && (
              <div className="flex flex-col items-center justify-center py-20 text-slate-500">
                  <div className="w-20 h-20 bg-white/5 rounded-full flex items-center justify-center mb-4">
                      <AlertCircle size={40} />
                  </div>
                  <p>هیچ گشتاندنێک نییە</p>
              </div>
          )}
        </div>
      </div>

      {/* View Modal */}
      {selectedCircular && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/60 backdrop-blur-sm overflow-y-auto">
          <div className="glass-panel w-full max-w-3xl p-8 rounded-2xl border border-amber-500/30 shadow-[0_0_50px_rgba(245,158,11,0.1)] max-h-[90vh] overflow-y-auto custom-scrollbar relative my-8">
            <div className="flex justify-between items-start mb-6 sticky top-0 bg-black/80 backdrop-blur-xl py-2 z-10 border-b border-white/10">
                <h3 className="text-xl font-bold text-white flex items-center gap-2">
                    <FileText className="text-amber-400" />
                    وردەکاری گشتاندن
                </h3>
                <button 
                    onClick={() => setSelectedCircular(null)}
                    className="text-slate-400 hover:text-white bg-white/5 hover:bg-white/10 p-2 rounded-lg transition-colors"
                >
                    <XCircle size={24} />
                </button>
            </div>
            
            <div className="space-y-6">
                <div className="bg-white/5 border border-white/10 rounded-xl p-6">
                    <h4 className="text-2xl font-bold text-white mb-4">{selectedCircular.title}</h4>
                    
                    <div className="grid grid-cols-2 md:grid-cols-4 gap-4 mb-6 text-sm">
                        <div className="bg-black/20 p-3 rounded-lg border border-white/5">
                            <span className="block text-slate-500 mb-1">ژمارەی نوسراو</span>
                            <span className="text-amber-400 font-mono">{selectedCircular.incomingNumber || selectedCircular.referenceNumber}</span>
                        </div>
                        <div className="bg-black/20 p-3 rounded-lg border border-white/5">
                            <span className="block text-slate-500 mb-1">بەرواری نوسراو</span>
                            <span className="text-slate-300">{selectedCircular.incomingDate || format(new Date(selectedCircular.createdAt), 'yyyy/MM/dd')}</span>
                        </div>
                        <div className="bg-black/20 p-3 rounded-lg border border-white/5">
                            <span className="block text-slate-500 mb-1">لەکوێوە هاتووە</span>
                            <span className="text-slate-300">{selectedCircular.source || selectedCircular.senderDepartment}</span>
                        </div>
                        <div className="bg-black/20 p-3 rounded-lg border border-white/5">
                            <span className="block text-slate-500 mb-1">نێرەر</span>
                            <span className="text-slate-300">{selectedCircular.senderName}</span>
                        </div>
                    </div>

                    <div className="prose prose-invert max-w-none">
                        <p className="text-slate-300 leading-relaxed whitespace-pre-wrap">
                            {selectedCircular.content}
                        </p>
                    </div>
                </div>

                {selectedCircular.attachments && selectedCircular.attachments.length > 0 && (
                    <div>
                        <h5 className="text-lg font-bold text-white mb-4 flex items-center gap-2">
                            <Paperclip className="text-amber-400" size={20} />
                            هاوپێچەکان ({selectedCircular.attachments.length})
                        </h5>
                        <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                            {selectedCircular.attachments.map((att: any) => (
                                <a 
                                    key={att.id} 
                                    href={att.url} 
                                    download={att.name}
                                    className="flex items-center gap-3 bg-white/5 hover:bg-white/10 p-4 rounded-xl border border-white/10 transition-all hover:-translate-y-1 hover:shadow-[0_0_15px_rgba(255,255,255,0.05)] group"
                                >
                                    <div className={`w-10 h-10 rounded-lg flex items-center justify-center flex-shrink-0 ${
                                        att.type === 'pdf' ? 'bg-red-500/20 text-red-400' :
                                        att.type === 'word' ? 'bg-blue-500/20 text-blue-400' :
                                        att.type === 'excel' ? 'bg-green-500/20 text-green-400' :
                                        'bg-slate-500/20 text-slate-400'
                                    }`}>
                                        <File size={20} />
                                    </div>
                                    <div className="flex-1 min-w-0">
                                        <p className="text-sm font-medium text-slate-200 truncate group-hover:text-amber-400 transition-colors">{att.name}</p>
                                        <p className="text-xs text-slate-500 uppercase">{att.type}</p>
                                    </div>
                                </a>
                            ))}
                        </div>
                    </div>
                )}
            </div>
          </div>
        </div>
      )}

      {/* Create Modal */}
      {showCreateModal && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/60 backdrop-blur-sm overflow-y-auto">
          <div className="glass-panel w-full max-w-2xl p-8 rounded-2xl border border-amber-500/30 shadow-[0_0_50px_rgba(245,158,11,0.1)] max-h-[90vh] overflow-y-auto custom-scrollbar relative my-8">
            <h3 className="text-xl font-bold text-white mb-6 flex items-center gap-2 sticky top-0 bg-black/80 backdrop-blur-xl py-2 z-10">
                <Plus className="text-amber-400" />
                زیادکردنی گشتاندن
            </h3>
            
            <div className="space-y-6">
                <div>
                    <label className="block text-sm text-slate-400 mb-2 font-bold">ناونیشان</label>
                    <input 
                        type="text" 
                        value={newCircular.title}
                        onChange={e => setNewCircular({...newCircular, title: e.target.value})}
                        className="w-full bg-black/20 border border-white/10 rounded-xl p-3 text-white focus:border-amber-500/50 outline-none transition-colors"
                        placeholder="ناونیشانی گشتاندن..."
                    />
                </div>

                <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
                    <div>
                        <label className="block text-sm text-slate-400 mb-2 font-bold">ژمارەی نوسراو</label>
                        <input 
                            type="text" 
                            value={newCircular.incomingNumber}
                            onChange={e => setNewCircular({...newCircular, incomingNumber: e.target.value})}
                            className="w-full bg-black/20 border border-white/10 rounded-xl p-3 text-white focus:border-amber-500/50 outline-none transition-colors"
                            placeholder="ژمارەی نوسراو..."
                        />
                    </div>
                    <div>
                        <label className="block text-sm text-slate-400 mb-2 font-bold">بەرواری نوسراو</label>
                        <input 
                            type="date" 
                            value={newCircular.incomingDate}
                            onChange={e => setNewCircular({...newCircular, incomingDate: e.target.value})}
                            className="w-full bg-black/20 border border-white/10 rounded-xl p-3 text-white focus:border-amber-500/50 outline-none transition-colors"
                        />
                    </div>
                    <div>
                        <label className="block text-sm text-slate-400 mb-2 font-bold">لەکوێوە هاتووە</label>
                        <input 
                            type="text" 
                            value={newCircular.source}
                            onChange={e => setNewCircular({...newCircular, source: e.target.value})}
                            className="w-full bg-black/20 border border-white/10 rounded-xl p-3 text-white focus:border-amber-500/50 outline-none transition-colors"
                            placeholder="ناوی فەرمانگە یان لایەن..."
                        />
                    </div>
                </div>

                <div>
                    <label className="block text-sm text-slate-400 mb-2 font-bold">ناوەڕۆک</label>
                    <textarea 
                        value={newCircular.content}
                        onChange={e => setNewCircular({...newCircular, content: e.target.value})}
                        className="w-full bg-black/20 border border-white/10 rounded-xl p-3 text-white focus:border-amber-500/50 outline-none transition-colors h-40 resize-none"
                        placeholder="دەقی گشتاندن..."
                    />
                </div>

                {/* File Upload Section */}
                <div>
                  <label className="block text-sm font-bold text-slate-300 mb-2">هاوپێچەکان</label>
                  <div className="border-2 border-dashed border-white/20 rounded-2xl p-6 hover:bg-white/5 transition-colors text-center group cursor-pointer relative bg-white/5">
                    <input type="file" className="absolute inset-0 w-full h-full opacity-0 cursor-pointer" onChange={handleFileChange} multiple accept=".doc,.docx,.xls,.xlsx,.pdf,.jpg,.png" />
                    <div className="w-12 h-12 bg-amber-500/10 text-amber-400 rounded-full flex items-center justify-center mx-auto mb-3 group-hover:scale-110 transition-transform shadow-[0_0_20px_rgba(245,158,11,0.3)]">
                      <Paperclip size={24} />
                    </div>
                    <p className="text-slate-300 font-bold">کلیک بکە یان فایلەکە ڕابکێشە</p>
                    <p className="text-xs text-slate-500 mt-1">Word, Excel, PDF</p>
                  </div>

                  {selectedFiles.length > 0 && (
                    <div className="mt-4 space-y-2">
                      {selectedFiles.map((file, index) => {
                        let type = 'other';
                        if (file.name.endsWith('.pdf')) type = 'pdf';
                        else if (file.name.match(/\.(doc|docx)$/)) type = 'word';
                        else if (file.name.match(/\.(xls|xlsx)$/)) type = 'excel';
                        
                        return (
                          <div key={index} className="flex items-center justify-between bg-white/5 p-3 rounded-xl border border-white/10">
                            <div className="flex items-center gap-3">
                              <div className={`w-8 h-8 rounded-lg flex items-center justify-center flex-shrink-0 ${
                                type === 'pdf' ? 'bg-red-500/20 text-red-400' :
                                type === 'word' ? 'bg-blue-500/20 text-blue-400' :
                                type === 'excel' ? 'bg-green-500/20 text-green-400' :
                                'bg-slate-500/20 text-slate-400'
                              }`}>
                                <File size={16} />
                              </div>
                              <span className="text-sm text-slate-200 truncate max-w-[200px]">{file.name}</span>
                            </div>
                            <button onClick={() => removeFile(index)} className="text-red-400 hover:bg-red-500/10 p-1.5 rounded-lg transition-all hover:shadow-[0_0_10px_rgba(239,68,68,0.2)]">
                              <XCircle size={18} />
                            </button>
                          </div>
                        );
                      })}
                    </div>
                  )}
                </div>
            </div>

            <div className="flex justify-end gap-3 mt-8 pt-4 border-t border-white/10 sticky bottom-0 bg-black/80 backdrop-blur-xl pb-2 z-10">
                <button 
                    onClick={() => setShowCreateModal(false)}
                    disabled={loading}
                    className="px-6 py-2 rounded-xl hover:bg-white/10 text-slate-300 transition-all disabled:opacity-50 hover:text-white hover:shadow-[0_0_15px_rgba(255,255,255,0.05)] border border-transparent hover:border-white/10"
                >
                    پاشگەزبوونەوە
                </button>
                <button 
                    onClick={handleCreate}
                    disabled={loading}
                    className="px-6 py-2 rounded-xl bg-gradient-to-r from-amber-600 to-orange-600 hover:from-amber-500 hover:to-orange-500 text-white font-bold shadow-[0_0_20px_rgba(245,158,11,0.4)] transition-all disabled:opacity-50 flex items-center gap-2 hover:-translate-y-0.5 border border-white/10"
                >
                    {loading ? 'جێبەجێکردن...' : 'بڵاوکردنەوە'}
                </button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
};
