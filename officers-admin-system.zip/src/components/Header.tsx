import React from 'react';
import { useApp } from '../context';
import { Search, Bell, User, Settings, LogOut } from 'lucide-react';

export const Header: React.FC<{ onSearchClick: () => void, onNotificationClick: () => void, onProfileClick: () => void }> = ({ onSearchClick, onNotificationClick, onProfileClick }) => {
  const { currentUser, notifications, logout } = useApp();
  const unreadCount = notifications.filter(n => n.userId === currentUser?.id && !n.read).length;

  return (
    <header className="h-16 glass-panel border-b border-white/10 sticky top-0 z-20 px-6 flex items-center justify-between shadow-[0_4px_30px_rgba(0,0,0,0.1)] print:hidden rounded-none bg-white/5 backdrop-blur-md">
      {/* Search Bar */}
      <div className="flex-1 max-w-xl">
        <div 
          onClick={onSearchClick}
          className="relative group cursor-pointer"
        >
          <div className="absolute inset-y-0 right-0 pr-3 flex items-center pointer-events-none">
            <Search className="h-4 w-4 text-slate-400 group-hover:text-blue-400 transition-colors duration-150 ease-out" />
          </div>
          <input
            type="text"
            readOnly
            className="block w-full pr-10 pl-4 py-2 rounded-xl bg-white/5 border border-white/10 text-sm text-slate-200 placeholder-slate-400 focus:border-blue-500/50 focus:ring-1 focus:ring-blue-500/50 outline-none cursor-pointer transition-all duration-150 ease-out shadow-inner"
            placeholder="گەڕان بۆ نوسراو، ئەرشیف..."
          />
          <div className="absolute inset-y-0 left-0 pl-2 flex items-center pointer-events-none">
            <span className="text-[10px] font-bold text-slate-400 border border-white/10 rounded px-1.5 py-0.5 bg-white/5 backdrop-blur-sm">⌘K</span>
          </div>
        </div>
      </div>

      {/* Right Actions */}
      <div className="flex items-center gap-4 mr-8">
        {/* Notifications */}
        <button 
          onClick={onNotificationClick}
          className="relative p-2 rounded-xl text-slate-300 hover:bg-white/10 hover:text-white transition-all duration-150 ease-out border border-transparent hover:border-white/10"
        >
          <Bell className="h-5 w-5" />
          {unreadCount > 0 && (
            <span className="absolute top-1.5 left-1.5 h-2.5 w-2.5 rounded-full bg-red-500 ring-2 ring-slate-900 shadow-[0_0_10px_rgba(239,68,68,0.8)] animate-pulse" />
          )}
        </button>

        {/* User Profile */}
        <div className="flex items-center gap-3 pl-4 border-l border-white/10">
          <div className="text-left hidden md:block">
            <p className="text-sm font-semibold text-white tracking-wide">{currentUser?.name}</p>
            <p className="text-[10px] text-blue-300 font-medium uppercase tracking-wider opacity-80">{currentUser?.title}</p>
          </div>
          <div className="relative group">
            <button 
              onClick={onProfileClick}
              className="h-10 w-10 rounded-xl bg-gradient-to-br from-blue-500 to-indigo-600 flex items-center justify-center text-white hover:from-blue-400 hover:to-indigo-500 transition-all duration-150 ease-out shadow-[0_0_15px_rgba(59,130,246,0.3)] border border-white/20 hover:scale-105"
            >
              <User className="h-5 w-5" />
            </button>
            
            {/* Dropdown */}
            <div className="absolute top-full left-0 mt-3 w-56 glass-panel rounded-xl shadow-[0_10px_40px_rgba(0,0,0,0.5)] border border-white/10 py-1 opacity-0 invisible group-hover:opacity-100 group-hover:visible transition-all duration-150 ease-out transform origin-top-right z-50 translate-y-2 group-hover:translate-y-0">
              <div className="px-4 py-3 border-b border-white/10 bg-white/5">
                <p className="text-sm font-bold text-white">هەژماری بەکارهێنەر</p>
                <p className="text-xs text-blue-300 mt-1 opacity-80">{currentUser?.role}</p>
              </div>
              <div className="p-2 space-y-1">
                <button 
                  onClick={onProfileClick}
                  className="w-full text-right px-3 py-2 text-sm text-slate-200 hover:bg-white/10 hover:text-white rounded-lg flex items-center gap-2 transition-all duration-150 ease-out"
                >
                  <User size={16} className="text-blue-400" />
                  پڕۆفایل
                </button>
                <button 
                  onClick={logout}
                  className="w-full text-right px-3 py-2 text-sm text-red-400 hover:bg-red-500/20 hover:text-red-300 rounded-lg flex items-center gap-2 transition-all duration-150 ease-out border border-transparent hover:border-red-500/30"
                >
                  <LogOut size={16} />
                  چوونەدەرەوە
                </button>
              </div>
            </div>
          </div>
        </div>
      </div>
    </header>
  );
};
