import React, { useState } from 'react';
import { useApp } from '../context';
import { Search, Plus, Wrench, Building2, X, Check, Network, ArrowRight, Trash2, Edit2, List, Settings2 } from 'lucide-react';
import { DepartmentInfo, WorkflowTemplate, WorkflowStep, Role } from '../types';
import { translations, getRoleLabel } from '../translations';

const ROLES: { id: Role; label: string }[] = Object.entries(translations.role).map(([id, label]) => ({
  id: id as Role,
  label
}));

export const WorkflowTemplateManager: React.FC<{ onClose: () => void }> = ({ onClose }) => {
  const { workflowTemplates, addWorkflowTemplate, updateWorkflowTemplate, deleteWorkflowTemplate, currentUser } = useApp();
  const [editingTemplate, setEditingTemplate] = useState<WorkflowTemplate | null>(null);
  const [showForm, setShowForm] = useState(false);
  
  // Form State
  const [name, setName] = useState('');
  const [description, setDescription] = useState('');
  const [steps, setSteps] = useState<WorkflowStep[]>([]);

  const handleAddStep = () => {
    const newStep: WorkflowStep = {
      id: Math.random().toString(36).substr(2, 9),
      label: 'قۆناغی نوێ',
      role: 'employee'
    };
    setSteps([...steps, newStep]);
  };

  const updateStep = (id: string, updates: Partial<WorkflowStep>) => {
    setSteps(steps.map(s => s.id === id ? { ...s, ...updates } : s));
  };

  const removeStep = (id: string) => {
    setSteps(steps.filter(s => s.id !== id));
  };

  const handleSave = async () => {
    if (!name || steps.length === 0) return;

    const templateData: WorkflowTemplate = {
      id: editingTemplate?.id || Math.random().toString(36).substr(2, 9),
      name,
      description,
      steps,
      createdBy: currentUser?.name || 'نەناسراو',
      createdAt: editingTemplate?.createdAt || new Date().toISOString()
    };

    if (editingTemplate) {
      await updateWorkflowTemplate(templateData);
    } else {
      await addWorkflowTemplate(templateData);
    }
    
    resetForm();
  };

  const resetForm = () => {
    setEditingTemplate(null);
    setName('');
    setDescription('');
    setSteps([]);
    setShowForm(false);
  };

  const handleEdit = (template: WorkflowTemplate) => {
    setEditingTemplate(template);
    setName(template.name);
    setDescription(template.description || '');
    setSteps(template.steps);
    setShowForm(true);
  };

  return (
    <div className="fixed inset-0 bg-black/80 backdrop-blur-md z-[60] flex items-center justify-center p-4 animate-in fade-in duration-200">
      <div className="glass-panel rounded-3xl w-full max-w-5xl h-[85vh] shadow-2xl overflow-hidden animate-in zoom-in-95 duration-200 flex flex-col border border-white/10">
        <div className="p-6 border-b border-white/10 flex justify-between items-center bg-white/5">
          <div className="flex items-center gap-4">
            <div className="w-12 h-12 rounded-2xl flex items-center justify-center text-white shadow-lg border border-white/20 bg-indigo-600">
              <Settings2 size={24} />
            </div>
            <div>
              <h2 className="text-2xl font-bold text-white neon-text">بەڕێوەبردنی ڕەوتەکانی کار</h2>
              <p className="text-slate-400">دروستکردن و دەستکاریکردنی قاڵبی ڕەوتی کارەکان</p>
            </div>
          </div>
          <button onClick={onClose} className="p-2 hover:bg-white/10 rounded-full transition-all hover:shadow-[0_0_10px_rgba(255,255,255,0.1)]">
            <X size={24} className="text-slate-400 hover:text-white" />
          </button>
        </div>

        <div className="flex-1 overflow-hidden flex">
          {/* List Section */}
          <div className="w-1/3 border-l border-white/10 p-6 overflow-y-auto custom-scrollbar bg-black/20">
            <div className="flex items-center justify-between mb-6">
              <h3 className="text-lg font-bold text-white flex items-center gap-2">
                <List size={20} className="text-indigo-400" />
                قاڵبەکان
              </h3>
              <button 
                onClick={() => { resetForm(); setShowForm(true); }}
                className="p-2 bg-indigo-600 hover:bg-indigo-500 text-white rounded-lg transition-all"
              >
                <Plus size={18} />
              </button>
            </div>
            
            <div className="space-y-3">
              {workflowTemplates.map(t => (
                <div 
                  key={t.id}
                  className={`p-4 rounded-xl border transition-all group cursor-pointer ${
                    editingTemplate?.id === t.id ? 'bg-indigo-600/20 border-indigo-500' : 'bg-white/5 border-white/10 hover:bg-white/10'
                  }`}
                  onClick={() => handleEdit(t)}
                >
                  <div className="flex justify-between items-start mb-2">
                    <h4 className="font-bold text-white">{t.name}</h4>
                    <button 
                      onClick={(e) => { e.stopPropagation(); deleteWorkflowTemplate(t.id); }}
                      className="p-1.5 text-slate-500 hover:text-red-400 opacity-0 group-hover:opacity-100 transition-all"
                    >
                      <Trash2 size={14} />
                    </button>
                  </div>
                  <p className="text-xs text-slate-500 line-clamp-2 mb-3">{t.description}</p>
                  <div className="flex items-center gap-2">
                    <span className="text-[10px] font-bold bg-white/5 px-2 py-0.5 rounded text-slate-400 border border-white/5">
                      {t.steps.length} قۆناغ
                    </span>
                  </div>
                </div>
              ))}
            </div>
          </div>

          {/* Form Section */}
          <div className="flex-1 p-8 overflow-y-auto custom-scrollbar bg-slate-900/50">
            {showForm ? (
              <div className="space-y-8 animate-in slide-in-from-left-4 duration-300">
                <div className="grid grid-cols-2 gap-6">
                  <div className="space-y-2">
                    <label className="text-sm font-bold text-slate-400">ناوی قاڵب</label>
                    <input 
                      value={name}
                      onChange={e => setName(e.target.value)}
                      className="w-full bg-black/40 border border-white/10 rounded-xl px-4 py-3 text-white outline-none focus:border-indigo-500 transition-all"
                      placeholder="بۆ نموونە: ڕەوتی کاری مۆڵەت"
                    />
                  </div>
                  <div className="space-y-2">
                    <label className="text-sm font-bold text-slate-400">وەسف (ئارەزوومەندانە)</label>
                    <input 
                      value={description}
                      onChange={e => setDescription(e.target.value)}
                      className="w-full bg-black/40 border border-white/10 rounded-xl px-4 py-3 text-white outline-none focus:border-indigo-500 transition-all"
                      placeholder="کورتەیەک دەربارەی ئەم ڕەوتە..."
                    />
                  </div>
                </div>

                <div className="space-y-4">
                  <div className="flex items-center justify-between">
                    <h3 className="text-lg font-bold text-white flex items-center gap-2">
                      <Network size={20} className="text-indigo-400" />
                      هەنگاوەکانی ڕەوتی کار
                    </h3>
                    <button 
                      onClick={handleAddStep}
                      className="flex items-center gap-2 px-4 py-2 bg-indigo-600/20 text-indigo-400 border border-indigo-500/30 rounded-xl hover:bg-indigo-600/30 transition-all text-sm font-bold hover:shadow-[0_0_10px_rgba(99,102,241,0.2)]"
                    >
                      <Plus size={16} />
                      زیادکردنی هەنگاو
                    </button>
                  </div>

                  <div className="space-y-4">
                    {steps.map((step, index) => (
                      <div key={step.id} className="flex items-center gap-4 bg-white/5 p-4 rounded-2xl border border-white/10 group animate-in slide-in-from-top-2 duration-200">
                        <div className="w-8 h-8 rounded-full bg-indigo-600 text-white flex items-center justify-center font-bold text-sm shrink-0">
                          {index + 1}
                        </div>
                        
                        <div className="flex-1 grid grid-cols-2 gap-4">
                          <input 
                            value={step.label}
                            onChange={e => updateStep(step.id, { label: e.target.value })}
                            className="bg-black/20 border border-white/10 rounded-lg px-3 py-2 text-sm text-white outline-none focus:border-indigo-500"
                            placeholder="ناوی هەنگاو..."
                          />
                          <select
                            value={step.role}
                            onChange={e => updateStep(step.id, { role: e.target.value as Role })}
                            className="bg-black/20 border border-white/10 rounded-lg px-3 py-2 text-sm text-white outline-none focus:border-indigo-500"
                          >
                            {ROLES.map(r => (
                              <option key={r.id} value={r.id} className="bg-slate-900">{r.label}</option>
                            ))}
                          </select>
                        </div>

                        <button 
                          onClick={() => removeStep(step.id)}
                          className="p-2 text-slate-500 hover:text-red-400 transition-all hover:bg-red-500/10 rounded-lg"
                        >
                          <Trash2 size={18} />
                        </button>
                      </div>
                    ))}

                    {steps.length === 0 && (
                      <div className="text-center py-12 border-2 border-dashed border-white/5 rounded-3xl text-slate-500">
                        <Network size={48} className="mx-auto mb-4 opacity-20" />
                        <p>هیچ هەنگاوێک زیاد نەکراوە</p>
                      </div>
                    )}
                  </div>
                </div>

                <div className="flex gap-4 pt-6 border-t border-white/10">
                  <button 
                    onClick={handleSave}
                    className="flex-1 bg-gradient-to-r from-indigo-600 to-indigo-500 hover:from-indigo-500 hover:to-indigo-400 text-white py-4 rounded-2xl font-bold shadow-[0_10px_20px_rgba(79,70,229,0.3)] hover:shadow-[0_15px_30px_rgba(79,70,229,0.4)] transition-all hover:-translate-y-1 border border-white/10"
                  >
                    {editingTemplate ? 'نوێکردنەوەی قاڵب' : 'پاشەکەوتکردنی قاڵب'}
                  </button>
                  <button 
                    onClick={resetForm}
                    className="flex-1 bg-white/5 hover:bg-white/10 text-slate-300 py-4 rounded-2xl font-bold border border-white/10 transition-all hover:text-white hover:shadow-[0_0_15px_rgba(255,255,255,0.05)]"
                  >
                    پاشگەزبوونەوە
                  </button>
                </div>
              </div>
            ) : (
              <div className="h-full flex flex-col items-center justify-center text-slate-500 opacity-50">
                <Settings2 size={80} className="mb-6" />
                <p className="text-xl font-bold">قاڵبێک هەڵبژێرە یان دانەیەکی نوێ دروست بکە</p>
              </div>
            )}
          </div>
        </div>
      </div>
    </div>
  );
};

export const DepartmentCenter: React.FC = () => {
  const { departments, addDepartment, updateDepartment } = useApp();
  const [searchTerm, setSearchTerm] = useState('');
  const [showAddModal, setShowAddModal] = useState(false);
  const [showConnectionsModal, setShowConnectionsModal] = useState(false);
  const [showWorkflowBuilder, setShowWorkflowBuilder] = useState(false);
  const [showWorkflowTemplateManager, setShowWorkflowTemplateManager] = useState(false);
  const [workflowSourceId, setWorkflowSourceId] = useState('');
  const [selectedDept, setSelectedDept] = useState<DepartmentInfo | null>(null);

  // Add Modal State
  const [newDeptId, setNewDeptId] = useState('');
  const [newDeptName, setNewDeptName] = useState('');

  const [editingDept, setEditingDept] = useState<DepartmentInfo | null>(null);

  const filteredDepartments = departments.filter(dept => 
    dept.name.toLowerCase().includes(searchTerm.toLowerCase()) ||
    dept.id.toLowerCase().includes(searchTerm.toLowerCase())
  );

  const handleSaveDepartment = () => {
    if (!newDeptId || !newDeptName) return;
    
    if (editingDept) {
      updateDepartment({
        ...editingDept,
        name: newDeptName,
      });
    } else {
      addDepartment({
        id: newDeptId,
        name: newDeptName,
        type: 'department', // Default type
      });
    }
    
    closeModal();
  };

  const openAddModal = () => {
    setEditingDept(null);
    setNewDeptId('');
    setNewDeptName('');
    setShowAddModal(true);
  };

  const openEditModal = (dept: DepartmentInfo) => {
    setEditingDept(dept);
    setNewDeptId(dept.id);
    setNewDeptName(dept.name);
    setShowAddModal(true);
  };

  const closeModal = () => {
    setShowAddModal(false);
    setEditingDept(null);
    setNewDeptId('');
    setNewDeptName('');
  };

  const toggleConnection = (targetDeptId: string) => {
    if (!selectedDept) return;
    
    const currentDestinations = selectedDept.allowedDestinations || [];
    let newDestinations;
    
    if (currentDestinations.includes(targetDeptId)) {
      newDestinations = currentDestinations.filter(id => id !== targetDeptId);
    } else {
      newDestinations = [...currentDestinations, targetDeptId];
    }
    
    const updatedDept = { ...selectedDept, allowedDestinations: newDestinations };
    updateDepartment(updatedDept);
    setSelectedDept(updatedDept); // Update local state to reflect changes immediately in modal
  };

  const openConnectionsModal = (dept: DepartmentInfo) => {
    setSelectedDept(dept);
    setShowConnectionsModal(true);
  };

  return (
    <div className="space-y-8" dir="rtl">
      {/* Header Section */}
      <div className="text-center space-y-2">
        <h1 className="text-3xl font-black text-white neon-text">سەنتەری ژوورەکان</h1>
        <p className="text-slate-400 text-lg">بەڕێوەبردن و ئاڵوگۆڕی نوسراو لەنێوان بەشەکان</p>
      </div>

      {/* Actions Bar */}
      <div className="flex flex-col md:flex-row gap-4 items-center justify-between glass-panel p-4 rounded-2xl shadow-2xl border border-white/10">
        <div className="relative w-full md:w-96">
          <Search className="absolute right-4 top-3.5 text-slate-400" size={20} />
          <input
            type="text"
            placeholder="گەڕان بەدوای بەش..."
            className="w-full pr-12 pl-4 py-3 rounded-xl bg-white/5 border border-white/10 focus:border-blue-500/50 focus:ring-2 focus:ring-blue-500/20 outline-none transition-all text-white placeholder:text-slate-500"
            value={searchTerm}
            onChange={(e) => setSearchTerm(e.target.value)}
          />
        </div>
        
        <div className="flex gap-3 w-full md:w-auto">
          <button 
            onClick={() => setShowWorkflowTemplateManager(true)}
            className="flex-1 md:flex-none flex items-center justify-center gap-2 bg-gradient-to-r from-indigo-600 to-purple-600 hover:from-indigo-500 hover:to-purple-500 text-white px-6 py-3 rounded-xl font-bold transition-all shadow-[0_0_20px_rgba(79,70,229,0.4)] hover:shadow-[0_0_30px_rgba(79,70,229,0.5)] hover:-translate-y-0.5 border border-white/10"
          >
            <Settings2 size={20} />
            <span>قاڵبەکانی ڕەوتی کار</span>
          </button>
          <button 
            onClick={() => setShowWorkflowBuilder(true)}
            className="flex-1 md:flex-none flex items-center justify-center gap-2 bg-gradient-to-r from-purple-600 to-blue-600 hover:from-purple-500 hover:to-blue-500 text-white px-6 py-3 rounded-xl font-bold transition-all shadow-[0_0_20px_rgba(147,51,234,0.4)] hover:shadow-[0_0_30px_rgba(147,51,234,0.5)] hover:-translate-y-0.5 border border-white/10"
          >
            <Network size={20} />
            <span>ڕێکخستنی ڕەوتی کار</span>
          </button>
          <button 
            onClick={openAddModal}
            className="flex-1 md:flex-none flex items-center justify-center gap-2 bg-gradient-to-r from-orange-500 to-red-500 hover:from-orange-400 hover:to-red-400 text-white px-6 py-3 rounded-xl font-bold transition-all shadow-[0_0_20px_rgba(249,115,22,0.4)] hover:shadow-[0_0_30px_rgba(249,115,22,0.5)] hover:-translate-y-0.5 border border-white/10"
          >
            <Plus size={20} />
            <span>زیادکردنی ژوور</span>
          </button>
        </div>
      </div>

      {/* Departments Grid */}
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4 gap-6">
        {filteredDepartments.map(dept => (
          <div key={dept.id} className="group glass-panel rounded-3xl p-6 relative overflow-hidden hover:shadow-[0_0_30px_rgba(59,130,246,0.3)] transition-all duration-300 hover:-translate-y-1 cursor-pointer border border-white/10">
            {/* Background Gradient */}
            <div 
              className="absolute inset-0 opacity-20 transition-opacity group-hover:opacity-30"
              style={{ background: `linear-gradient(135deg, #3b82f6 0%, transparent 100%)` }}
            />
            
            <div className="relative z-10 flex flex-col items-center text-center space-y-4">
              <div 
                className="w-16 h-16 rounded-2xl flex items-center justify-center shadow-lg mb-2 backdrop-blur-md border border-white/20"
                style={{ backgroundColor: 'rgba(255,255,255,0.1)' }}
              >
                <Building2 className="text-white drop-shadow-[0_0_8px_rgba(255,255,255,0.5)]" size={32} />
              </div>
              
              <h3 className="text-xl font-bold text-white neon-text">{dept.name}</h3>
              <p className="text-slate-400 text-sm font-mono uppercase tracking-wider">{dept.id}</p>
              
              <div className="pt-4 w-full flex gap-2">
                <button 
                  onClick={(e) => { e.stopPropagation(); openEditModal(dept); }}
                  className="flex-1 py-2 rounded-lg bg-white/5 hover:bg-white/10 text-white text-sm font-medium transition-all flex items-center justify-center gap-2 border border-white/10 hover:shadow-[0_0_10px_rgba(255,255,255,0.1)] hover:-translate-y-0.5"
                  title="Edit Department"
                >
                  <Wrench size={16} />
                  <span>دەستکاری</span>
                </button>
                <button 
                  onClick={(e) => { e.stopPropagation(); openConnectionsModal(dept); }}
                  className="flex-1 py-2 rounded-lg bg-white/5 hover:bg-white/10 text-white text-sm font-medium transition-all flex items-center justify-center gap-2 border border-white/10 hover:shadow-[0_0_10px_rgba(255,255,255,0.1)] hover:-translate-y-0.5"
                  title="Manage Connections"
                >
                  <Network size={16} />
                  <span>پەیوەندی</span>
                </button>
              </div>
            </div>
          </div>
        ))}
      </div>

      {/* Connections Modal */}
      {showConnectionsModal && selectedDept && (
        <div className="fixed inset-0 bg-black/80 backdrop-blur-md z-50 flex items-center justify-center p-4 animate-in fade-in duration-200">
          <div className="glass-panel rounded-3xl w-full max-w-4xl shadow-2xl overflow-hidden animate-in zoom-in-95 duration-200 flex flex-col max-h-[90vh] border border-white/10">
            <div className="p-6 border-b border-white/10 flex justify-between items-center bg-white/5 backdrop-blur-md">
              <div className="flex items-center gap-4">
                <div className="w-12 h-12 rounded-2xl flex items-center justify-center text-white shadow-lg border border-white/20" style={{ backgroundColor: '#3b82f6' }}>
                  <Network size={24} />
                </div>
                <div>
                  <h2 className="text-2xl font-bold text-white neon-text">ڕێکخستنی پەیوەندییەکان</h2>
                  <p className="text-slate-400">دیاری بکە {selectedDept.name} دەتوانێت نوسراو بۆ کێ بنێرێت</p>
                </div>
              </div>
              <button onClick={() => setShowConnectionsModal(false)} className="p-2 hover:bg-white/10 rounded-full transition-all hover:shadow-[0_0_10px_rgba(255,255,255,0.1)]">
                <X size={24} className="text-slate-400 hover:text-white" />
              </button>
            </div>

            <div className="p-6 overflow-y-auto custom-scrollbar flex-1">
              <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
                {departments.filter(d => d.id !== selectedDept.id).map(dept => {
                  const isConnected = selectedDept.allowedDestinations?.includes(dept.id);
                  return (
                    <div 
                      key={dept.id}
                      onClick={() => toggleConnection(dept.id)}
                      className={`
                        relative p-4 rounded-xl border cursor-pointer transition-all duration-200 flex items-center gap-4
                        ${isConnected 
                          ? 'border-emerald-500/50 bg-emerald-500/10 shadow-[0_0_15px_rgba(16,185,129,0.2)]' 
                          : 'border-white/10 bg-white/5 hover:border-white/30 hover:bg-white/10'}
                      `}
                    >
                      <div 
                        className={`w-6 h-6 rounded-full border-2 flex items-center justify-center transition-colors ${isConnected ? 'border-emerald-500 bg-emerald-500 text-white' : 'border-slate-500 bg-transparent'}`}
                      >
                        {isConnected && <Check size={14} strokeWidth={3} />}
                      </div>
                      
                      <div className="flex-1">
                        <h4 className={`font-bold ${isConnected ? 'text-emerald-400' : 'text-slate-300'}`}>{dept.name}</h4>
                        <p className="text-xs text-slate-500 font-mono">{dept.id}</p>
                      </div>

                      {isConnected && (
                        <div className="absolute top-4 left-4 text-emerald-500">
                          <ArrowRight size={16} />
                        </div>
                      )}
                    </div>
                  );
                })}
              </div>
            </div>

            <div className="p-6 border-t border-white/10 bg-white/5 flex justify-end backdrop-blur-md">
              <button
                onClick={() => setShowConnectionsModal(false)}
                className="px-8 py-3 rounded-xl bg-gradient-to-r from-blue-600 to-indigo-600 text-white font-bold hover:from-blue-500 hover:to-indigo-500 shadow-[0_0_20px_rgba(59,130,246,0.4)] transition-all hover:-translate-y-0.5 border border-white/10"
              >
                تەواو
              </button>
            </div>
          </div>
        </div>
      )}

      {/* Workflow Builder Modal */}
      {showWorkflowBuilder && (
        <div className="fixed inset-0 bg-black/80 backdrop-blur-md z-50 flex items-center justify-center p-4 animate-in fade-in duration-200">
          <div className="glass-panel rounded-3xl w-full max-w-6xl h-[90vh] shadow-2xl overflow-hidden animate-in zoom-in-95 duration-200 flex flex-col border border-white/10">
            {/* Header */}
            <div className="p-6 border-b border-white/10 flex justify-between items-center bg-white/5 backdrop-blur-md">
              <div className="flex items-center gap-4">
                <div className="w-12 h-12 rounded-2xl flex items-center justify-center text-white shadow-lg border border-white/20 bg-purple-600">
                  <Network size={24} />
                </div>
                <div>
                  <h2 className="text-2xl font-bold text-white neon-text">ڕێکخستنی ڕەوتی کار (Workflow Builder)</h2>
                  <p className="text-slate-400">دیاری بکە هەر بەشێک دەتوانێت نوسراو بۆ کێ بنێرێت</p>
                </div>
              </div>
              <button onClick={() => setShowWorkflowBuilder(false)} className="p-2 hover:bg-white/10 rounded-full transition-all hover:shadow-[0_0_10px_rgba(255,255,255,0.1)]">
                <X size={24} className="text-slate-400 hover:text-white" />
              </button>
            </div>

            {/* Content */}
            <div className="flex flex-1 overflow-hidden">
              {/* Sidebar: Select Source */}
              <div className="w-1/3 border-l border-white/10 bg-white/5 p-6 overflow-y-auto custom-scrollbar">
                <h3 className="text-lg font-bold text-white mb-4 flex items-center gap-2">
                  <Building2 size={20} className="text-purple-400" />
                  بەشی نێرەر
                </h3>
                <div className="space-y-2">
                  {departments.map(dept => (
                    <button
                      key={dept.id}
                      onClick={() => setWorkflowSourceId(dept.id)}
                      className={`w-full text-right p-4 rounded-xl border transition-all duration-200 flex items-center justify-between group ${
                        workflowSourceId === dept.id 
                          ? 'bg-purple-600 text-white border-purple-500 shadow-[0_0_15px_rgba(147,51,234,0.3)]' 
                          : 'bg-white/5 text-slate-300 border-white/10 hover:bg-white/10'
                      }`}
                    >
                      <span className="font-bold">{dept.name}</span>
                      {workflowSourceId === dept.id && <Check size={16} />}
                    </button>
                  ))}
                </div>
              </div>

              {/* Main: Select Destinations */}
              <div className="flex-1 p-6 overflow-y-auto custom-scrollbar bg-slate-900/50">
                {workflowSourceId ? (
                  <>
                    <div className="flex items-center justify-between mb-6">
                      <h3 className="text-lg font-bold text-white flex items-center gap-2">
                        <ArrowRight size={20} className="text-emerald-400" />
                        دەتوانێت بنێرێت بۆ
                      </h3>
                      <span className="text-sm text-slate-400 bg-white/5 px-3 py-1 rounded-full border border-white/10">
                        {departments.find(d => d.id === workflowSourceId)?.name}
                      </span>
                    </div>

                    <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                      {departments.filter(d => d.id !== workflowSourceId).map(targetDept => {
                        const sourceDept = departments.find(d => d.id === workflowSourceId);
                        const isConnected = sourceDept?.allowedDestinations?.includes(targetDept.id);

                        return (
                          <div 
                            key={targetDept.id}
                            onClick={() => {
                              if (!sourceDept) return;
                              const current = sourceDept.allowedDestinations || [];
                              const updated = current.includes(targetDept.id)
                                ? current.filter(id => id !== targetDept.id)
                                : [...current, targetDept.id];
                              updateDepartment({ ...sourceDept, allowedDestinations: updated });
                            }}
                            className={`
                              relative p-4 rounded-xl border cursor-pointer transition-all duration-200 flex items-center gap-4 group
                              ${isConnected 
                                ? 'border-emerald-500/50 bg-emerald-500/10 shadow-[0_0_15px_rgba(16,185,129,0.2)]' 
                                : 'border-white/10 bg-white/5 hover:border-white/30 hover:bg-white/10'}
                            `}
                          >
                            <div 
                              className={`w-6 h-6 rounded-lg border-2 flex items-center justify-center transition-colors ${isConnected ? 'border-emerald-500 bg-emerald-500 text-white' : 'border-slate-600 bg-transparent group-hover:border-slate-400'}`}
                            >
                              {isConnected && <Check size={14} strokeWidth={3} />}
                            </div>
                            
                            <div className="flex-1">
                              <h4 className={`font-bold ${isConnected ? 'text-emerald-400' : 'text-slate-300'}`}>{targetDept.name}</h4>
                              <p className="text-xs text-slate-500 font-mono">{targetDept.id}</p>
                            </div>
                          </div>
                        );
                      })}
                    </div>
                  </>
                ) : (
                  <div className="h-full flex flex-col items-center justify-center text-slate-500 opacity-50">
                    <Network size={64} className="mb-4" />
                    <p className="text-xl font-bold">تکایە سەرەتا بەشی نێرەر دیاری بکە</p>
                  </div>
                )}
              </div>
            </div>
          </div>
        </div>
      )}

      {/* Workflow Template Manager Modal */}
      {showWorkflowTemplateManager && (
        <WorkflowTemplateManager onClose={() => setShowWorkflowTemplateManager(false)} />
      )}

      {/* Add Department Modal */}
      {showAddModal && (
        <div className="fixed inset-0 bg-black/80 backdrop-blur-md z-50 flex items-center justify-center p-4 animate-in fade-in duration-200">
          <div className="glass-panel rounded-3xl w-full max-w-lg shadow-2xl overflow-hidden animate-in zoom-in-95 duration-200 border border-white/10">
            <div className="p-8">
              <div className="flex items-center gap-4 mb-8">
                <div className="w-12 h-12 bg-orange-500/20 rounded-2xl flex items-center justify-center text-orange-400 shadow-[0_0_15px_rgba(249,115,22,0.3)] border border-orange-500/30">
                  <Building2 size={24} />
                </div>
                <h2 className="text-2xl font-bold text-white neon-text">
                  {editingDept ? 'دەستکاری ژوور' : 'زیادکردنی ژووری نوێ'}
                </h2>
              </div>

              <div className="space-y-6">
                <div>
                  <label className="block text-sm font-bold text-slate-300 mb-2 text-right">کۆدی ژوور</label>
                  <input
                    type="text"
                    value={newDeptId}
                    onChange={(e) => setNewDeptId(e.target.value)}
                    className={`w-full px-4 py-3 rounded-xl bg-white/5 border border-white/10 focus:border-orange-500/50 focus:ring-2 focus:ring-orange-500/20 outline-none transition-all text-left text-white placeholder:text-slate-500 ${editingDept ? 'opacity-50 cursor-not-allowed' : ''}`}
                    placeholder="نموونە: NewOffice"
                    dir="ltr"
                    disabled={!!editingDept}
                  />
                  {!editingDept && <p className="text-xs text-slate-500 mt-2 text-right">تەنها پیتە ئینگلیزییەکان بەکاربهێنە (بێ بۆشایی)</p>}
                </div>

                <div>
                  <label className="block text-sm font-bold text-slate-300 mb-2 text-right">ناوی ژوور</label>
                  <input
                    type="text"
                    value={newDeptName}
                    onChange={(e) => setNewDeptName(e.target.value)}
                    className="w-full px-4 py-3 rounded-xl bg-white/5 border border-white/10 focus:border-orange-500/50 focus:ring-2 focus:ring-orange-500/20 outline-none transition-all text-right text-white placeholder:text-slate-500"
                    placeholder="ناوی ژوورەکە بە کوردی..."
                  />
                </div>
              </div>

              <div className="flex gap-3 mt-8 pt-6 border-t border-white/10">
                <button
                  onClick={closeModal}
                  className="flex-1 py-3.5 rounded-xl border border-white/10 text-slate-300 font-bold hover:bg-white/10 hover:text-white transition-all hover:shadow-[0_0_15px_rgba(255,255,255,0.05)]"
                >
                  پاشگەزبوونەوە
                </button>
                <button
                  onClick={handleSaveDepartment}
                  className="flex-1 py-3.5 rounded-xl bg-gradient-to-r from-orange-500 to-red-500 text-white font-bold hover:from-orange-400 hover:to-red-400 shadow-[0_0_20px_rgba(249,115,22,0.4)] transition-all hover:-translate-y-1 border border-white/10"
                >
                  {editingDept ? 'نوێکردنەوە' : 'زیادکردن'}
                </button>
              </div>
            </div>
          </div>
        </div>
      )}
    </div>
  );
};
