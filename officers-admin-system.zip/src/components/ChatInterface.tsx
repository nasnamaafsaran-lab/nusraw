import React, { useState, useEffect, useRef } from 'react';
import { useApp } from '../context';
import { Send, Paperclip, Phone, Video, MoreVertical, Search, Image as ImageIcon, Mic, FileText, User as UserIcon, Users, StopCircle, Play, Pause, Plus, XCircle } from 'lucide-react';
import { format } from 'date-fns';
import { motion, AnimatePresence } from 'framer-motion';

export const ChatInterface: React.FC = () => {
  const { currentUser, chats, users, sendMessage, getChatMessages, createChat, uploadFiles, showToast } = useApp();
  const [selectedChatId, setSelectedChatId] = useState<string | null>(null);
  const [messages, setMessages] = useState<any[]>([]);
  const [newMessage, setNewMessage] = useState('');
  const [searchTerm, setSearchTerm] = useState('');
  const [isCreatingGroup, setIsCreatingGroup] = useState(false);
  const [groupName, setGroupName] = useState('');
  const [selectedParticipants, setSelectedParticipants] = useState<string[]>([]);
  const [isRecording, setIsRecording] = useState(false);
  const messagesEndRef = useRef<HTMLDivElement>(null);
  const fileInputRef = useRef<HTMLInputElement>(null);
  const mediaRecorderRef = useRef<MediaRecorder | null>(null);
  const audioChunksRef = useRef<Blob[]>([]);

  const selectedChat = chats.find(c => c.id === selectedChatId);

  useEffect(() => {
    if (selectedChatId) {
      loadMessages(selectedChatId);
    }
  }, [selectedChatId]);

  useEffect(() => {
    scrollToBottom();
  }, [messages]);

  const loadMessages = React.useCallback(async (chatId: string) => {
    const msgs = await getChatMessages(chatId);
    setMessages(msgs);
  }, [getChatMessages]);

  const scrollToBottom = React.useCallback(() => {
    messagesEndRef.current?.scrollIntoView({ behavior: 'smooth' });
  }, []);

  const handleSend = React.useCallback(async () => {
    if (!selectedChatId || !newMessage.trim()) return;
    await sendMessage(selectedChatId, newMessage, 'text');
    setNewMessage('');
    loadMessages(selectedChatId); // Refresh immediately
  }, [selectedChatId, newMessage, sendMessage, loadMessages]);

  const handleFileUpload = React.useCallback(async (e: React.ChangeEvent<HTMLInputElement>) => {
    if (!selectedChatId || !e.target.files?.length) return;
    
    const files = Array.from(e.target.files);
    const uploaded = await uploadFiles(files);
    
    for (const file of uploaded) {
        await sendMessage(selectedChatId, file.name, 'file', file.url);
    }
    loadMessages(selectedChatId);
  }, [selectedChatId, uploadFiles, sendMessage, loadMessages]);

  useEffect(() => {
    return () => {
      if (mediaRecorderRef.current && mediaRecorderRef.current.state !== 'inactive') {
        mediaRecorderRef.current.stop();
        mediaRecorderRef.current.stream.getTracks().forEach(track => track.stop());
      }
    };
  }, []);

  const startRecording = React.useCallback(async () => {
    try {
      const stream = await navigator.mediaDevices.getUserMedia({ audio: true });
      const mediaRecorder = new MediaRecorder(stream);
      mediaRecorderRef.current = mediaRecorder;
      audioChunksRef.current = [];

      mediaRecorder.ondataavailable = (event) => {
        if (event.data.size > 0) {
          audioChunksRef.current.push(event.data);
        }
      };

      mediaRecorder.onstop = async () => {
        const audioBlob = new Blob(audioChunksRef.current, { type: 'audio/webm' });
        const audioFile = new File([audioBlob], 'voice-message.webm', { type: 'audio/webm' });
        
        if (selectedChatId) {
            const uploaded = await uploadFiles([audioFile]);
            if (uploaded.length > 0) {
                await sendMessage(selectedChatId, 'Voice Message', 'voice', uploaded[0].url);
                loadMessages(selectedChatId);
            }
        }
        
        stream.getTracks().forEach(track => track.stop());
      };

      mediaRecorder.start();
      setIsRecording(true);
    } catch (error) {
      console.error('Error accessing microphone:', error);
      showToast('ناتوانرا دەست بە تۆمارکردنی دەنگ بکرێت', 'error');
    }
  }, [selectedChatId, uploadFiles, sendMessage, loadMessages, showToast]);

  const stopRecording = React.useCallback(() => {
    if (mediaRecorderRef.current && isRecording) {
      mediaRecorderRef.current.stop();
      setIsRecording(false);
    }
  }, [isRecording]);

  const handleCreateChat = React.useCallback(async (userId: string) => {
      // Check if chat already exists
      const existing = chats.find(c => c.type === 'direct' && c.participants.includes(userId));
      if (existing) {
          setSelectedChatId(existing.id);
      } else {
          const newId = await createChat('direct', [userId]);
          if (newId) setSelectedChatId(newId);
      }
  }, [chats, createChat]);

  const handleCreateGroup = React.useCallback(async () => {
      if (!groupName.trim() || selectedParticipants.length === 0) {
          showToast('تکایە ناوی گروپ و بەشداربووان دیاری بکە', 'warning');
          return;
      }
      
      const newId = await createChat('group', selectedParticipants, groupName);
      if (newId) {
          setSelectedChatId(newId);
          setIsCreatingGroup(false);
          setGroupName('');
          setSelectedParticipants([]);
          showToast('گروپ بە سەرکەوتوویی دروستکرا', 'success');
      }
  }, [groupName, selectedParticipants, createChat, showToast]);

  const toggleParticipant = React.useCallback((userId: string) => {
      setSelectedParticipants(prev => 
          prev.includes(userId) ? prev.filter(id => id !== userId) : [...prev, userId]
      );
  }, []);

  const filteredChats = chats.filter(chat => {
      if (chat.type === 'direct') {
          const otherId = chat.participants.find(p => p !== currentUser?.id);
          const otherUser = users.find(u => u.id === otherId);
          return otherUser?.name.toLowerCase().includes(searchTerm.toLowerCase());
      }
      return chat.name?.toLowerCase().includes(searchTerm.toLowerCase());
  });

  const getChatName = (chat: any) => {
      if (chat.type === 'group') return chat.name;
      const otherId = chat.participants.find((p: string) => p !== currentUser?.id);
      const otherUser = users.find(u => u.id === otherId);
      return otherUser?.name || 'Unknown User';
  };

  const getChatAvatar = (chat: any) => {
      if (chat.type === 'group') return <Users size={20} />;
      return <UserIcon size={20} />;
  };

  return (
    <div className="h-[calc(100vh-8rem)] flex gap-6">
      {/* Chat List */}
      <div className="w-80 flex flex-col gap-4">
        <div className="glass-panel p-4 rounded-2xl">
          <div className="relative mb-4">
            <Search className="absolute right-3 top-3 text-slate-400" size={18} />
            <input 
              type="text" 
              placeholder="گەڕان..." 
              value={searchTerm}
              onChange={e => setSearchTerm(e.target.value)}
              className="w-full bg-white/5 border border-white/10 rounded-xl py-2.5 pr-10 pl-4 text-sm focus:outline-none focus:border-blue-500/50 transition-colors"
            />
          </div>
          
          <div className="flex flex-col gap-2 overflow-y-auto h-[calc(100%-4rem)] custom-scrollbar">
            <div className="flex items-center justify-between mb-2">
                <div className="text-xs font-bold text-slate-500 uppercase tracking-wider">نامەکان</div>
                <button 
                    onClick={() => setIsCreatingGroup(true)}
                    className="text-xs bg-blue-500/20 text-blue-400 hover:bg-blue-500/30 px-2 py-1 rounded-lg transition-colors flex items-center gap-1"
                >
                    <Plus size={12} />
                    گروپی نوێ
                </button>
            </div>
            {filteredChats.map(chat => (
              <button
                key={chat.id}
                onClick={() => setSelectedChatId(chat.id)}
                className={`flex items-center gap-3 p-3 rounded-xl transition-all ${
                  selectedChatId === chat.id 
                    ? 'bg-blue-600/20 border border-blue-500/30 shadow-[0_0_15px_rgba(37,99,235,0.1)]' 
                    : 'hover:bg-white/5 border border-transparent hover:shadow-[0_0_10px_rgba(255,255,255,0.05)]'
                }`}
              >
                <div className={`w-10 h-10 rounded-full flex items-center justify-center ${
                    selectedChatId === chat.id ? 'bg-white/20 text-white shadow-[0_0_10px_rgba(255,255,255,0.2)]' : 'bg-slate-700 text-slate-300'
                }`}>
                  {getChatAvatar(chat)}
                </div>
                <div className="flex-1 text-right">
                  <div className="text-sm font-bold text-slate-200">{getChatName(chat)}</div>
                  <div className="text-xs text-slate-500 truncate">
                    {chat.lastMessage?.content || 'هیچ نامەیەک نییە'}
                  </div>
                </div>
                {chat.lastMessage && (
                    <div className="text-[10px] text-slate-600 self-start">
                        {format(new Date(chat.lastMessage.timestamp), 'HH:mm')}
                    </div>
                )}
              </button>
            ))}

            <div className="text-xs font-bold text-slate-500 mt-4 mb-2 uppercase tracking-wider">پەیوەندییەکان</div>
            {users.filter(u => u.id !== currentUser?.id).map(user => (
                <button
                    key={user.id}
                    onClick={() => handleCreateChat(user.id)}
                    className="flex items-center gap-3 p-3 rounded-xl hover:bg-white/5 transition-all text-right hover:shadow-[0_0_10px_rgba(255,255,255,0.05)]"
                >
                    <div className="w-8 h-8 rounded-full bg-slate-700 flex items-center justify-center text-slate-300">
                        <UserIcon size={14} />
                    </div>
                    <div className="text-sm text-slate-300">{user.name}</div>
                </button>
            ))}
          </div>
        </div>
      </div>

      {/* Chat Area */}
      <div className="flex-1 glass-panel rounded-2xl flex flex-col overflow-hidden">
        {selectedChat ? (
          <>
            {/* Header */}
            <div className="p-4 border-b border-white/5 flex items-center justify-between bg-white/5 backdrop-blur-md">
              <div className="flex items-center gap-3">
                <div className="w-10 h-10 rounded-full bg-gradient-to-br from-blue-500 to-violet-600 flex items-center justify-center text-white shadow-lg">
                  {getChatAvatar(selectedChat)}
                </div>
                <div>
                  <h3 className="font-bold text-white">{getChatName(selectedChat)}</h3>
                  <div className="flex items-center gap-2">
                    <span className="w-2 h-2 rounded-full bg-emerald-500 animate-pulse" />
                    <span className="text-xs text-emerald-400">سەرهێڵ</span>
                  </div>
                </div>
              </div>
              <div className="flex items-center gap-2">
                <button className="p-2 hover:bg-white/10 rounded-lg text-slate-400 hover:text-white transition-all hover:shadow-[0_0_10px_rgba(255,255,255,0.1)]">
                  <Phone size={20} />
                </button>
                <button className="p-2 hover:bg-white/10 rounded-lg text-slate-400 hover:text-white transition-all hover:shadow-[0_0_10px_rgba(255,255,255,0.1)]">
                  <Video size={20} />
                </button>
                <button className="p-2 hover:bg-white/10 rounded-lg text-slate-400 hover:text-white transition-all hover:shadow-[0_0_10px_rgba(255,255,255,0.1)]">
                  <MoreVertical size={20} />
                </button>
              </div>
            </div>

            {/* Messages */}
            <div className="flex-1 overflow-y-auto p-6 space-y-4 custom-scrollbar bg-black/20">
              {messages.map((msg, idx) => {
                const isMe = msg.senderId === currentUser?.id;
                return (
                  <motion.div 
                    initial={{ opacity: 0, y: 10 }}
                    animate={{ opacity: 1, y: 0 }}
                    key={msg.id || idx} 
                    className={`flex ${isMe ? 'justify-end' : 'justify-start'}`}
                  >
                    <div className={`max-w-[70%] rounded-2xl p-4 ${
                      isMe 
                        ? 'bg-blue-600 text-white rounded-br-none shadow-[0_4px_15px_rgba(37,99,235,0.3)]' 
                        : 'bg-white/10 text-slate-200 rounded-bl-none border border-white/5'
                    }`}>
                      {msg.type === 'file' ? (
                          <div className="flex items-center gap-3">
                              <div className="p-2 bg-white/20 rounded-lg">
                                  <FileText size={24} />
                              </div>
                              <a href={msg.fileUrl} target="_blank" rel="noreferrer" className="underline decoration-white/30 hover:decoration-white">
                                  {msg.content}
                              </a>
                          </div>
                      ) : msg.type === 'voice' ? (
                          <div className="flex items-center gap-3 min-w-[200px]">
                              <audio controls src={msg.fileUrl} className="w-full h-8 rounded-lg" />
                          </div>
                      ) : (
                          <p className="leading-relaxed">{msg.content}</p>
                      )}
                      <div className={`text-[10px] mt-2 flex items-center gap-1 ${isMe ? 'text-blue-200' : 'text-slate-400'}`}>
                        {format(new Date(msg.timestamp), 'HH:mm')}
                        {isMe && <span className="text-xs">✓✓</span>}
                      </div>
                    </div>
                  </motion.div>
                );
              })}
              <div ref={messagesEndRef} />
            </div>

            {/* Input */}
            <div className="p-4 bg-white/5 border-t border-white/5 backdrop-blur-md">
              <div className="flex items-center gap-3">
                <button 
                    onClick={() => fileInputRef.current?.click()}
                    className="p-3 rounded-xl bg-white/5 hover:bg-white/10 text-slate-400 hover:text-blue-400 transition-all border border-white/5 hover:shadow-[0_0_10px_rgba(59,130,246,0.2)]"
                    disabled={isRecording}
                >
                  <Paperclip size={20} />
                </button>
                <input 
                    type="file" 
                    ref={fileInputRef} 
                    className="hidden" 
                    onChange={handleFileUpload}
                    multiple
                />
                
                {isRecording ? (
                    <div className="flex-1 flex items-center gap-3 bg-red-500/10 border border-red-500/30 rounded-xl px-4 py-3">
                        <div className="w-3 h-3 rounded-full bg-red-500 animate-pulse" />
                        <span className="text-red-400 font-bold">تۆمارکردن...</span>
                        <div className="flex-1" />
                        <button 
                            onClick={stopRecording}
                            className="p-2 rounded-full bg-red-500 text-white hover:bg-red-600 transition-colors shadow-lg shadow-red-500/20"
                        >
                            <StopCircle size={20} />
                        </button>
                    </div>
                ) : (
                    <div className="flex-1 relative">
                      <input
                        type="text"
                        value={newMessage}
                        onChange={(e) => setNewMessage(e.target.value)}
                        onKeyPress={(e) => e.key === 'Enter' && handleSend()}
                        placeholder="نامەیەک بنووسە..."
                        className="w-full bg-black/20 border border-white/10 rounded-xl py-3 px-4 focus:outline-none focus:border-blue-500/50 transition-colors text-right"
                        dir="auto"
                      />
                      <button className="absolute left-3 top-3 text-slate-400 hover:text-white transition-colors">
                        <ImageIcon size={20} />
                      </button>
                    </div>
                )}

                {newMessage.trim() ? (
                    <button 
                        onClick={handleSend}
                        className="p-3 rounded-xl bg-white/10 hover:bg-white/20 text-white shadow-[0_0_15px_rgba(255,255,255,0.1)] transition-all transform hover:scale-105 active:scale-95 border border-white/20 backdrop-blur-md"
                    >
                    <Send size={20} className={document.dir === 'rtl' ? 'rotate-180' : ''} />
                    </button>
                ) : !isRecording && (
                    <button 
                        onClick={startRecording}
                        className="p-3 rounded-xl bg-white/5 hover:bg-white/10 text-slate-400 hover:text-red-400 transition-all hover:shadow-[0_0_10px_rgba(239,68,68,0.2)]"
                    >
                        <Mic size={20} />
                    </button>
                )}
              </div>
            </div>
          </>
        ) : (
          <div className="flex-1 flex flex-col items-center justify-center text-slate-500">
            <div className="w-24 h-24 rounded-full bg-white/5 flex items-center justify-center mb-4 animate-pulse">
                <Users size={48} className="opacity-50" />
            </div>
            <p className="text-lg">چاتێک هەڵبژێرە بۆ دەستپێکردن</p>
          </div>
        )}
      </div>

      {/* Create Group Modal */}
      {isCreatingGroup && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/60 backdrop-blur-sm">
          <div className="glass-panel w-full max-w-md p-6 rounded-2xl border border-blue-500/30 shadow-[0_0_50px_rgba(37,99,235,0.1)]">
            <div className="flex justify-between items-center mb-6">
                <h3 className="text-xl font-bold text-white flex items-center gap-2">
                    <Users className="text-blue-400" />
                    دروستکردنی گروپی نوێ
                </h3>
                <button 
                    onClick={() => setIsCreatingGroup(false)}
                    className="text-slate-400 hover:text-white transition-colors"
                >
                    <XCircle size={24} />
                </button>
            </div>

            <div className="space-y-4">
                <div>
                    <label className="block text-sm text-slate-400 mb-2">ناوی گروپ</label>
                    <input 
                        type="text" 
                        value={groupName}
                        onChange={e => setGroupName(e.target.value)}
                        className="w-full bg-black/20 border border-white/10 rounded-xl p-3 text-white focus:border-blue-500/50 outline-none transition-colors"
                        placeholder="ناوی گروپ بنووسە..."
                    />
                </div>

                <div>
                    <label className="block text-sm text-slate-400 mb-2">بەشداربووان هەڵبژێرە</label>
                    <div className="max-h-60 overflow-y-auto custom-scrollbar space-y-2 bg-black/20 p-2 rounded-xl border border-white/10">
                        {users.filter(u => u.id !== currentUser?.id).map(user => (
                            <label key={user.id} className="flex items-center gap-3 p-2 hover:bg-white/5 rounded-lg cursor-pointer transition-colors">
                                <input 
                                    type="checkbox" 
                                    checked={selectedParticipants.includes(user.id)}
                                    onChange={() => toggleParticipant(user.id)}
                                    className="w-4 h-4 rounded border-white/20 bg-black/50 text-blue-500 focus:ring-blue-500/50 focus:ring-offset-0"
                                />
                                <div className="w-8 h-8 rounded-full bg-slate-700 flex items-center justify-center text-slate-300">
                                    <UserIcon size={14} />
                                </div>
                                <span className="text-sm text-slate-300">{user.name}</span>
                            </label>
                        ))}
                    </div>
                </div>

                <button 
                    onClick={handleCreateGroup}
                    className="w-full py-3 mt-4 rounded-xl bg-gradient-to-r from-blue-600 to-violet-600 hover:from-blue-500 hover:to-violet-500 text-white font-bold shadow-[0_0_20px_rgba(37,99,235,0.4)] transition-all hover:-translate-y-0.5"
                >
                    دروستکردنی گروپ
                </button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
};
