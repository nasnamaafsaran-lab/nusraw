import React from 'react';
import { useApp } from '../context';
import { LayoutDashboard, FileText, Users, Printer, Archive, LogOut, Shield, Bell, Search, Settings, FilePlus, Building2, BarChart3, Send, MessageSquare, Files, Layers, UserCheck } from 'lucide-react';

export const Sidebar: React.FC<{ activeView: string; setActiveView: (view: string) => void }> = ({ activeView, setActiveView }) => {
  const { currentUser, logout, notifications } = useApp();

  if (!currentUser) return null;

  const unreadCount = notifications.filter(n => n.userId === currentUser.id && !n.read).length;

  const menuItems = [
    { id: 'dashboard', label: 'داشبۆرد', icon: LayoutDashboard, roles: ['all'] },
    { id: 'dispatch', label: 'نووسراو ناردن', icon: Send, roles: ['dispatch_staff', 'super_admin'] },
    { id: 'documents', label: 'نوسراوەکان', icon: Files, roles: ['super_admin', 'director_general', 'deputy_director', 'dispatch_staff', 'print_staff'] },
    { id: 'requests', label: 'داواکارییەکان', icon: FilePlus, roles: ['all'] },
    { id: 'search', label: 'گەڕان', icon: Search, roles: ['all'] },
    { id: 'chats', label: 'پەیوەندییەکان', icon: MessageSquare, roles: ['all'] },
    { id: 'circulars', label: 'گشتاندن', icon: FileText, roles: ['all'] },
    { id: 'hand_delivery', label: 'تۆماری زمە', icon: UserCheck, roles: ['all'] },
    { id: 'departments', label: 'سەنتەری ژوورەکان', icon: Building2, roles: ['super_admin'] },
    { id: 'workflow_templates', label: 'قاڵبەکانی ڕەوتی کار', icon: Layers, roles: ['super_admin'] },
    { id: 'print', label: 'وێستگەی چاپ', icon: Printer, roles: ['print_staff', 'super_admin'] },
    { id: 'users', label: 'بەڕێوەبردنی بەکارهێنەران', icon: Users, roles: ['super_admin'] },
    { id: 'archive', label: 'ئەرشیفەکان', icon: Archive, roles: ['all'] },
    { id: 'reports', label: 'ڕاپۆرتەکان', icon: BarChart3, roles: ['super_admin', 'director_general'] },
    { id: 'settings', label: 'ڕێکخستنەکان', icon: Settings, roles: ['super_admin'] },
  ];

  const filteredItems = menuItems.filter(item => {
    if (item.roles.includes('all')) return true;
    return item.roles.includes(currentUser.role);
  });

  return (
    <div className="w-72 glass-panel flex flex-col z-30 m-0 h-screen border-l border-white/10 shadow-[0_0_30px_rgba(0,0,0,0.3)] print:hidden relative overflow-hidden" dir="rtl">
      {/* Subtle background glow for sidebar */}
      <div className="absolute top-0 right-0 w-full h-64 bg-blue-500/5 rounded-full blur-3xl -z-10"></div>
      
      {/* Branding */}
      <div className="h-20 flex items-center gap-4 px-6 border-b border-white/5 bg-white/5 backdrop-blur-md">
        <div className="w-10 h-10 bg-blue-600/20 rounded-xl flex items-center justify-center border border-blue-500/30 shadow-[0_0_15px_rgba(59,130,246,0.2)]">
          <Shield className="text-blue-400" size={24} />
        </div>
        <div>
          <h1 className="font-bold text-lg text-white tracking-wide">ئیدارەی ئەفسەران</h1>
          <span className="text-[10px] text-emerald-400 font-bold tracking-wider uppercase bg-emerald-500/10 px-2 py-0.5 rounded-full border border-emerald-500/20 shadow-[0_0_10px_rgba(16,185,129,0.1)]">سەرهێڵ</span>
        </div>
      </div>

      {/* Navigation */}
      <div className="flex-1 py-6 px-4 space-y-1 overflow-y-auto custom-scrollbar">
        <p className="px-4 text-xs font-semibold text-slate-400 uppercase tracking-wider mb-4 opacity-70">لیستی سەرەکی</p>
        {filteredItems.map(item => {
          const isPrint = item.id === 'print';
          const isActive = activeView === item.id;

          if (isPrint) {
            return (
              <button
                key={item.id}
                onClick={() => setActiveView(item.id)}
                className={`w-full group flex items-center justify-between px-5 py-4 rounded-2xl transition-all duration-300 ease-out relative mb-2 overflow-hidden border ${
                  isActive
                    ? 'text-white bg-gradient-to-r from-purple-600/40 via-pink-500/40 to-blue-500/40 border-white/30 shadow-[0_0_30px_rgba(236,72,153,0.3),inset_0_0_20px_rgba(255,255,255,0.2)] backdrop-blur-xl'
                    : 'text-white/90 bg-gradient-to-r from-purple-600/20 via-pink-500/20 to-blue-500/20 border-white/10 hover:border-white/20 hover:shadow-[0_0_20px_rgba(236,72,153,0.2)] backdrop-blur-md'
                }`}
              >
                {isActive && (
                  <>
                    <div className="absolute inset-0 bg-gradient-to-r from-purple-500/20 via-pink-500/20 to-blue-500/20 -z-10 animate-pulse-glow"></div>
                    <div className="absolute right-0 top-1/2 -translate-y-1/2 w-1.5 h-10 bg-gradient-to-b from-purple-400 via-pink-500 to-blue-500 rounded-l-full shadow-[0_0_15px_rgba(236,72,153,0.8)]"></div>
                  </>
                )}
                <div className="flex items-center gap-4 relative z-10">
                  <div className={`p-2 rounded-xl bg-white/10 backdrop-blur-md border border-white/20 shadow-inner transition-transform duration-300 ${isActive ? 'scale-110 shadow-[0_0_15px_rgba(255,255,255,0.3)]' : 'group-hover:scale-110'}`}>
                    <item.icon size={20} className="text-white drop-shadow-[0_0_8px_rgba(255,255,255,0.8)]" />
                  </div>
                  <span className={`font-bold text-[15px] tracking-wide drop-shadow-md`}>{item.label}</span>
                </div>
                {/* Decorative elements */}
                <div className="absolute -right-4 -top-4 w-16 h-16 bg-purple-500/30 rounded-full blur-xl group-hover:bg-purple-500/50 transition-colors"></div>
                <div className="absolute -left-4 -bottom-4 w-16 h-16 bg-blue-500/30 rounded-full blur-xl group-hover:bg-blue-500/50 transition-colors"></div>
              </button>
            );
          }

          return (
            <button
              key={item.id}
              onClick={() => setActiveView(item.id)}
              className={`w-full group flex items-center justify-between px-5 py-4 rounded-2xl transition-all duration-150 ease-out relative mb-2 overflow-hidden ${
                isActive 
                  ? 'text-white bg-white/10 border border-white/20 shadow-[0_0_25px_rgba(251,191,36,0.2),inset_0_0_15px_rgba(255,255,255,0.1)]' 
                  : 'text-slate-400 hover:bg-white/5 hover:text-white border border-transparent hover:shadow-[0_0_15px_rgba(255,255,255,0.05)]'
              }`}
            >
              {isActive && (
                <>
                  <div className="absolute inset-0 bg-gradient-to-r from-amber-500/10 via-pink-500/5 to-transparent -z-10 animate-pulse-glow"></div>
                  <div className="absolute right-0 top-1/2 -translate-y-1/2 w-1.5 h-10 bg-gradient-to-b from-amber-400 via-pink-500 to-purple-500 rounded-l-full shadow-[0_0_15px_rgba(251,191,36,0.8)]"></div>
                </>
              )}
              <div className="flex items-center gap-4">
                <item.icon size={22} className={`transition-all duration-150 ease-out ${isActive ? 'text-amber-400 drop-shadow-[0_0_8px_rgba(251,191,36,0.8)] scale-110' : 'text-slate-500 group-hover:text-amber-200'}`} />
                <span className={`font-medium text-[15px] transition-all duration-150 ease-out ${isActive ? 'font-black tracking-wide drop-shadow-md' : ''}`}>{item.label}</span>
              </div>
              {item.id === 'documents' && unreadCount > 0 && (
                <span className="bg-red-500/80 backdrop-blur-md text-white text-xs font-black px-2.5 py-1 rounded-full shadow-[0_0_15px_rgba(239,68,68,0.6)] border border-red-400/50">
                  {unreadCount}
                </span>
              )}
            </button>
          );
        })}
      </div>

      {/* Footer Actions */}
      <div className="p-4 border-t border-white/5 bg-white/5 backdrop-blur-md">
        <button 
          onClick={logout}
          className="w-full flex items-center justify-center gap-2 p-3 rounded-xl bg-red-500/10 text-red-400 hover:bg-red-500/20 hover:text-red-300 border border-red-500/20 transition-all duration-150 ease-out group shadow-[0_0_10px_rgba(239,68,68,0.05)] hover:shadow-[0_0_15px_rgba(239,68,68,0.15)]"
        >
          <LogOut size={18} className="group-hover:-translate-x-1 transition-transform duration-150 ease-out" />
          <span className="font-medium text-sm">چوونەدەرەوە</span>
        </button>
        <p className="text-center text-[10px] text-slate-500 mt-4 font-mono opacity-50">v1.3.0 • Elite System</p>
      </div>
    </div>
  );
};
