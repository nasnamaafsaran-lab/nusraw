import React, { useState } from 'react';
import { useApp } from '../context';
import { Search, Plus, UserPlus, Trash2, Edit2, Lock, Unlock, Shield } from 'lucide-react';
import { User, Role, Department } from '../types';
import { getRoleLabel, translations } from '../translations';

export const UserManagement: React.FC = () => {
  const { users, departments, addUser, updateUser, deleteUser, toggleUserLock } = useApp();
  const [searchTerm, setSearchTerm] = useState('');
  const [showAddModal, setShowAddModal] = useState(false);
  const [editingUser, setEditingUser] = useState<User | null>(null);

  // Form State
  const [formData, setFormData] = useState({
    username: '',
    password: '',
    name: '',
    role: 'employee' as Role,
    department: 'admin_office',
    title: '',
  });

  const filteredUsers = users.filter(user => 
    user.name.toLowerCase().includes(searchTerm.toLowerCase()) ||
    user.username.toLowerCase().includes(searchTerm.toLowerCase())
  );

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (editingUser) {
      updateUser({ ...editingUser, ...formData });
    } else {
      addUser({
        ...formData,
        addedBy: 'System', // Should be current user name but for now System
      });
    }
    setShowAddModal(false);
    setEditingUser(null);
    setFormData({ username: '', password: '', name: '', role: 'employee', department: 'admin_office', title: '' });
  };

  const openEditModal = (user: User) => {
    setEditingUser(user);
    setFormData({
      username: user.username,
      password: user.password || '',
      name: user.name,
      role: user.role,
      department: user.department,
      title: user.title,
    });
    setShowAddModal(true);
  };

  return (
    <div className="space-y-8" dir="rtl">
      <div className="flex items-center justify-between">
        <div>
          <h1 className="text-3xl font-black text-white neon-text">بەڕێوەبردنی بەکارهێنەران</h1>
          <p className="text-slate-400 mt-2">زیادکردن و دەستکاریکردنی هەژماری کارمەندان</p>
        </div>
        <button 
          onClick={() => {
            setEditingUser(null);
            setFormData({ username: '', password: '', name: '', role: 'employee', department: 'admin_office', title: '' });
            setShowAddModal(true);
          }}
          className="flex items-center gap-2 bg-gradient-to-r from-blue-600 to-indigo-600 hover:from-blue-500 hover:to-indigo-500 text-white px-6 py-3 rounded-xl font-bold shadow-[0_0_20px_rgba(59,130,246,0.5)] transition-all hover:-translate-y-1 border border-white/10"
        >
          <UserPlus size={20} />
          <span>زیادکردنی بەکارهێنەر</span>
        </button>
      </div>

      <div className="bg-white/5 rounded-2xl shadow-sm border border-white/10 overflow-hidden">
        <div className="p-4 border-b border-white/10 bg-white/5 backdrop-blur-md">
          <div className="relative max-w-md">
            <Search className="absolute right-4 top-3.5 text-slate-400" size={20} />
            <input
              type="text"
              placeholder="گەڕان بەدوای بەکارهێنەر..."
              className="w-full pr-12 pl-4 py-3 rounded-xl bg-white/5 border border-white/10 focus:border-blue-500/50 focus:ring-2 focus:ring-blue-500/20 outline-none transition-all text-white placeholder:text-slate-500"
              value={searchTerm}
              onChange={(e) => setSearchTerm(e.target.value)}
            />
          </div>
        </div>

        <div className="overflow-x-auto">
          <table className="elite-table">
            <thead>
              <tr>
                <th>کارمەند</th>
                <th>ناونیشانی ئیمەیڵ / بەکارهێنەر</th>
                <th>پلە</th>
                <th>ڕۆڵ</th>
                <th>زیادکراوە لەلایەن</th>
                <th className="text-center">کردارەکان</th>
              </tr>
            </thead>
            <tbody>
              {filteredUsers.map(user => (
                <tr key={user.id} className="group">
                  <td>
                    <div className="flex items-center gap-3">
                      <div className="w-10 h-10 rounded-full bg-blue-500/20 text-blue-400 flex items-center justify-center font-bold text-lg border border-blue-500/30 shadow-[0_0_10px_rgba(59,130,246,0.2)]">
                        {user.name.charAt(0)}
                      </div>
                      <div>
                        <div className="font-bold text-white group-hover:text-blue-400 transition-colors">{user.name}</div>
                        <div className="text-xs text-slate-400">{user.title}</div>
                      </div>
                    </div>
                  </td>
                  <td className="font-mono text-slate-300">{user.username}</td>
                  <td>
                    <span className="badge-glow badge-info bg-white/10 text-slate-300 border-white/10">
                      {getRoleLabel(user.role)}
                    </span>
                  </td>
                  <td className="text-slate-300">{user.department}</td>
                  <td className="text-slate-500 text-sm">{user.addedBy || '-'}</td>
                  <td>
                    <div className="flex items-center justify-center gap-2">
                      <button 
                        onClick={() => toggleUserLock(user.id)}
                        className={`p-2 rounded-lg transition-all ${user.isLocked ? 'bg-red-500/20 text-red-400 hover:bg-red-500/30 shadow-[0_0_10px_rgba(239,68,68,0.2)]' : 'bg-white/5 text-slate-400 hover:text-white hover:bg-white/10 hover:shadow-[0_0_10px_rgba(255,255,255,0.1)]'}`}
                        title={user.isLocked ? "Unlock User" : "Lock User"}
                      >
                        {user.isLocked ? <Lock size={18} /> : <Unlock size={18} />}
                      </button>
                      <button 
                        onClick={() => openEditModal(user)}
                        className="p-2 rounded-lg bg-blue-500/10 text-blue-400 hover:bg-blue-500/20 transition-all hover:shadow-[0_0_10px_rgba(59,130,246,0.2)] hover:-translate-y-0.5"
                      >
                        <Edit2 size={18} />
                      </button>
                      <button 
                        onClick={() => deleteUser(user.id)}
                        className="p-2 rounded-lg bg-red-500/10 text-red-400 hover:bg-red-500/20 transition-all hover:shadow-[0_0_10px_rgba(239,68,68,0.2)] hover:-translate-y-0.5"
                      >
                        <Trash2 size={18} />
                      </button>
                    </div>
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      </div>

      {/* Add/Edit User Modal */}
      {showAddModal && (
        <div className="fixed inset-0 bg-black/80 backdrop-blur-md z-50 flex items-center justify-center p-4 animate-in fade-in duration-200">
          <div className="glass-panel rounded-3xl w-full max-w-lg shadow-2xl border border-white/10 overflow-hidden animate-in zoom-in-95 duration-200">
            <div className="p-8">
              <div className="flex items-center gap-4 mb-8">
                <div className="w-12 h-12 bg-blue-500/20 rounded-2xl flex items-center justify-center text-blue-400 shadow-[0_0_15px_rgba(59,130,246,0.3)]">
                  <UserPlus size={24} />
                </div>
                <h2 className="text-2xl font-bold text-white neon-text">
                  {editingUser ? 'دەستکاری بەکارهێنەر' : 'زیادکردنی بەکارهێنەر'}
                </h2>
              </div>

              <form onSubmit={handleSubmit} className="space-y-5">
                <div className="grid grid-cols-2 gap-4">
                  <div>
                    <label className="block text-sm font-bold text-slate-300 mb-2">ناوی بەکارهێنەر (چوونەژوورەوە)</label>
                    <input
                      type="text"
                      required
                      value={formData.username}
                      onChange={e => setFormData({...formData, username: e.target.value})}
                      className="w-full px-4 py-3 rounded-xl bg-white/5 border border-white/10 focus:border-blue-500/50 focus:ring-2 focus:ring-blue-500/20 outline-none transition-all text-left text-white placeholder:text-slate-500"
                      placeholder="username"
                      dir="ltr"
                    />
                  </div>
                  <div>
                    <label className="block text-sm font-bold text-slate-300 mb-2">وشەی نهێنی</label>
                    <input
                      type="text"
                      required={!editingUser}
                      value={formData.password}
                      onChange={e => setFormData({...formData, password: e.target.value})}
                      className="w-full px-4 py-3 rounded-xl bg-white/5 border border-white/10 focus:border-blue-500/50 focus:ring-2 focus:ring-blue-500/20 outline-none transition-all text-left text-white placeholder:text-slate-500"
                      placeholder="password"
                      dir="ltr"
                    />
                  </div>
                </div>

                <div>
                  <label className="block text-sm font-bold text-slate-300 mb-2">ناوی تەواو</label>
                  <input
                    type="text"
                    required
                    value={formData.name}
                    onChange={e => setFormData({...formData, name: e.target.value})}
                    className="w-full px-4 py-3 rounded-xl bg-white/5 border border-white/10 focus:border-blue-500/50 focus:ring-2 focus:ring-blue-500/20 outline-none transition-all text-white placeholder:text-slate-500"
                    placeholder="ناوی سیانی..."
                  />
                </div>

                <div className="grid grid-cols-2 gap-4">
                  <div>
                    <label className="block text-sm font-bold text-slate-300 mb-2">ڕۆڵ</label>
                    <select
                      value={formData.role}
                      onChange={e => setFormData({...formData, role: e.target.value as Role})}
                      className="w-full px-4 py-3 rounded-xl bg-slate-900 border border-white/10 focus:border-blue-500/50 focus:ring-2 focus:ring-blue-500/20 outline-none transition-all text-white"
                    >
                      {Object.entries(translations.role).map(([key, label]) => (
                        <option key={key} value={key}>{label}</option>
                      ))}
                    </select>
                  </div>
                  <div>
                    <label className="block text-sm font-bold text-slate-300 mb-2">بەش</label>
                    <select
                      value={formData.department}
                      onChange={e => setFormData({...formData, department: e.target.value})}
                      className="w-full px-4 py-3 rounded-xl bg-slate-900 border border-white/10 focus:border-blue-500/50 focus:ring-2 focus:ring-blue-500/20 outline-none transition-all text-white"
                    >
                      {departments.map(dept => (
                        <option key={dept.id} value={dept.id}>{dept.name}</option>
                      ))}
                    </select>
                  </div>
                </div>

                <div>
                  <label className="block text-sm font-bold text-slate-300 mb-2">ناونیشانی وەزیفی</label>
                  <input
                    type="text"
                    required
                    value={formData.title}
                    onChange={e => setFormData({...formData, title: e.target.value})}
                    className="w-full px-4 py-3 rounded-xl bg-white/5 border border-white/10 focus:border-blue-500/50 focus:ring-2 focus:ring-blue-500/20 outline-none transition-all text-white placeholder:text-slate-500"
                    placeholder="نموونە: بەڕێوەبەری کارگێڕی..."
                  />
                </div>

                <div className="flex gap-3 mt-8 pt-6 border-t border-white/10">
                  <button
                    type="button"
                    onClick={() => setShowAddModal(false)}
                    className="flex-1 py-3.5 rounded-xl border border-white/10 text-slate-300 font-bold hover:bg-white/10 hover:text-white transition-all hover:shadow-[0_0_15px_rgba(255,255,255,0.05)]"
                  >
                    پاشگەزبوونەوە
                  </button>
                  <button
                    type="submit"
                    className="flex-1 py-3.5 rounded-xl bg-gradient-to-r from-blue-600 to-indigo-600 text-white font-bold hover:from-blue-500 hover:to-indigo-500 shadow-[0_0_20px_rgba(59,130,246,0.4)] transition-all hover:-translate-y-1 border border-white/10"
                  >
                    {editingUser ? 'نوێکردنەوە' : 'زیادکردن'}
                  </button>
                </div>
              </form>
            </div>
          </div>
        </div>
      )}
    </div>
  );
};
