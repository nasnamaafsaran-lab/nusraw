import React from 'react';
import { Document, WorkflowStage, WorkflowTemplate } from '../types';
import { Check, Clock, Circle, X, Activity } from 'lucide-react';
import { useApp } from '../context';

interface WorkflowTimelineProps {
  doc: Document;
  onStageClick?: (stage: { id: string, label: string }, index: number, isFuture: boolean, isPast: boolean) => void;
}

const DEFAULT_STAGES: { id: string; label: string }[] = [
  { id: 'DISPATCH', label: 'بەشی ناردن' },
  { id: 'DEPT_HEAD_IN', label: 'بەڕێوەبەری بەش' },
  { id: 'UNIT_HEAD_IN', label: 'بەڕێوەبەری هۆبە' },
  { id: 'EMPLOYEE_ACTION', label: 'کارمەند' },
  { id: 'UNIT_HEAD_OUT', label: 'بەڕێوەبەری هۆبە' },
  { id: 'DEPT_HEAD_OUT', label: 'بەڕێوەبەری بەش' },
  { id: 'DEPUTY_REVIEW', label: 'جێگری بەڕێوەبەر' },
  { id: 'DIRECTOR_REVIEW', label: 'بەڕێوەبەری گشتی' },
  { id: 'PRINT_ROOM', label: 'بەشی پڕێنت' },
  { id: 'ARCHIVED', label: 'ئەرشیف' },
];

export const WorkflowTimeline: React.FC<WorkflowTimelineProps> = ({ doc, onStageClick }) => {
  const { workflowTemplates, users, departments } = useApp();
  const template = doc.workflowTemplateId ? workflowTemplates.find(t => t.id === doc.workflowTemplateId) : null;
  
  const currentHolder = users.find(u => u.id === doc.currentHolderId);
  const currentDept = departments.find(d => d.id === currentHolder?.department);

  const stages = template 
    ? template.steps.map(step => ({ id: step.id, label: step.label }))
    : DEFAULT_STAGES;

  const currentStageIndex = template 
    ? doc.currentStepIndex 
    : stages.findIndex(s => s.id === doc.workflowStage);
    
  const isRejected = doc.status === 'Rejected';

  return (
    <div className="w-full overflow-x-auto pb-12 pt-8 custom-scrollbar" dir="rtl">
      {template && (
        <div className="flex items-center gap-2 mb-6 px-10">
          <Activity size={14} className="text-purple-400" />
          <span className="text-xs font-bold text-purple-300">ڕەوتی کار: {template.name}</span>
        </div>
      )}
      <div className="min-w-[1000px] flex items-center justify-between relative px-10">
        
        {/* Background Line */}
        <div className="absolute top-6 left-10 right-10 h-1.5 bg-slate-800 rounded-full z-0" />
        
        {/* Progress Line */}
        <div 
          className={`absolute top-6 right-10 h-1.5 rounded-full z-0 transition-all duration-1000 ease-out ${
            isRejected ? 'bg-red-500 shadow-[0_0_15px_rgba(239,68,68,0.5)]' : 'bg-emerald-500 shadow-[0_0_15px_rgba(16,185,129,0.5)]'
          }`}
          style={{ 
            width: `calc(${(currentStageIndex / (stages.length - 1)) * 100}% - 20px)`,
            right: '40px' // Align with the center of the first node
          }}
        />

        {stages.map((stage, index) => {
          const isCompleted = index < currentStageIndex;
          const isCurrent = index === currentStageIndex;
          const isFuture = index > currentStageIndex;

          let nodeClass = '';
          let icon = null;
          let labelClass = '';

          if (isCompleted) {
            nodeClass = 'bg-emerald-500 border-4 border-slate-900 text-white shadow-[0_0_20px_rgba(16,185,129,0.4)] scale-110';
            icon = <Check size={20} strokeWidth={3} />;
            labelClass = 'text-emerald-400 font-bold';
          } else if (isCurrent) {
            if (isRejected) {
              nodeClass = 'bg-red-600 border-4 border-slate-900 text-white shadow-[0_0_30px_rgba(239,68,68,0.6)] scale-125 ring-4 ring-red-500/20';
              icon = <X size={24} strokeWidth={3} />;
              labelClass = 'text-red-400 font-bold scale-110';
            } else {
              nodeClass = 'bg-blue-500 border-4 border-slate-900 text-white shadow-[0_0_30px_rgba(59,130,246,0.6)] scale-125 ring-4 ring-blue-500/20 animate-pulse-glow';
              icon = <Check size={24} strokeWidth={3} />;
              labelClass = 'text-blue-400 font-bold scale-110';
            }
          } else {
            nodeClass = 'bg-slate-800 border-4 border-slate-900 text-slate-500';
            icon = <Check size={18} className="opacity-20" />; // Gray checkmark as requested
            labelClass = 'text-slate-500 font-medium';
          }

          return (
            <div 
              key={stage.id} 
              className={`relative z-10 flex flex-col items-center group ${(isFuture || isCompleted) && onStageClick ? 'cursor-pointer' : ''}`}
              onClick={() => {
                if (onStageClick && (isFuture || isCompleted)) {
                  onStageClick(stage, index, isFuture, isCompleted);
                }
              }}
            >
              {/* Node */}
              <div className={`
                w-12 h-12 rounded-full flex items-center justify-center transition-all duration-500 relative
                ${nodeClass}
                ${(isFuture || isCompleted) && onStageClick ? 'hover:scale-110 hover:shadow-[0_0_20px_rgba(255,255,255,0.3)]' : ''}
              `}>
                {icon}
              </div>

              {/* Label */}
              <div className={`
                absolute top-16 whitespace-nowrap text-sm transition-all duration-300 px-3 py-1 rounded-full
                ${labelClass}
                ${(isFuture || isCompleted) && onStageClick ? 'group-hover:text-white group-hover:bg-white/10' : ''}
              `}>
                {stage.label}
              </div>
              
              {/* Tooltip for Current/Rejected */}
              {isCurrent && (
                <div className="absolute bottom-full mb-3 animate-in fade-in slide-in-from-bottom-2 duration-500">
                  <div className={`px-4 py-2 rounded-2xl text-xs font-bold shadow-xl flex flex-col items-center gap-1 min-w-[120px] ${
                    isRejected ? 'bg-red-500 text-white' : 'bg-blue-600 text-white'
                  }`}>
                    <span className="opacity-80 text-[10px] uppercase tracking-widest">{isRejected ? 'ڕەتکراوەتەوە' : 'ئێستا لێرەیە'}</span>
                    <span className="text-sm">{currentDept?.name || '---'}</span>
                    <span className="text-[10px] opacity-70">({currentHolder?.name || '---'})</span>
                  </div>
                  <div className={`w-3 h-3 rotate-45 mx-auto -mt-1.5 ${
                    isRejected ? 'bg-red-500' : 'bg-blue-600'
                  }`}></div>
                </div>
              )}
            </div>
          );
        })}
      </div>
    </div>
  );
};
