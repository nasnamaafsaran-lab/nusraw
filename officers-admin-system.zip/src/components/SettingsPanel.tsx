import React, { useRef, useState, useEffect } from 'react';
import { useApp } from '../context';
import { 
  Database, Globe, Download, Upload, Server, RefreshCw, Clock, 
  Shield, Lock, User, Bell, Save, Trash2, Activity, HardDrive, FileX, FileText 
} from 'lucide-react';

export const SettingsPanel: React.FC = () => {
  const { backupSystem, restoreSystem, showToast } = useApp();
  const fileInputRef = useRef<HTMLInputElement>(null);
  const [activeTab, setActiveTab] = useState('general');
  const [serverIp, setServerIp] = useState<string>('Loading...');
  const [cleanupDate, setCleanupDate] = useState('');
  const [settings, setSettings] = useState({
    systemName: 'سیستەمی EDMS',
    language: 'kurdish',
    theme: 'dark',
    sessionTimeout: '30',
    passwordPolicy: {
      minLength: 8,
      requireNumbers: true,
      requireSpecial: false
    },
    autoBackup: 'daily',
    notifications: {
      email: false,
      system: true
    }
  });

  useEffect(() => {
    fetch('/api/network-info')
      .then(res => res.json())
      .then(data => setServerIp(data.ip))
      .catch(() => setServerIp(window.location.hostname));

    // Fetch settings from server (mock for now if endpoint not fully populated)
    fetch('/api/settings')
      .then(res => res.json())
      .then(data => {
        if (Object.keys(data).length > 0) {
           // Merge with defaults
           setSettings(prev => ({ ...prev, ...data }));
        }
      })
      .catch(err => console.error(err));
  }, []);

  const handleSaveSettings = async () => {
    try {
      // Save each setting key
      for (const [key, value] of Object.entries(settings)) {
        await fetch('/api/settings', {
          method: 'POST',
          headers: { 'Content-Type': 'application/json' },
          body: JSON.stringify({ key, value: JSON.stringify(value) })
        });
      }
      showToast('ڕێکخستنەکان بە سەرکەوتوویی پاشەکەوت کران', 'success');
    } catch (error) {
      showToast('هەڵە لە پاشەکەوتکردنی ڕێکخستنەکان', 'error');
    }
  };

  const handleOptimizeDB = async () => {
    try {
      const res = await fetch('/api/settings/optimize', { method: 'POST' });
      const data = await res.json();
      if (data.success) {
        showToast('داتابەیس بە سەرکەوتوویی باشتر کرا (Optimized)', 'success');
      }
    } catch (error) {
      showToast('هەڵە لە باشترکردنی داتابەیس', 'error');
    }
  };

  const handleRestore = async (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (file) {
        if (confirm('دڵنیایت لە گەڕاندنەوەی ئەم فایلە؟ هەموو داتاکانی ئێستا دەسڕێنەوە.')) {
            await restoreSystem(file);
        }
        if (fileInputRef.current) fileInputRef.current.value = '';
    }
  };

  const handleCleanupAttachments = async () => {
    if (!cleanupDate) {
      showToast('تکایە بەروارێک دیاری بکە', 'error');
      return;
    }
    
    if (confirm(`دڵنیایت لە سڕینەوەی هەموو فایلە هاوپێچەکان پێش بەرواری ${cleanupDate}؟ ئەم کردە گەڕانەوەی نییە.`)) {
      try {
        const res = await fetch('/api/settings/cleanup-attachments', {
          method: 'POST',
          headers: { 'Content-Type': 'application/json' },
          body: JSON.stringify({ beforeDate: cleanupDate })
        });
        const data = await res.json();
        if (data.success) {
          showToast(`${data.count} فایل بە سەرکەوتوویی سڕانەوە`, 'success');
        } else {
          showToast('هەڵە لە سڕینەوەی فایلەکان', 'error');
        }
      } catch (error) {
        showToast('هەڵە لە پەیوەندی بە سێرڤەر', 'error');
      }
    }
  };

  const handleExportLogs = () => {
    // Mock export functionality
    const csvContent = "data:text/csv;charset=utf-8,Date,User,Action,Target\n" + 
      "2024-03-06,Admin,Login,System\n" +
      "2024-03-06,User1,Create,Document #123";
    const encodedUri = encodeURI(csvContent);
    const link = document.createElement("a");
    link.setAttribute("href", encodedUri);
    link.setAttribute("download", "system_logs.csv");
    document.body.appendChild(link);
    link.click();
    document.body.removeChild(link);
    showToast('تۆمارەکان بە سەرکەوتوویی دابەزێنران', 'success');
  };

  const tabs = [
    { id: 'general', label: 'گشتی', icon: Globe },
    { id: 'security', label: 'سکیوریتی', icon: Shield },
    { id: 'backup', label: 'پاشەکەوت', icon: Database },
    { id: 'system', label: 'سیستەم', icon: Server },
  ];

  return (
    <div className="space-y-8 pb-10" dir="rtl">
      <div className="flex items-center justify-between">
        <div>
          <h1 className="text-3xl font-black text-white neon-text">ڕێکخستنەکان</h1>
          <p className="text-slate-400 text-lg">بەڕێوەبردنی داتا و پەیوەندییەکان</p>
        </div>
        <button 
          onClick={handleSaveSettings}
          className="px-6 py-3 bg-blue-600 hover:bg-blue-500 text-white rounded-xl font-bold shadow-lg shadow-blue-600/20 transition-all hover:-translate-y-1 flex items-center gap-2"
        >
          <Save size={20} />
          پاشەکەوتکردن
        </button>
      </div>

      <div className="grid grid-cols-12 gap-8">
        {/* Sidebar Tabs */}
        <div className="col-span-12 lg:col-span-3 space-y-2">
          {tabs.map(tab => (
            <button
              key={tab.id}
              onClick={() => setActiveTab(tab.id)}
              className={`w-full flex items-center gap-3 px-4 py-4 rounded-xl transition-all font-bold ${
                activeTab === tab.id 
                  ? 'bg-blue-600 text-white shadow-lg shadow-blue-600/20' 
                  : 'bg-white/5 text-slate-400 hover:bg-white/10 hover:text-white'
              }`}
            >
              <tab.icon size={20} />
              {tab.label}
            </button>
          ))}
        </div>

        {/* Content Area */}
        <div className="col-span-12 lg:col-span-9 space-y-6">
          
          {/* General Settings */}
          {activeTab === 'general' && (
            <div className="glass-panel p-8 rounded-3xl border border-white/10 space-y-8 animate-in fade-in slide-in-from-bottom-4 duration-500">
              <div className="space-y-4">
                <h3 className="text-xl font-bold text-white flex items-center gap-2">
                  <Globe className="text-blue-400" />
                  زانیاری گشتی
                </h3>
                <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                  <div className="space-y-2">
                    <label className="text-slate-400 text-sm">ناوی سیستەم</label>
                    <input 
                      type="text" 
                      value={settings.systemName}
                      onChange={e => setSettings({...settings, systemName: e.target.value})}
                      className="w-full bg-black/30 border border-white/10 rounded-xl px-4 py-3 text-white focus:border-blue-500 outline-none transition-colors"
                    />
                  </div>
                  <div className="space-y-2">
                    <label className="text-slate-400 text-sm">زمان</label>
                    <select 
                      value={settings.language}
                      onChange={e => setSettings({...settings, language: e.target.value})}
                      className="w-full bg-black/30 border border-white/10 rounded-xl px-4 py-3 text-white focus:border-blue-500 outline-none transition-colors"
                    >
                      <option value="kurdish">کوردی</option>
                      <option value="english">English</option>
                      <option value="arabic">عربی</option>
                    </select>
                  </div>
                </div>
              </div>

              <div className="space-y-4 pt-6 border-t border-white/5">
                <h3 className="text-xl font-bold text-white flex items-center gap-2">
                  <Bell className="text-yellow-400" />
                  ئاگادارکردنەوەکان
                </h3>
                <div className="space-y-3">
                  <label className="flex items-center gap-3 p-4 rounded-xl bg-white/5 border border-white/5 cursor-pointer hover:bg-white/10 transition-colors">
                    <input 
                      type="checkbox" 
                      checked={settings.notifications.system}
                      onChange={e => setSettings({...settings, notifications: {...settings.notifications, system: e.target.checked}})}
                      className="w-5 h-5 rounded border-slate-600 text-blue-600 focus:ring-blue-500 bg-transparent"
                    />
                    <span className="text-white font-medium">ئاگادارکردنەوەکانی سیستەم</span>
                  </label>
                  <label className="flex items-center gap-3 p-4 rounded-xl bg-white/5 border border-white/5 cursor-pointer hover:bg-white/10 transition-colors">
                    <input 
                      type="checkbox" 
                      checked={settings.notifications.email}
                      onChange={e => setSettings({...settings, notifications: {...settings.notifications, email: e.target.checked}})}
                      className="w-5 h-5 rounded border-slate-600 text-blue-600 focus:ring-blue-500 bg-transparent"
                    />
                    <span className="text-white font-medium">ئاگادارکردنەوەکانی ئیمەیڵ</span>
                  </label>
                </div>
              </div>
            </div>
          )}

          {/* Security Settings */}
          {activeTab === 'security' && (
            <div className="glass-panel p-8 rounded-3xl border border-white/10 space-y-8 animate-in fade-in slide-in-from-bottom-4 duration-500">
              <div className="space-y-4">
                <h3 className="text-xl font-bold text-white flex items-center gap-2">
                  <Lock className="text-red-400" />
                  پاراستنی هەژمار
                </h3>
                <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                  <div className="space-y-2">
                    <label className="text-slate-400 text-sm">کاتی بەسەرچوونی دانیشتن</label>
                    <select 
                      value={settings.sessionTimeout}
                      onChange={e => setSettings({...settings, sessionTimeout: e.target.value})}
                      className="w-full bg-black/30 border border-white/10 rounded-xl px-4 py-3 text-white focus:border-red-500 outline-none transition-colors"
                    >
                      <option value="15">١٥ خولەک</option>
                      <option value="30">٣٠ خولەک</option>
                      <option value="60">١ کاتژمێر</option>
                      <option value="240">٤ کاتژمێر</option>
                    </select>
                  </div>
                  <div className="space-y-2">
                    <label className="text-slate-400 text-sm">کەمترین ژمارەی پیت بۆ وشەی نهێنی</label>
                    <input 
                      type="number" 
                      value={settings.passwordPolicy.minLength}
                      onChange={e => setSettings({...settings, passwordPolicy: {...settings.passwordPolicy, minLength: parseInt(e.target.value)}})}
                      className="w-full bg-black/30 border border-white/10 rounded-xl px-4 py-3 text-white focus:border-red-500 outline-none transition-colors"
                    />
                  </div>
                </div>
              </div>

              <div className="space-y-4 pt-6 border-t border-white/5">
                <h3 className="text-xl font-bold text-white flex items-center gap-2">
                  <Activity className="text-orange-400" />
                  تۆماری چوونەژوورەوە
                </h3>
                <div className="bg-black/20 rounded-xl p-4 border border-white/5">
                  <div className="flex items-center justify-between text-sm text-slate-400 mb-2">
                    <span>دواین چوونەژوورەوە</span>
                    <span>IP Address</span>
                  </div>
                  <div className="flex items-center justify-between text-white font-mono text-sm">
                    <span>{new Date().toLocaleString()}</span>
                    <span>192.168.1.105</span>
                  </div>
                </div>
                <button className="text-blue-400 text-sm hover:underline">بینینی هەموو تۆمارەکان</button>
              </div>
            </div>
          )}

          {/* Backup Settings */}
          {activeTab === 'backup' && (
            <div className="glass-panel p-8 rounded-3xl border border-white/10 space-y-8 animate-in fade-in slide-in-from-bottom-4 duration-500">
              <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                <div className="bg-blue-500/10 rounded-2xl p-6 border border-blue-500/20 flex flex-col items-center text-center space-y-4">
                  <div className="w-16 h-16 bg-blue-500/20 rounded-full flex items-center justify-center text-blue-400">
                    <Download size={32} />
                  </div>
                  <div>
                    <h3 className="text-lg font-bold text-white">پاشەکەوتکردن</h3>
                    <p className="text-sm text-slate-400 mt-1">دابەزاندنی کۆپییەکی تەواوی داتابەیس و فایلەکان</p>
                  </div>
                  <button 
                    onClick={backupSystem}
                    className="w-full py-3 bg-blue-600 hover:bg-blue-500 text-white rounded-xl font-bold transition-colors shadow-lg shadow-blue-600/20"
                  >
                    دابەزاندن
                  </button>
                </div>

                <div className="bg-emerald-500/10 rounded-2xl p-6 border border-emerald-500/20 flex flex-col items-center text-center space-y-4">
                  <div className="w-16 h-16 bg-emerald-500/20 rounded-full flex items-center justify-center text-emerald-400">
                    <Upload size={32} />
                  </div>
                  <div>
                    <h3 className="text-lg font-bold text-white">گەڕاندنەوە</h3>
                    <p className="text-sm text-slate-400 mt-1">گەڕاندنەوەی داتاکان لە فایلێکی پاشەکەوتەوە</p>
                  </div>
                  <div className="relative w-full">
                    <input
                      type="file"
                      ref={fileInputRef}
                      onChange={handleRestore}
                      className="hidden"
                      accept=".zip"
                    />
                    <button 
                      onClick={() => fileInputRef.current?.click()}
                      className="w-full py-3 bg-emerald-600 hover:bg-emerald-500 text-white rounded-xl font-bold transition-colors shadow-lg shadow-emerald-600/20"
                    >
                      هەڵبژاردنی فایل
                    </button>
                  </div>
                </div>
              </div>

              <div className="space-y-4 pt-6 border-t border-white/5">
                <h3 className="text-xl font-bold text-white flex items-center gap-2">
                  <Clock className="text-purple-400" />
                  پاشەکەوتی ئۆتۆماتیکی
                </h3>
                <div className="flex items-center gap-4">
                  <select 
                    value={settings.autoBackup}
                    onChange={e => setSettings({...settings, autoBackup: e.target.value})}
                    className="bg-black/30 border border-white/10 rounded-xl px-4 py-3 text-white focus:border-purple-500 outline-none transition-colors min-w-[200px]"
                  >
                    <option value="off">ناچالاک</option>
                    <option value="daily">ڕۆژانە (١٢:٠٠ شەو)</option>
                    <option value="weekly">هەفتانە (هەینی)</option>
                    <option value="monthly">مانگانە (١ی مانگ)</option>
                  </select>
                  <p className="text-sm text-slate-400">دواین پاشەکەوتی ئۆتۆماتیکی: <span className="text-white font-mono">2024-03-05 00:00</span></p>
                </div>
              </div>
            </div>
          )}

          {/* System Settings */}
          {activeTab === 'system' && (
            <div className="glass-panel p-8 rounded-3xl border border-white/10 space-y-8 animate-in fade-in slide-in-from-bottom-4 duration-500">
              <div className="space-y-4">
                <h3 className="text-xl font-bold text-white flex items-center gap-2">
                  <HardDrive className="text-cyan-400" />
                  بەڕێوەبردنی داتابەیس
                </h3>
                <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                  <div className="p-4 rounded-2xl bg-white/5 border border-white/5 flex items-center justify-between">
                    <div>
                      <h4 className="text-white font-bold">قەبارەی داتابەیس</h4>
                      <p className="text-sm text-slate-400">12.5 MB</p>
                    </div>
                    <button 
                      onClick={handleOptimizeDB}
                      className="px-4 py-2 bg-cyan-600/20 text-cyan-400 hover:bg-cyan-600/30 rounded-lg font-bold transition-colors flex items-center gap-2"
                    >
                      <RefreshCw size={16} />
                      باشترکردن
                    </button>
                  </div>
                  <div className="p-4 rounded-2xl bg-white/5 border border-white/5 flex items-center justify-between">
                    <div>
                      <h4 className="text-white font-bold">فایلە کاتییەکان</h4>
                      <p className="text-sm text-slate-400">٤٥ فایل (١٢٠ مێگابایت)</p>
                    </div>
                    <button className="px-4 py-2 bg-red-600/20 text-red-400 hover:bg-red-600/30 rounded-lg font-bold transition-colors flex items-center gap-2">
                      <Trash2 size={16} />
                      سڕینەوە
                    </button>
                  </div>
                </div>
              </div>

              <div className="space-y-4 pt-6 border-t border-white/5">
                <h3 className="text-xl font-bold text-white flex items-center gap-2">
                  <Server className="text-emerald-400" />
                  زانیاری سێرڤەر
                </h3>
                <div className="bg-black/30 rounded-2xl p-6 border border-white/10 font-mono text-lg text-emerald-400 select-all shadow-inner text-center tracking-wider">
                  http://{serverIp}:3000
                </div>
                <p className="text-center text-sm text-slate-400">ئەم ناونیشانە بەکاربێنە بۆ بەستنەوەی کۆمپیوتەرەکانی تر</p>
              </div>

              {/* Storage Management */}
              <div className="space-y-4 pt-6 border-t border-white/5">
                <h3 className="text-xl font-bold text-white flex items-center gap-2">
                  <HardDrive className="text-rose-400" />
                  بەڕێوەبردنی بیرگە
                </h3>
                <div className="bg-rose-500/10 rounded-2xl p-6 border border-rose-500/20 space-y-4">
                  <div className="flex items-start gap-3">
                    <FileX className="text-rose-400 shrink-0 mt-1" />
                    <div>
                      <h4 className="text-white font-bold">سڕینەوەی فایلە کۆنەکان</h4>
                      <p className="text-sm text-slate-400 mt-1">سڕینەوەی هەموو فایلە هاوپێچەکان (Attachments) کە پێش بەروارێکی دیاریکراو دروستکراون. تێبینی: نوسراوەکان خۆیان ناسڕێنەوە، تەنها فایلەکان.</p>
                    </div>
                  </div>
                  
                  <div className="flex items-center gap-4 pt-2">
                    <input 
                      type="date" 
                      value={cleanupDate}
                      onChange={(e) => setCleanupDate(e.target.value)}
                      className="bg-black/30 border border-white/10 rounded-xl px-4 py-2 text-white focus:border-rose-500 outline-none transition-colors"
                    />
                    <button 
                      onClick={handleCleanupAttachments}
                      className="px-6 py-2 bg-rose-600 hover:bg-rose-500 text-white rounded-xl font-bold transition-colors shadow-lg shadow-rose-600/20"
                    >
                      سڕینەوە
                    </button>
                  </div>
                </div>
              </div>

              {/* Logs Export */}
              <div className="space-y-4 pt-6 border-t border-white/5">
                <h3 className="text-xl font-bold text-white flex items-center gap-2">
                  <FileText className="text-blue-400" />
                  تۆماری چالاکیەکان
                </h3>
                <div className="flex items-center justify-between bg-white/5 p-4 rounded-2xl border border-white/5">
                  <div>
                    <h4 className="text-white font-bold">دابەزاندنی تۆمارەکان</h4>
                    <p className="text-sm text-slate-400">هەڵگرتنی هەموو چالاکیەکان وەک فایلێکی Excel/CSV</p>
                  </div>
                  <button 
                    onClick={handleExportLogs}
                    className="px-4 py-2 bg-blue-600/20 text-blue-400 hover:bg-blue-600/30 rounded-lg font-bold transition-colors flex items-center gap-2"
                  >
                    <Download size={16} />
                    ناردن بۆ CSV
                  </button>
                </div>
              </div>
            </div>
          )}

        </div>
      </div>
    </div>
  );
};
