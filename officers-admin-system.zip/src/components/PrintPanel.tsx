import React, { useState } from 'react';
import { useApp } from '../context';
import { Document, Attachment } from '../types';
import { Printer, Search, Filter, FileCheck, Archive, RotateCcw, AlertCircle, Eye, ArrowLeft, Building2, UserCheck, Clock, Paperclip, File, Download, MessageSquare, CheckCircle2, Layers } from 'lucide-react';
import { PrintLayout } from './PrintLayout';
import { WorkflowTimeline } from './WorkflowTimeline';
import printJS from 'print-js';
import { getActionLabel, getStatusLabel } from '../translations';

const ArchivedDocumentDetail: React.FC<{ doc: Document; onBack: () => void }> = ({ doc, onBack }) => {
  const handlePrintAttachment = (url: string, type: string, name: string) => {
    const a = document.createElement('a');
    a.href = url;
    a.download = name;
    document.body.appendChild(a);
    a.click();
    document.body.removeChild(a);
  };

  return (
    <div className="glass-panel rounded-3xl shadow-[0_0_50px_rgba(0,0,0,0.5)] border border-white/10 overflow-hidden animate-in fade-in zoom-in-95 duration-300" dir="rtl">
        {/* Header */}
        <div className="bg-white/5 p-6 border-b border-white/10 flex items-center justify-between backdrop-blur-xl">
            <button onClick={onBack} className="flex items-center gap-2 text-slate-400 hover:text-white transition-all group hover:-translate-x-1">
                <div className="p-2 rounded-full bg-white/5 group-hover:bg-white/10 transition-all shadow-[0_0_10px_rgba(255,255,255,0.05)] group-hover:shadow-[0_0_15px_rgba(255,255,255,0.1)]">
                  <ArrowLeft size={20} />
                </div>
                <span className="font-bold">گەڕانەوە</span>
            </button>
            <h2 className="text-2xl font-black text-white flex items-center gap-3 neon-text">
                <Archive className="text-blue-400" />
                وردەکاری نوسراوی ئەرشیفکراو
            </h2>
        </div>

        {/* Workflow Timeline */}
        <div className="bg-black/40 border-b border-white/10 p-8 backdrop-blur-xl">
             <WorkflowTimeline doc={doc} />
        </div>

        <div className="p-8 space-y-8">
            {/* Incoming Info */}
            <div className="bg-gradient-to-br from-white/5 to-transparent p-8 rounded-[2rem] border border-white/10 relative overflow-hidden group">
                 <div className="absolute top-0 right-0 w-32 h-32 bg-blue-500/10 rounded-bl-full -mr-10 -mt-10 transition-transform group-hover:scale-110 blur-xl" />
                 
                 <h3 className="text-lg font-black text-white mb-6 flex items-center gap-2 relative z-10">
                    <Building2 className="text-blue-400" />
                    زانیاری نوسراوی هاتوو
                 </h3>
                 
                 <div className="grid grid-cols-1 md:grid-cols-3 gap-8 relative z-10">
                    <div className="space-y-2">
                        <span className="text-xs font-bold text-slate-500 uppercase tracking-widest">سەرچاوە</span>
                        <div className="text-white font-bold text-lg bg-black/20 p-3 rounded-xl border border-white/5">{doc.source || '---'}</div>
                    </div>
                    <div className="space-y-2">
                        <span className="text-xs font-bold text-slate-500 uppercase tracking-widest">ژمارەی نوسراو</span>
                        <div className="text-white font-mono font-bold text-lg bg-black/20 p-3 rounded-xl border border-white/5">{doc.incomingNumber || '---'}</div>
                    </div>
                    <div className="space-y-2">
                        <span className="text-xs font-bold text-slate-500 uppercase tracking-widest">بەروار</span>
                        <div className="text-white font-mono font-bold text-lg bg-black/20 p-3 rounded-xl border border-white/5" dir="ltr">{doc.incomingDate || '---'}</div>
                    </div>
                 </div>
            </div>

            {/* Main Content */}
            <div className="space-y-6">
                <div>
                    <h1 className="text-3xl font-black text-white mb-3 leading-tight">{doc.title}</h1>
                    <div className="flex flex-wrap items-center gap-4 text-sm text-slate-400">
                        <span className="flex items-center gap-2 bg-white/5 px-3 py-1.5 rounded-lg border border-white/5"><UserCheck size={16} className="text-blue-400"/> نێرەر: <span className="text-white font-bold">{doc.senderName}</span></span>
                        <span className="flex items-center gap-2 bg-white/5 px-3 py-1.5 rounded-lg border border-white/5"><Clock size={16} className="text-blue-400"/> {new Date(doc.createdAt).toLocaleDateString('ckb-IQ')}</span>
                        <span className={`px-3 py-1.5 rounded-lg text-xs font-bold border ${doc.priority === 'Urgent' ? 'bg-orange-500/10 text-orange-400 border-orange-500/20' : 'bg-blue-500/10 text-blue-400 border-blue-500/20'}`}>{doc.priority}</span>
                    </div>
                </div>
                
                <div className="bg-white/5 p-8 rounded-[2rem] border border-white/10 text-slate-200 leading-loose whitespace-pre-wrap min-h-[200px] text-lg shadow-inner">
                    {doc.content}
                </div>
            </div>

            {/* Attachments */}
            {doc.attachments.length > 0 && (
                <div>
                    <h3 className="text-lg font-black text-white mb-6 flex items-center gap-2">
                        <Paperclip className="text-purple-400" />
                        هاوپێچەکان
                    </h3>
                    <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-4">
                        {doc.attachments.map((att, index) => (
                            <div key={index} className="flex items-center justify-between bg-white/5 p-4 rounded-2xl border border-white/10 hover:bg-white/10 hover:border-purple-500/30 transition-all group cursor-pointer hover:-translate-y-1">
                                <div className="flex items-center gap-4 overflow-hidden">
                                    <div className={`w-12 h-12 rounded-xl flex items-center justify-center text-white shadow-lg ${
                                        att.type === 'pdf' ? 'bg-red-500' : 
                                        att.type === 'word' ? 'bg-blue-500' : 
                                        'bg-slate-600'
                                    }`}>
                                        <File size={24} />
                                    </div>
                                    <div className="overflow-hidden">
                                        <span className="block text-sm font-bold text-white truncate">{att.name}</span>
                                        <div className="flex items-center gap-2">
                                          <span className="text-[10px] text-slate-400 uppercase font-mono">{att.type}</span>
                                          {att.uploadedBy && (
                                            <span className="text-[10px] text-blue-400/70 font-bold border-r border-white/10 pr-2">
                                              هاوپێچکراوە لەلایەن: {att.uploadedBy}
                                            </span>
                                          )}
                                        </div>
                                    </div>
                                </div>
                                <button 
                                    onClick={() => handlePrintAttachment(att.url, att.type, att.name)}
                                    className="p-3 bg-white/5 hover:bg-purple-600 hover:text-white rounded-xl text-slate-400 transition-all shadow-lg hover:shadow-[0_0_20px_rgba(147,51,234,0.4)] hover:-translate-y-1"
                                    title="بینین / داگرتن"
                                >
                                    <Download size={20} />
                                </button>
                            </div>
                        ))}
                    </div>
                </div>
            )}

            {/* History / Comments */}
            <div>
                <h3 className="text-lg font-black text-white mb-6 flex items-center gap-2">
                    <MessageSquare className="text-emerald-400" />
                    مێژووی نوسراو و تێبینییەکان
                </h3>
                <div className="space-y-6 relative before:absolute before:right-6 before:top-0 before:bottom-0 before:w-0.5 before:bg-gradient-to-b before:from-blue-500 before:to-purple-500 before:opacity-30">
                    {doc.history.map((item, index) => (
                        <div key={index} className="relative pr-14 group">
                            <div className={`absolute right-4 top-4 w-4 h-4 rounded-full border-4 border-slate-900 z-10 transition-all ${
                                item.action === 'approved' ? 'bg-emerald-500 shadow-[0_0_15px_rgba(16,185,129,0.6)]' :
                                item.action === 'rejected' ? 'bg-red-500 shadow-[0_0_15px_rgba(239,68,68,0.6)]' :
                                'bg-blue-500 shadow-[0_0_15px_rgba(59,130,246,0.6)]'
                            }`} />
                            <div className="bg-white/5 p-5 rounded-2xl border border-white/10 hover:bg-white/10 transition-colors">
                                <div className="flex justify-between items-start mb-3">
                                    <div>
                                        <span className="font-bold text-white block text-lg">{item.fromUser}</span>
                                        <span className="text-xs text-slate-400 font-bold uppercase tracking-wider">{getActionLabel(item.action)} {item.toUser ? `-> ${item.toUser}` : ''}</span>
                                    </div>
                                    <span className="text-xs text-slate-500 font-mono bg-black/30 px-2 py-1 rounded-lg" dir="ltr">
                                        {new Date(item.timestamp).toLocaleString('en-US')}
                                    </span>
                                </div>
                                {item.note && (
                                    <p className="text-sm text-slate-300 bg-black/20 p-4 rounded-xl border border-white/5 leading-relaxed">
                                        {item.note}
                                    </p>
                                )}
                            </div>
                        </div>
                    ))}
                </div>
            </div>
        </div>
    </div>
  );
};

export const PrintPanel: React.FC = () => {
  const { documents, updateDocument, users, currentUser, showToast } = useApp();
  const [activeTab, setActiveTab] = useState<'pending' | 'printed'>('pending');
  const [selectedDoc, setSelectedDoc] = useState<Document | null>(null);
  const [loading, setLoading] = useState<string | null>(null);
  
  // Return Modal State
  const [docToReturn, setDocToReturn] = useState<Document | null>(null);
  const [returnTargetId, setReturnTargetId] = useState('');
  const [returnReason, setReturnReason] = useState('');

  React.useEffect(() => {
    if (selectedDoc) {
      const updatedDoc = documents.find(d => d.id === selectedDoc.id);
      if (updatedDoc && updatedDoc !== selectedDoc) {
        setSelectedDoc(updatedDoc);
      }
    }
  }, [documents, selectedDoc?.id]); // Use id to avoid loop if selectedDoc reference changes

  // Filter Logic
  // Pending: Approved documents waiting for print
  const pendingDocs = React.useMemo(() => documents.filter(doc => doc.status === 'Approved'), [documents]);
  
  // Printed: Archived documents that have been printed
  const printedDocs = React.useMemo(() => documents.filter(doc => 
    doc.status === 'Archived' && 
    doc.history.some(h => h.action === 'printed')
  ), [documents]);

  // Statistics
  const printedToday = React.useMemo(() => {
    const today = new Date().toISOString().split('T')[0];
    return printedDocs.filter(doc => {
      const printHistory = doc.history.find(h => h.action === 'printed');
      return printHistory && printHistory.timestamp.startsWith(today);
    }).length;
  }, [printedDocs]);

  const handlePrintAttachment = (url: string, type: string, name: string) => {
    const a = document.createElement('a');
    a.href = url;
    a.download = name;
    document.body.appendChild(a);
    a.click();
    document.body.removeChild(a);
  };

  const markAsPrinted = async (doc: Document) => {
    setLoading(doc.id);
    try {
      await updateDocument(doc.id, {
        status: 'Archived',
        workflowStage: 'ARCHIVED',
        history: [...doc.history, {
          action: 'printed',
          fromUser: currentUser?.name,
          timestamp: new Date().toISOString(),
          note: 'نوسراوەکە بە سەرکەوتوویی پڕێنت کرا و ئەرشیف کرا'
        }]
      });
      showToast('نوسراوەکە بە سەرکەوتوویی پڕێنت کرا و نێردرا بۆ ئەرشیف', 'success');
    } catch (error) {
      console.error("Failed to mark as printed", error);
    } finally {
      setLoading(null);
    }
  };

  const [errorType, setErrorType] = useState('');
  const errorTypes = [
    'کەمی زانیاری',
    'هەڵە لە فایل',
    'پێویستی بە واژۆیە',
    'هەڵەی تەکنیکی',
    'تر...'
  ];

  const submitReturn = async () => {
    if (!docToReturn || !returnTargetId || !returnReason) return;
    setLoading(docToReturn.id);
    try {
      const targetUser = users.find(u => u.id === returnTargetId);
      let newStage = docToReturn.workflowStage;
      
      if (targetUser) {
          if (targetUser.role === 'section_director') newStage = 'DEPT_HEAD_IN';
          else if (targetUser.role === 'unit_head') newStage = 'UNIT_HEAD_IN';
          else if (targetUser.role === 'employee') newStage = 'EMPLOYEE_ACTION';
          else if (targetUser.role === 'deputy_director') newStage = 'DEPUTY_REVIEW';
          else if (targetUser.role === 'director_general') newStage = 'DIRECTOR_REVIEW';
          else if (targetUser.role === 'dispatch_staff') newStage = 'DISPATCH';
      }

      await updateDocument(docToReturn.id, {
        currentHolderId: returnTargetId,
        workflowStage: newStage,
        status: 'Pending',
        history: [...docToReturn.history, {
          action: 'returned',
          fromUser: currentUser?.name,
          toUser: targetUser?.name,
          timestamp: new Date().toISOString(),
          note: `[${errorType}] ${returnReason}`
        }]
      });
      showToast('نوسراوەکە بە سەرکەوتوویی گەڕێندرایەوە بۆ شوێنی مەبەست', 'success');
      setDocToReturn(null);
      setReturnReason('');
      setReturnTargetId('');
      setErrorType('');
    } catch (error) {
      console.error("Failed to return document", error);
    } finally {
      setLoading(null);
    }
  };

  if (selectedDoc) {
    return <ArchivedDocumentDetail doc={selectedDoc} onBack={() => setSelectedDoc(null)} />;
  }

  return (
    <div className="space-y-8" dir="rtl">
      {/* Header & Tabs */}
      <div className="flex flex-col md:flex-row items-center justify-between gap-6">
        <div>
          <h2 className="text-4xl font-black text-white flex items-center gap-4 neon-text">
            <div className="w-16 h-16 rounded-2xl bg-gradient-to-br from-blue-600 to-indigo-600 flex items-center justify-center shadow-[0_0_30px_rgba(37,99,235,0.5)]">
              <Printer size={32} className="text-white" />
            </div>
            وێستگەی پڕێنت
          </h2>
          <p className="text-slate-400 mt-2 font-medium">بەڕێوەبردنی پڕێنت و ئەرشیفکردنی نوسراوە پەسەندکراوەکان</p>
        </div>

        <div className="flex gap-4 p-2 bg-white/5 rounded-3xl border border-white/10 backdrop-blur-md">
          <div className="hidden sm:flex items-center gap-6 px-4 border-l border-white/10">
            <div className="text-center">
              <div className="text-2xl font-black text-blue-400">{pendingDocs.length}</div>
              <div className="text-[10px] text-slate-400 uppercase tracking-wider font-bold">چاوەڕێی پڕێنت</div>
            </div>
            <div className="text-center">
              <div className="text-2xl font-black text-emerald-400">{printedToday}</div>
              <div className="text-[10px] text-slate-400 uppercase tracking-wider font-bold">پڕێنتی ئەمڕۆ</div>
            </div>
          </div>
          <button
            onClick={() => setActiveTab('pending')}
            className={`relative px-8 py-3 rounded-2xl text-sm font-bold transition-all duration-500 flex items-center gap-3 overflow-hidden group ${
              activeTab === 'pending' 
                ? 'bg-white/10 text-white shadow-[0_0_20px_rgba(59,130,246,0.3)] scale-105 ring-1 ring-white/30 backdrop-blur-xl' 
                : 'bg-white/5 text-slate-400 hover:bg-white/10 hover:text-white'
            }`}
            style={activeTab === 'pending' ? {
              background: 'rgba(59, 130, 246, 0.2)',
              border: '1px solid rgba(255, 255, 255, 0.2)',
              boxShadow: '0 8px 32px 0 rgba(31, 38, 135, 0.37)',
            } : {}}
          >
            <div className={`absolute inset-0 bg-gradient-to-r from-transparent via-white/10 to-transparent translate-x-[-100%] group-hover:translate-x-[100%] transition-transform duration-1000 ${activeTab === 'pending' ? 'opacity-100' : 'opacity-0'}`} />
            <Printer size={18} className={`transition-transform duration-300 ${activeTab === 'pending' ? 'scale-110 text-blue-400' : 'group-hover:scale-110'}`} />
            <span className="relative z-10">بۆ پڕێنت ({pendingDocs.length})</span>
          </button>
          <button
            onClick={() => setActiveTab('printed')}
            className={`relative px-8 py-3 rounded-2xl text-sm font-bold transition-all duration-500 flex items-center gap-3 overflow-hidden group ${
              activeTab === 'printed' 
                ? 'bg-white/10 text-white shadow-[0_0_20px_rgba(16,185,129,0.3)] scale-105 ring-1 ring-white/30 backdrop-blur-xl' 
                : 'bg-white/5 text-slate-400 hover:bg-white/10 hover:text-white'
            }`}
            style={activeTab === 'printed' ? {
              background: 'rgba(16, 185, 129, 0.2)',
              border: '1px solid rgba(255, 255, 255, 0.2)',
              boxShadow: '0 8px 32px 0 rgba(31, 38, 135, 0.37)',
            } : {}}
          >
            <div className={`absolute inset-0 bg-gradient-to-r from-transparent via-white/10 to-transparent translate-x-[-100%] group-hover:translate-x-[100%] transition-transform duration-1000 ${activeTab === 'printed' ? 'opacity-100' : 'opacity-0'}`} />
            <Archive size={18} className={`transition-transform duration-300 ${activeTab === 'printed' ? 'scale-110 text-emerald-400' : 'group-hover:scale-110'}`} />
            <span className="relative z-10">ئەرشیفی پڕێنت ({printedDocs.length})</span>
          </button>
        </div>
      </div>

      {/* Content Grid */}
      <div className="grid grid-cols-1 gap-6">
        {(activeTab === 'pending' ? pendingDocs : printedDocs).length === 0 ? (
          <div className="text-center py-32 glass-panel rounded-[3rem] border border-dashed border-white/10 flex flex-col items-center justify-center">
            <div className="w-24 h-24 rounded-full bg-white/5 flex items-center justify-center mb-6 animate-pulse">
              <FileCheck className="text-slate-600" size={48} />
            </div>
            <h3 className="text-2xl font-bold text-white mb-2">هیچ نوسراوێک نییە</h3>
            <p className="text-slate-500">
              {activeTab === 'pending' ? 'هیچ نوسراوێکی پەسەندکراو نییە بۆ پڕێنت' : 'هیچ نوسراوێکی پڕێنتکراو لە ئەرشیف نییە'}
            </p>
          </div>
        ) : (
          (activeTab === 'pending' ? pendingDocs : printedDocs).map(doc => (
            <div key={doc.id} className="glass-panel p-8 rounded-[2.5rem] border border-white/10 shadow-2xl hover:border-blue-500/30 transition-all duration-500 group relative overflow-hidden">
              {/* Background Glow */}
              <div className="absolute top-0 right-0 w-64 h-64 bg-blue-600/5 rounded-full blur-[80px] -mr-20 -mt-20 group-hover:bg-blue-600/10 transition-colors" />
              
              <div className="relative z-10 flex flex-col xl:flex-row items-start xl:items-center justify-between gap-8">
                {/* Doc Info */}
                <div className="flex-1 space-y-4">
                  <div className="flex flex-wrap items-center gap-3">
                    <span className="bg-blue-500/20 text-blue-400 px-3 py-1 rounded-lg text-xs font-mono border border-blue-500/30">
                      {doc.referenceNumber}
                    </span>
                    {doc.incomingNumber && (
                      <span className="bg-purple-500/20 text-purple-400 px-3 py-1 rounded-lg text-xs font-mono border border-purple-500/30">
                        ژمارەی هاتوو: {doc.incomingNumber}
                      </span>
                    )}
                    <span className="text-slate-500 text-xs font-bold uppercase tracking-widest flex items-center gap-1">
                      <Clock size={12} />
                      {new Date(doc.createdAt).toLocaleDateString('ckb-IQ')}
                    </span>
                  </div>
                  
                  <h3 className="text-2xl font-black text-white leading-tight group-hover:text-blue-400 transition-colors">
                    {doc.title}
                  </h3>
                  
                  <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4 text-sm">
                    <div className="flex items-center gap-3 text-slate-400">
                      <div className="w-8 h-8 rounded-full bg-white/10 flex items-center justify-center text-white font-bold text-xs">
                        {doc.senderName.charAt(0)}
                      </div>
                      <div>
                        <span className="block text-xs text-slate-500">نێرەر</span>
                        <span className="font-bold text-slate-200">{doc.senderName}</span>
                      </div>
                    </div>
                    <div>
                      <span className="block text-xs text-slate-500">سەرچاوە</span>
                      <span className="font-bold text-slate-200">{doc.source || doc.senderDepartment}</span>
                    </div>
                    <div>
                      <span className="block text-xs text-slate-500">ژووری پەیوەندیدار</span>
                      <span className="font-bold text-blue-400">{doc.relatedRoomName || 'دیاری نەکراوە'}</span>
                    </div>
                  </div>
                </div>

                {/* Attachments List */}
                <div className="flex-1 w-full xl:w-auto bg-black/20 rounded-2xl p-5 border border-white/5">
                  <h4 className="text-xs font-bold text-slate-500 uppercase tracking-widest mb-4 flex items-center gap-2">
                    <Paperclip size={14} className="text-purple-400" />
                    هاوپێچەکان و باری کارکردن
                  </h4>
                  {doc.attachments.length === 0 ? (
                    <p className="text-slate-600 text-sm italic">هیچ هاوپێچێک نییە</p>
                  ) : (
                    <div className="space-y-3">
                      {doc.attachments.map(att => (
                        <div key={att.id} className="flex items-center justify-between bg-white/5 p-2 rounded-xl border border-white/5 group/att">
                          <div className="flex items-center gap-3 overflow-hidden">
                            <div className="p-2 rounded-lg bg-white/5 text-slate-400">
                              <File size={16} />
                            </div>
                            <div className="overflow-hidden">
                              <span className="block text-xs font-bold text-white truncate">{att.name}</span>
                              <div className="flex items-center gap-2">
                                <span className="text-[10px] text-slate-500 uppercase">{att.type}</span>
                                {att.uploadedBy && (
                                  <span className="text-[10px] text-blue-400/70 font-bold border-r border-white/10 pr-2">
                                    لەلایەن: {att.uploadedBy}
                                  </span>
                                )}
                              </div>
                            </div>
                          </div>
                          <button 
                            onClick={() => handlePrintAttachment(att.url, att.type, att.name)}
                            className="p-2 bg-white/5 hover:bg-blue-600 hover:text-white rounded-lg text-slate-400 transition-all"
                          >
                            <Download size={14} />
                          </button>
                        </div>
                      ))}
                    </div>
                  )}
                </div>

                {/* Actions */}
                <div className="flex flex-col sm:flex-row xl:flex-col gap-3 w-full xl:w-auto">
                  {activeTab === 'pending' ? (
                    <>
                      <button
                        onClick={() => setSelectedDoc(doc)}
                        className="px-6 py-4 rounded-2xl bg-white/5 hover:bg-white/10 text-white font-bold border border-white/10 transition-all flex items-center justify-center gap-2 hover:shadow-[0_0_15px_rgba(255,255,255,0.1)] hover:-translate-y-1 backdrop-blur-md"
                      >
                        <Eye size={20} />
                        وردەکاری
                      </button>
                      <button
                        onClick={() => setDocToReturn(doc)}
                        className="px-8 py-4 rounded-2xl font-black transition-all flex items-center justify-center gap-2 transform hover:-translate-y-1 border border-white/20 backdrop-blur-xl"
                        style={{
                          background: 'rgba(245, 158, 11, 0.2)',
                          color: '#fbbf24',
                          boxShadow: '0 8px 32px 0 rgba(245, 158, 11, 0.2)',
                        }}
                      >
                        <RotateCcw size={20} />
                        گەڕاندنەوە بەهۆی هەڵە
                      </button>
                      <button
                        onClick={() => markAsPrinted(doc)}
                        disabled={loading === doc.id}
                        className="px-8 py-4 rounded-2xl font-black transition-all flex items-center justify-center gap-2 disabled:opacity-50 disabled:cursor-not-allowed transform hover:-translate-y-1 border border-white/20 backdrop-blur-xl"
                        style={{
                          background: 'rgba(16, 185, 129, 0.2)',
                          color: '#34d399',
                          boxShadow: '0 8px 32px 0 rgba(16, 185, 129, 0.2)',
                        }}
                      >
                        {loading === doc.id ? (
                          <div className="w-5 h-5 border-2 border-white/30 border-t-white rounded-full animate-spin" />
                        ) : (
                          <>
                            <Printer size={20} />
                            پڕێنت و ئەرشیفکردن
                          </>
                        )}
                      </button>
                    </>
                  ) : (
                    <button
                      onClick={() => setSelectedDoc(doc)}
                      className="px-8 py-4 rounded-2xl bg-white/5 hover:bg-blue-600/20 hover:text-blue-400 text-slate-300 font-bold border border-white/10 transition-all flex items-center justify-center gap-2 w-full sm:w-auto hover:shadow-[0_0_20px_rgba(37,99,235,0.3)] hover:-translate-y-1 backdrop-blur-md"
                    >
                      <Eye size={20} />
                      بینینی ئەرشیف
                    </button>
                  )}
                </div>
              </div>
            </div>
          ))
        )}
      </div>

      {/* Return Modal */}
      {docToReturn && (
        <div className="fixed inset-0 bg-black/80 backdrop-blur-md z-[60] flex items-center justify-center p-4 animate-in fade-in duration-200">
          <div className="glass-panel rounded-[2.5rem] w-full max-w-lg shadow-2xl overflow-hidden animate-in zoom-in-95 duration-200 border border-white/10">
            <div className="p-8 border-b border-white/10 flex justify-between items-center bg-white/5 backdrop-blur-md">
              <h3 className="text-2xl font-black text-white neon-text flex items-center gap-3">
                <div className="p-3 rounded-2xl bg-amber-500/20 text-amber-400">
                  <RotateCcw size={24} />
                </div>
                گەڕاندنەوەی نوسراو
              </h3>
              <button onClick={() => setDocToReturn(null)} className="p-3 hover:bg-white/10 rounded-2xl transition-all">
                <AlertCircle size={24} className="text-slate-400 hover:text-white" />
              </button>
            </div>
            
            <div className="p-8 space-y-6">
              <div className="bg-amber-500/10 border border-amber-500/20 rounded-2xl p-5 text-amber-200 text-sm leading-relaxed flex gap-3">
                <AlertCircle className="shrink-0" size={20} />
                تکایە جۆری هەڵەکە و هۆکاری گەڕاندنەوەی ئەم نوسراوە بنووسە بۆ ئەوەی شوێنی پەیوەندیدار بتوانێت چاکی بکات.
              </div>

              <div className="grid grid-cols-2 gap-4">
                <div className="col-span-2">
                  <label className="block text-sm font-bold text-slate-400 mb-2 mr-2">جۆری هەڵە</label>
                  <div className="flex flex-wrap gap-2">
                    {errorTypes.map(type => (
                      <button
                        key={type}
                        onClick={() => setErrorType(type)}
                        className={`px-4 py-2 rounded-xl text-xs font-bold transition-all border ${
                          errorType === type 
                            ? 'bg-amber-500 text-white border-amber-400 shadow-[0_0_15px_rgba(245,158,11,0.4)]' 
                            : 'bg-white/5 text-slate-400 border-white/10 hover:bg-white/10'
                        }`}
                      >
                        {type}
                      </button>
                    ))}
                  </div>
                </div>

                <div className="col-span-2">
                  <label className="block text-sm font-bold text-slate-400 mb-2 mr-2">گەڕاندنەوە بۆ</label>
                  <select
                    value={returnTargetId}
                    onChange={e => setReturnTargetId(e.target.value)}
                    className="w-full bg-black/40 border border-white/10 rounded-2xl px-5 py-4 text-white focus:border-amber-500 outline-none transition-all appearance-none shadow-inner"
                  >
                    <option value="">هەڵبژێرە...</option>
                    {users.filter(u => u.id !== currentUser?.id).map(u => (
                      <option key={u.id} value={u.id}>{u.name} - {u.role}</option>
                    ))}
                  </select>
                </div>
              </div>

              <div>
                <label className="block text-sm font-bold text-slate-400 mb-2 mr-2">تێبینی زیاتر</label>
                <textarea
                  value={returnReason}
                  onChange={e => setReturnReason(e.target.value)}
                  className="w-full px-5 py-4 rounded-2xl bg-black/40 border border-white/10 focus:border-amber-500 outline-none text-white transition-all h-32 resize-none placeholder:text-slate-600 shadow-inner"
                  placeholder="هۆکاری گەڕاندنەوە بە وردی بنووسە..."
                />
              </div>

              <button
                onClick={submitReturn}
                disabled={loading === docToReturn.id || !returnTargetId || !returnReason || !errorType}
                className="w-full bg-gradient-to-r from-amber-600 to-amber-500 hover:from-amber-500 hover:to-amber-400 text-white py-5 rounded-2xl font-black flex items-center justify-center gap-3 hover:-translate-y-1 transition-all shadow-[0_10px_30px_rgba(245,158,11,0.3)] hover:shadow-[0_15px_40px_rgba(245,158,11,0.4)] disabled:opacity-50 disabled:cursor-not-allowed border border-white/20"
              >
                {loading === docToReturn.id ? (
                  <div className="w-6 h-6 border-3 border-white/30 border-t-white rounded-full animate-spin" />
                ) : (
                  <>
                    <RotateCcw size={20} />
                    گەڕاندنەوە بۆ چاککردن
                  </>
                )}
              </button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
};

export const ArchivePanel: React.FC = () => {
  const { getVisibleDocuments, documents, currentUser, users, departments } = useApp();
  const [selectedDoc, setSelectedDoc] = useState<Document | null>(null);
  const [searchTerm, setSearchTerm] = useState('');
  const [dateFilter, setDateFilter] = useState('');

  const docs = React.useMemo(() => getVisibleDocuments(), [getVisibleDocuments]);

  React.useEffect(() => {
    if (selectedDoc) {
      const updatedDoc = docs.find(d => d.id === selectedDoc.id);
      if (updatedDoc && updatedDoc !== selectedDoc) {
        setSelectedDoc(updatedDoc);
      }
    }
  }, [docs, selectedDoc?.id]);

  const getArchivingDepartment = (doc: Document) => {
    const archiveAction = doc.history?.find(h => h.action === 'archive' || h.action === 'print_and_archive');
    if (archiveAction) {
      const user = users.find(u => u.id === archiveAction.fromUser);
      if (user) {
        const dept = departments.find(d => d.id === user.department);
        return dept ? dept.name : user.department;
      }
    }
    // Fallback to current holder if no history
    const holderDept = departments.find(d => d.id === doc.currentHolderId);
    if (holderDept) return holderDept.name;
    const holderUser = users.find(u => u.id === doc.currentHolderId);
    if (holderUser) {
      const dept = departments.find(d => d.id === holderUser.department);
      return dept ? dept.name : holderUser.department;
    }
    return 'نەزانراو';
  };

  const getSource = (doc: Document) => {
    if (doc.source) return doc.source;
    const dept = departments.find(d => d.id === doc.senderDepartment);
    return dept ? dept.name : doc.senderDepartment;
  };

  const archivedDocs = React.useMemo(() => {
    return [...docs]
      .filter(doc => {
        // Must be archived
        if (doc.status !== 'Archived' && doc.workflowStage !== 'ARCHIVED') return false;

        // Must be a participant or sender (enforce for everyone)
        const isParticipant = 
          doc.senderId === currentUser?.id ||
          doc.participants?.includes(currentUser?.id || '') ||
          doc.participants?.includes(currentUser?.department || '');
        
        if (!isParticipant) return false;

        const matchesSearch = 
          doc.title.toLowerCase().includes(searchTerm.toLowerCase()) ||
          doc.referenceNumber.toLowerCase().includes(searchTerm.toLowerCase()) ||
          (doc.incomingNumber && doc.incomingNumber.toLowerCase().includes(searchTerm.toLowerCase())) ||
          doc.senderName.toLowerCase().includes(searchTerm.toLowerCase());
        
        const matchesDate = dateFilter ? doc.createdAt.startsWith(dateFilter) : true;
        
        return matchesSearch && matchesDate;
      })
      .sort((a, b) => new Date(b.createdAt).getTime() - new Date(a.createdAt).getTime());
  }, [docs, currentUser, searchTerm, dateFilter]);

  const getStatusBadge = (status: string) => {
    switch (status) {
      case 'Approved': return <span className="badge-glow badge-success bg-emerald-500/10 text-emerald-400 border-emerald-500/20">پەسەندکراو</span>;
      case 'Rejected': return <span className="badge-glow badge-error bg-red-500/10 text-red-400 border-red-500/20">ڕەتکراوە</span>;
      case 'Archived': return <span className="badge-glow badge-info bg-blue-500/10 text-blue-400 border-blue-500/20">ئەرشیفکراو</span>;
      default: return <span className="badge-glow badge-warning bg-yellow-500/10 text-yellow-400 border-yellow-500/20">لە کارکردندان</span>;
    }
  };

  const exportArchive = () => {
    const headers = ['ژمارەی نوسراو', 'ناونیشان', 'لەکوێوە هاتووە', 'بەشی تەواوکەر', 'نێرەر', 'بەروار', 'دۆخ'];
    const csvContent = [
      headers.join(','),
      ...archivedDocs.map(doc => {
        return [
          doc.referenceNumber,
          `"${doc.title}"`,
          `"${getSource(doc)}"`,
          `"${getArchivingDepartment(doc)}"`,
          `"${doc.senderName}"`,
          new Date(doc.createdAt).toLocaleDateString('en-US'),
          doc.status
        ].join(',');
      })
    ].join('\n');

    const blob = new Blob([csvContent], { type: 'text/csv;charset=utf-8;' });
    const link = document.createElement('a');
    link.href = URL.createObjectURL(blob);
    link.download = `archive_report_${new Date().toISOString().split('T')[0]}.csv`;
    link.click();
  };

  if (selectedDoc) {
    return <ArchivedDocumentDetail doc={selectedDoc} onBack={() => setSelectedDoc(null)} />;
  }

  return (
    <div className="space-y-6" dir="rtl">
      <div className="flex flex-col md:flex-row items-center justify-between gap-4">
        <h2 className="text-2xl font-bold text-white flex items-center gap-2 neon-text">
          <Archive className="text-blue-400 drop-shadow-[0_0_8px_rgba(59,130,246,0.8)]" />
          ئەرشیفی نوسراوەکان
        </h2>
        
        <div className="flex flex-wrap items-center gap-3 w-full md:w-auto">
          {/* Search Input */}
          <div className="relative flex-1 md:w-64">
            <input
              type="text"
              value={searchTerm}
              onChange={(e) => setSearchTerm(e.target.value)}
              placeholder="گەڕان بەپێی ناونیشان، ژمارە..."
              className="w-full bg-white/5 border border-white/10 rounded-xl px-4 py-2 pl-10 text-white focus:border-blue-500 outline-none transition-colors"
            />
            <Search className="absolute left-3 top-2.5 text-slate-400" size={18} />
          </div>

          {/* Date Filter */}
          <div className="relative">
            <input
              type="date"
              value={dateFilter}
              onChange={(e) => setDateFilter(e.target.value)}
              className="bg-white/5 border border-white/10 rounded-xl px-4 py-2 text-white focus:border-blue-500 outline-none transition-colors"
            />
          </div>

          <button
            onClick={exportArchive}
            className="bg-white/10 hover:bg-white/20 text-white px-4 py-2 rounded-xl font-medium flex items-center gap-2 transition-all shadow-[0_0_15px_rgba(255,255,255,0.1)] hover:shadow-[0_0_25px_rgba(255,255,255,0.2)] hover:-translate-y-0.5 border border-white/20 backdrop-blur-md"
          >
            <FileCheck size={18} />
            دابەزاندن
          </button>
        </div>
      </div>

      <div className="bg-white/5 rounded-2xl shadow-sm border border-white/10 overflow-hidden">
        <div className="overflow-x-auto">
          <table className="elite-table text-right w-full">
            <thead>
              <tr>
                <th className="whitespace-nowrap">ژمارەی نوسراو</th>
                <th>ناونیشان</th>
                <th>لەکوێوە هاتووە</th>
                <th>بەشی تەواوکەر</th>
                <th>نێرەر</th>
                <th>بەروار</th>
                <th>دۆخ</th>
                <th>کردارەکان</th>
              </tr>
            </thead>
            <tbody>
              {archivedDocs.map(doc => (
                <tr key={doc.id} className="group hover:bg-white/5 transition-colors">
                  <td className="font-mono text-blue-300 font-bold whitespace-nowrap">
                    {doc.referenceNumber}
                    {doc.incomingNumber && (
                      <span className="block text-xs text-slate-500 mt-1">هاتوو: {doc.incomingNumber}</span>
                    )}
                  </td>
                  <td className="font-medium text-white group-hover:text-blue-400 transition-colors">
                    {doc.title}
                  </td>
                  <td className="text-slate-300">{getSource(doc)}</td>
                  <td className="text-slate-300">{getArchivingDepartment(doc)}</td>
                  <td className="text-slate-300">{doc.senderName}</td>
                  <td className="text-slate-400 text-sm font-mono" dir="ltr">
                    {new Date(doc.createdAt).toLocaleDateString('ckb-IQ')}
                  </td>
                  <td>
                    {getStatusLabel(doc.status)}
                  </td>
                  <td>
                    <button 
                      onClick={() => setSelectedDoc(doc)}
                      className="text-blue-400 hover:text-white hover:bg-blue-500/20 p-2 rounded-lg transition-all flex items-center gap-2 hover:shadow-[0_0_10px_rgba(59,130,246,0.2)] hover:-translate-y-0.5"
                    >
                      <Eye size={18} />
                      <span className="text-sm hidden sm:inline">بینین</span>
                    </button>
                  </td>
                </tr>
              ))}
              {archivedDocs.length === 0 && (
                <tr>
                  <td colSpan={8} className="text-center py-12 text-slate-500">
                    هیچ نوسراوێک نەدۆزرایەوە
                  </td>
                </tr>
              )}
            </tbody>
          </table>
        </div>
      </div>
    </div>
  );
};
