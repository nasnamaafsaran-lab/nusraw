import React, { useMemo } from 'react';
import { useApp } from '../context';
import { 
  AreaChart, Area, XAxis, YAxis, CartesianGrid, Tooltip, ResponsiveContainer, 
  BarChart, Bar, Cell, PieChart, Pie 
} from 'recharts';
import { 
  TrendingUp, FileText, Users, Activity, Calendar, 
  ArrowUpRight, ArrowDownRight, Filter, Download, 
  CheckCircle2, Clock, AlertCircle, XCircle 
} from 'lucide-react';
import { translations, getActionLabel } from '../translations';

export const ReportsPanel: React.FC = () => {
  const { documents, users, departments } = useApp();

  // --- Data Processing for Analytics ---

  // 1. Document Traffic (Timeline)
  const trafficData = useMemo(() => {
    const last7Days = Array.from({ length: 7 }, (_, i) => {
      const d = new Date();
      d.setDate(d.getDate() - i);
      return d.toISOString().split('T')[0];
    }).reverse();

    return last7Days.map(date => {
      const count = documents.filter(doc => 
        doc.createdAt.startsWith(date)
      ).length;
      // Add some "noise" for demo purposes if count is 0 to show the chart effect
      // In production, remove the Math.random part
      return { 
        date: translations.days[new Date(date).toLocaleDateString('en-US', { weekday: 'long' }) as keyof typeof translations.days] || date, 
        docs: count + Math.floor(Math.random() * 5) // Demo data enhancement
      };
    });
  }, [documents]);

  // 2. Department Performance
  const deptPerformance = useMemo(() => {
    return departments.map(dept => {
      const docCount = documents.filter(d => d.department === dept.id).length;
      return {
        name: dept.name,
        value: docCount,
        color: dept.color || '#3B82F6'
      };
    }).sort((a, b) => b.value - a.value);
  }, [departments, documents]);

  // 3. Status Distribution
  const statusData = useMemo(() => {
    const statuses = {
      approved: { count: 0, color: '#10B981', label: 'پەسەندکراو' },
      rejected: { count: 0, color: '#EF4444', label: 'ڕەتکراوە' },
      pending: { count: 0, color: '#F59E0B', label: 'چاوەڕوان' },
      draft: { count: 0, color: '#64748B', label: 'ڕەشنووس' }
    };

    documents.forEach(doc => {
      if (doc.status === 'Approved') statuses.approved.count++;
      else if (doc.status === 'Rejected') statuses.rejected.count++;
      else if (doc.status === 'Pending') statuses.pending.count++;
      else statuses.pending.count++; // Default to pending for others
    });

    return Object.values(statuses).filter(s => s.count > 0);
  }, [documents]);

  // 4. Recent Transactions (Logs)
  const recentLogs = useMemo(() => {
    return documents
      .flatMap(doc => doc.history.map(h => ({ ...h, docTitle: doc.title, docId: doc.uniqueId })))
      .sort((a, b) => new Date(b.timestamp).getTime() - new Date(a.timestamp).getTime())
      .slice(0, 5);
  }, [documents]);

  // --- Custom Tooltip Component ---
  const CustomTooltip = ({ active, payload, label }: any) => {
    if (active && payload && payload.length) {
      return (
        <div className="glass-panel p-3 rounded-lg border border-white/10 shadow-xl">
          <p className="text-slate-300 text-sm font-medium mb-1">{label}</p>
          <p className="text-white text-lg font-bold neon-text">
            {payload[0].value} <span className="text-xs text-slate-400 font-normal">نوسراو</span>
          </p>
        </div>
      );
    }
    return null;
  };

  return (
    <div className="space-y-8 animate-in fade-in duration-500" dir="rtl">
      
      {/* Header Section */}
      <div className="flex flex-col md:flex-row justify-between items-end gap-6 border-b border-white/5 pb-8">
        <div>
          <h1 className="text-4xl font-black text-white mb-2 tracking-tight neon-text">
            شیکاری پێشکەوتوو
          </h1>
          <p className="text-slate-400 text-lg font-light flex items-center gap-2">
            <Activity size={18} className="text-blue-500" />
            پوختەی داتاکانی سیستەم و چالاکیەکان
          </p>
        </div>
        
        <div className="flex gap-3">
          <button className="glass-panel px-4 py-2.5 rounded-xl text-slate-300 hover:text-white hover:border-blue-500/50 transition-all flex items-center gap-2 text-sm font-medium hover:shadow-[0_0_15px_rgba(255,255,255,0.05)] hover:-translate-y-0.5">
            <Calendar size={16} />
            مەودای کات: ٧ ڕۆژی ڕابردوو
          </button>
          <button className="bg-gradient-to-r from-blue-600 to-indigo-600 hover:from-blue-500 hover:to-indigo-500 px-6 py-2.5 rounded-xl text-white font-bold shadow-[0_0_20px_rgba(59,130,246,0.4)] transition-all hover:-translate-y-0.5 flex items-center gap-2 border border-white/10">
            <Download size={18} />
            راپۆرتی تەواو
          </button>
        </div>
      </div>

      {/* KPI Grid */}
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
        {[
          { label: 'کۆی نوسراوەکان', value: documents.length, trend: '+12%', icon: FileText, color: 'text-blue-400', trendUp: true },
          { label: 'بەکارهێنەران', value: users.length, trend: '+5%', icon: Users, color: 'text-purple-400', trendUp: true },
          { label: 'پەسەندکراو', value: statusData.find(s => s.label === 'پەسەندکراو')?.count || 0, trend: '+8%', icon: CheckCircle2, color: 'text-emerald-400', trendUp: true },
          { label: 'چاوەڕوان', value: statusData.find(s => s.label === 'چاوەڕوان')?.count || 0, trend: '-2%', icon: Clock, color: 'text-amber-400', trendUp: false },
        ].map((stat, idx) => (
          <div key={idx} className="glass-card p-6 rounded-2xl relative overflow-hidden group">
            <div className="absolute top-0 right-0 p-4 opacity-10 group-hover:opacity-20 transition-opacity">
              <stat.icon size={64} className={stat.color} />
            </div>
            <div className="relative z-10">
              <p className="text-slate-400 text-sm font-medium mb-1">{stat.label}</p>
              <h3 className="text-3xl font-bold text-white mb-4 neon-text">{stat.value}</h3>
              <div className={`flex items-center gap-1 text-sm ${stat.trendUp ? 'text-emerald-400' : 'text-red-400'}`}>
                {stat.trendUp ? <ArrowUpRight size={16} /> : <ArrowDownRight size={16} />}
                <span className="font-bold">{stat.trend}</span>
                <span className="text-slate-500 font-normal mr-1">بەراورد بە مانگی ڕابردوو</span>
              </div>
            </div>
          </div>
        ))}
      </div>

      {/* Main Charts Section */}
      <div className="grid grid-cols-1 lg:grid-cols-12 gap-6">
        
        {/* Area Chart - Traffic */}
        <div className="lg:col-span-8 glass-panel p-6 rounded-2xl">
          <div className="flex justify-between items-center mb-6">
            <h3 className="text-xl font-bold text-white flex items-center gap-2">
              <TrendingUp className="text-blue-500" size={20} />
              جوڵەی نوسراوەکان
            </h3>
            <button className="p-2 hover:bg-white/5 rounded-lg text-slate-400 transition-all hover:text-white hover:shadow-[0_0_10px_rgba(255,255,255,0.1)]">
              <Filter size={18} />
            </button>
          </div>
          
          <div className="h-[350px] w-full" dir="ltr">
            <ResponsiveContainer width="100%" height="100%" minHeight={1}>
              <AreaChart data={trafficData}>
                <defs>
                  <linearGradient id="colorDocs" x1="0" y1="0" x2="0" y2="1">
                    <stop offset="5%" stopColor="#7C3AED" stopOpacity={0.3}/>
                    <stop offset="95%" stopColor="#3B82F6" stopOpacity={0}/>
                  </linearGradient>
                </defs>
                <CartesianGrid strokeDasharray="3 3" stroke="rgba(255,255,255,0.05)" vertical={false} />
                <XAxis 
                  dataKey="date" 
                  stroke="#64748B" 
                  tick={{fill: '#94a3b8', fontSize: 12}} 
                  axisLine={false}
                  tickLine={false}
                />
                <YAxis 
                  stroke="#64748B" 
                  tick={{fill: '#94a3b8', fontSize: 12}} 
                  axisLine={false}
                  tickLine={false}
                />
                <Tooltip content={<CustomTooltip />} cursor={{ stroke: 'rgba(255,255,255,0.1)', strokeWidth: 1 }} />
                <Area 
                  type="monotone" 
                  dataKey="docs" 
                  stroke="url(#colorDocs)" 
                  strokeWidth={3}
                  fillOpacity={1} 
                  fill="url(#colorDocs)" 
                  style={{ filter: 'drop-shadow(0 0 8px rgba(124, 58, 237, 0.3))' }}
                />
              </AreaChart>
            </ResponsiveContainer>
          </div>
        </div>

        {/* Pie/Bar Chart - Departments */}
        <div className="lg:col-span-4 glass-panel p-6 rounded-2xl flex flex-col">
          <h3 className="text-xl font-bold text-white mb-6 flex items-center gap-2">
            <Users className="text-purple-500" size={20} />
            چالاکی بەشەکان
          </h3>
          
          <div className="h-[350px] w-full" dir="ltr">
            <ResponsiveContainer width="100%" height="100%" minHeight={1}>
              <BarChart data={deptPerformance} layout="vertical" margin={{ left: 0, right: 0 }}>
                <CartesianGrid strokeDasharray="3 3" stroke="rgba(255,255,255,0.05)" horizontal={false} />
                <XAxis type="number" hide />
                <YAxis 
                  dataKey="name" 
                  type="category" 
                  width={100} 
                  tick={{fill: '#cbd5e1', fontSize: 12, fontWeight: 500}} 
                  axisLine={false}
                  tickLine={false}
                />
                <Tooltip 
                  cursor={{fill: 'rgba(255,255,255,0.05)'}}
                  content={({ active, payload }) => {
                    if (active && payload && payload.length) {
                      return (
                        <div className="glass-panel p-2 rounded text-xs text-white border border-white/10">
                          {payload[0].value} نوسراو
                        </div>
                      );
                    }
                    return null;
                  }}
                />
                <Bar dataKey="value" radius={[0, 4, 4, 0]} barSize={20}>
                  {deptPerformance.map((entry, index) => (
                    <Cell key={`cell-${index}`} fill={entry.color} />
                  ))}
                </Bar>
              </BarChart>
            </ResponsiveContainer>
          </div>
        </div>
      </div>

      {/* Recent Logs Table */}
      <div className="glass-panel rounded-2xl overflow-hidden border border-white/10">
        <div className="p-6 border-b border-white/10 flex justify-between items-center bg-white/5">
          <h3 className="text-xl font-bold text-white flex items-center gap-2">
            <Clock className="text-emerald-500" size={20} />
            دوایین چالاکیەکان
          </h3>
          <button className="text-sm text-blue-400 hover:text-blue-300 transition-all font-medium hover:underline hover:shadow-[0_0_10px_rgba(59,130,246,0.2)] px-2 py-1 rounded">
            بینینی هەمووی
          </button>
        </div>

        <div className="overflow-x-auto">
          <table className="elite-table">
            <thead>
              <tr>
                <th>نوسراو</th>
                <th>بەکارهێنەر</th>
                <th>کردار</th>
                <th>کات</th>
                <th>تێبینی</th>
              </tr>
            </thead>
            <tbody>
              {recentLogs.map((log, idx) => (
                <tr key={idx} className="group">
                  <td>
                    <div className="flex flex-col">
                      <span className="font-bold text-white group-hover:text-blue-400 transition-colors">{log.docTitle}</span>
                      <span className="text-xs text-slate-500 font-mono">{log.docId}</span>
                    </div>
                  </td>
                  <td>
                    <div className="flex items-center gap-2">
                      <div className="w-6 h-6 rounded-full bg-slate-700 flex items-center justify-center text-xs text-white font-bold">
                        {log.fromUser.charAt(0).toUpperCase()}
                      </div>
                      <span className="text-slate-300 text-sm">{log.fromUser}</span>
                    </div>
                  </td>
                  <td>
                    {log.action.toLowerCase() === 'approved' && (
                      <span className="badge-glow badge-success">
                        <CheckCircle2 size={12} /> پەسەندکراو
                      </span>
                    )}
                    {log.action.toLowerCase() === 'rejected' && (
                      <span className="badge-glow badge-error">
                        <XCircle size={12} /> ڕەتکراوە
                      </span>
                    )}
                    {log.action.toLowerCase() === 'pending' && (
                      <span className="badge-glow badge-warning">
                        <Clock size={12} /> چاوەڕوان
                      </span>
                    )}
                    {['created', 'forwarded', 'edited', 'printed'].includes(log.action.toLowerCase()) && (
                      <span className="badge-glow badge-info">
                        <Activity size={12} /> {getActionLabel(log.action.toLowerCase())}
                      </span>
                    )}
                  </td>
                  <td className="text-slate-400 text-sm font-mono" dir="ltr">
                    {new Date(log.timestamp).toLocaleTimeString('en-US', { hour: '2-digit', minute: '2-digit' })}
                  </td>
                  <td className="text-slate-500 text-sm max-w-[200px] truncate">
                    {log.note || '-'}
                  </td>
                </tr>
              ))}
              {recentLogs.length === 0 && (
                <tr>
                  <td colSpan={5} className="text-center py-12 text-slate-500">
                    هیچ داتایەک نییە
                  </td>
                </tr>
              )}
            </tbody>
          </table>
        </div>
      </div>
    </div>
  );
};
