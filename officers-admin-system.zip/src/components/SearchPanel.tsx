import React, { useState } from 'react';
import { useApp } from '../context';
import { Search, FileText, Filter, Calendar, User, ArrowLeft, Eye, Clock, CheckCircle, XCircle, Building2, Hash } from 'lucide-react';
import { Document } from '../types';
import { format } from 'date-fns';
import { getStatusLabel } from '../translations';
import { motion } from 'framer-motion';

export const SearchPanel: React.FC<{ onViewDoc: (doc: Document) => void }> = ({ onViewDoc }) => {
  const { getVisibleDocuments } = useApp();
  const [query, setQuery] = useState('');
  const [filterType, setFilterType] = useState<'all' | 'circular' | 'normal'>('all');
  const [dateRange, setDateRange] = useState<'all' | 'today' | 'week' | 'month'>('all');
  const [statusFilter, setStatusFilter] = useState<'all' | 'pending' | 'in_progress' | 'approved' | 'rejected'>('all');
  const [sourceFilter, setSourceFilter] = useState('');
  const [numberFilter, setNumberFilter] = useState('');

  const allDocs = getVisibleDocuments();

  const filteredDocs = allDocs.filter(doc => {
    const docNumber = doc.incomingNumber || doc.referenceNumber || doc.uniqueId || '';
    const docSource = doc.source || doc.senderDepartment || '';

    const matchesQuery = 
      doc.title.toLowerCase().includes(query.toLowerCase()) ||
      doc.content.toLowerCase().includes(query.toLowerCase()) ||
      docNumber.toLowerCase().includes(query.toLowerCase()) ||
      docSource.toLowerCase().includes(query.toLowerCase()) ||
      doc.senderName.toLowerCase().includes(query.toLowerCase());

    const matchesType = 
      filterType === 'all' ? true :
      filterType === 'circular' ? doc.isCircular :
      !doc.isCircular;

    const matchesStatus = 
      statusFilter === 'all' ? true :
      doc.status === statusFilter;

    const matchesSource = sourceFilter ? docSource.toLowerCase().includes(sourceFilter.toLowerCase()) : true;
    const matchesNumber = numberFilter ? docNumber.toLowerCase().includes(numberFilter.toLowerCase()) : true;

    let matchesDate = true;
    const docDate = new Date(doc.createdAt);
    const now = new Date();
    
    if (dateRange === 'today') {
      matchesDate = docDate.toDateString() === now.toDateString();
    } else if (dateRange === 'week') {
      const weekAgo = new Date(now.getTime() - 7 * 24 * 60 * 60 * 1000);
      matchesDate = docDate >= weekAgo;
    } else if (dateRange === 'month') {
      const monthAgo = new Date(now.getTime() - 30 * 24 * 60 * 60 * 1000);
      matchesDate = docDate >= monthAgo;
    }

    return matchesQuery && matchesType && matchesDate && matchesStatus && matchesSource && matchesNumber;
  });

  const getStatusIcon = (status: string) => {
      switch (status) {
          case 'approved': return <CheckCircle size={16} />;
          case 'rejected': return <XCircle size={16} />;
          case 'in_progress': return <Clock size={16} />;
          default: return <Clock size={16} />;
      }
  };

  const getStatusColor = (status: string) => {
      switch (status) {
          case 'approved': return 'bg-emerald-500/10 text-emerald-400 border-emerald-500/20';
          case 'rejected': return 'bg-red-500/10 text-red-400 border-red-500/20';
          case 'in_progress': return 'bg-blue-500/10 text-blue-400 border-blue-500/20';
          default: return 'bg-amber-500/10 text-amber-400 border-amber-500/20';
      }
  };

  return (
    <div className="space-y-6" dir="rtl">
      <div className="glass-panel p-8 rounded-3xl border border-white/10 shadow-2xl relative overflow-hidden">
        <div className="absolute top-0 left-0 w-full h-1 bg-gradient-to-r from-blue-500 via-purple-500 to-pink-500" />
        
        <h2 className="text-3xl font-black text-white mb-6 flex items-center gap-3 neon-text">
          <Search className="text-blue-400" size={32} />
          گەڕانی پێشکەوتوو
        </h2>

        {/* General Search */}
        <div className="relative mb-6">
          <input
            type="text"
            value={query}
            onChange={e => setQuery(e.target.value)}
            placeholder="گەڕانی گشتی (ناونیشان، ناوەڕۆک، ژمارە، سەرچاوە...)"
            className="w-full px-6 py-4 rounded-2xl bg-black/30 border border-white/10 focus:border-blue-500 focus:ring-4 focus:ring-blue-500/10 outline-none transition-all text-lg text-white placeholder:text-slate-500 pl-14"
          />
          <Search className="absolute left-5 top-1/2 -translate-y-1/2 text-slate-400" size={24} />
        </div>

        {/* Advanced Filters */}
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-4 mb-6">
            <div className="relative">
                <input
                    type="text"
                    value={numberFilter}
                    onChange={e => setNumberFilter(e.target.value)}
                    placeholder="ژمارەی نوسراو..."
                    className="w-full px-4 py-3 rounded-xl bg-white/5 border border-white/10 focus:border-blue-500 outline-none transition-all text-white placeholder:text-slate-500 pr-10"
                />
                <Hash className="absolute right-3 top-1/2 -translate-y-1/2 text-slate-400" size={18} />
            </div>
            <div className="relative">
                <input
                    type="text"
                    value={sourceFilter}
                    onChange={e => setSourceFilter(e.target.value)}
                    placeholder="لەکوێوە هاتووە..."
                    className="w-full px-4 py-3 rounded-xl bg-white/5 border border-white/10 focus:border-blue-500 outline-none transition-all text-white placeholder:text-slate-500 pr-10"
                />
                <Building2 className="absolute right-3 top-1/2 -translate-y-1/2 text-slate-400" size={18} />
            </div>
            
            <select 
                value={statusFilter}
                onChange={e => setStatusFilter(e.target.value as any)}
                className="w-full px-4 py-3 rounded-xl bg-white/5 border border-white/10 focus:border-blue-500 outline-none transition-all text-white appearance-none cursor-pointer"
            >
                <option value="all" className="bg-slate-800">هەموو دۆخەکان</option>
                <option value="pending" className="bg-slate-800">چاوەڕێکراو</option>
                <option value="in_progress" className="bg-slate-800">لە جێبەجێکردندایە</option>
                <option value="approved" className="bg-slate-800">تەواوبووە</option>
                <option value="rejected" className="bg-slate-800">ڕەتکراوەتەوە</option>
            </select>

            <select 
                value={dateRange}
                onChange={e => setDateRange(e.target.value as any)}
                className="w-full px-4 py-3 rounded-xl bg-white/5 border border-white/10 focus:border-blue-500 outline-none transition-all text-white appearance-none cursor-pointer"
            >
                <option value="all" className="bg-slate-800">هەموو کاتێک</option>
                <option value="today" className="bg-slate-800">ئەمڕۆ</option>
                <option value="week" className="bg-slate-800">ئەم هەفتەیە</option>
                <option value="month" className="bg-slate-800">ئەم مانگە</option>
            </select>
        </div>

        {/* Type Filters */}
        <div className="flex flex-wrap gap-4">
          <div className="flex items-center gap-2 bg-white/5 p-1 rounded-xl border border-white/10">
            <button
              onClick={() => setFilterType('all')}
              className={`px-4 py-2 rounded-lg text-sm font-bold transition-all ${filterType === 'all' ? 'bg-blue-600 text-white shadow-[0_0_15px_rgba(37,99,235,0.4)]' : 'text-slate-400 hover:text-white hover:bg-white/5'}`}
            >
              هەمووی
            </button>
            <button
              onClick={() => setFilterType('normal')}
              className={`px-4 py-2 rounded-lg text-sm font-bold transition-all ${filterType === 'normal' ? 'bg-blue-600 text-white shadow-[0_0_15px_rgba(37,99,235,0.4)]' : 'text-slate-400 hover:text-white hover:bg-white/5'}`}
            >
              نوسراوی ئاسایی
            </button>
            <button
              onClick={() => setFilterType('circular')}
              className={`px-4 py-2 rounded-lg text-sm font-bold transition-all ${filterType === 'circular' ? 'bg-purple-600 text-white shadow-[0_0_15px_rgba(147,51,234,0.4)]' : 'text-slate-400 hover:text-white hover:bg-white/5'}`}
            >
              گشتاندن
            </button>
          </div>
        </div>
      </div>

      <div className="space-y-4">
        <h3 className="text-lg font-bold text-slate-400 px-2 flex items-center gap-2">
          <Filter size={20} />
          ئەنجامی گەڕان ({filteredDocs.length})
        </h3>

        {filteredDocs.length === 0 ? (
          <div className="text-center py-20 bg-white/5 rounded-3xl border border-white/5 border-dashed">
            <div className="w-20 h-20 bg-white/5 rounded-full flex items-center justify-center mx-auto mb-4">
              <Search className="text-slate-600" size={40} />
            </div>
            <p className="text-slate-500 text-lg">هیچ ئەنجامێک نەدۆزرایەوە</p>
          </div>
        ) : (
          <div className="grid grid-cols-1 gap-4">
            {filteredDocs.map((doc, idx) => (
              <motion.div 
                initial={{ opacity: 0, y: 10 }}
                animate={{ opacity: 1, y: 0 }}
                transition={{ delay: idx * 0.05 }}
                key={doc.id}
                className="glass-panel p-6 rounded-2xl border border-white/10 hover:border-blue-500/30 hover:bg-white/5 transition-all group"
              >
                <div className="flex flex-col lg:flex-row gap-6">
                    {/* Icon & Title */}
                    <div className="flex-1">
                        <div className="flex items-start gap-4 mb-4">
                            <div className={`w-12 h-12 rounded-xl flex items-center justify-center shadow-lg flex-shrink-0 ${
                                doc.isCircular ? 'bg-purple-500/20 text-purple-400 border border-purple-500/30' : 'bg-blue-500/20 text-blue-400 border border-blue-500/30'
                            }`}>
                                <FileText size={24} />
                            </div>
                            <div>
                                <h4 className="text-xl font-bold text-white group-hover:text-blue-400 transition-colors mb-2">
                                    {doc.title}
                                </h4>
                                <div className="flex flex-wrap items-center gap-3 text-sm text-slate-400">
                                    <span className="flex items-center gap-1 bg-black/30 px-2 py-1 rounded-lg border border-white/5">
                                        <Hash size={14} className="text-amber-400" />
                                        <span className="font-mono text-amber-400">{doc.incomingNumber || doc.referenceNumber || doc.uniqueId}</span>
                                    </span>
                                    <span className="flex items-center gap-1 bg-black/30 px-2 py-1 rounded-lg border border-white/5">
                                        <Calendar size={14} className="text-blue-400" />
                                        <span>{doc.incomingDate || format(new Date(doc.createdAt), 'yyyy/MM/dd')}</span>
                                    </span>
                                    <span className="flex items-center gap-1 bg-black/30 px-2 py-1 rounded-lg border border-white/5">
                                        <Building2 size={14} className="text-emerald-400" />
                                        <span className="truncate max-w-[150px]">{doc.source || doc.senderDepartment}</span>
                                    </span>
                                </div>
                            </div>
                        </div>
                        
                        {/* Content Snippet */}
                        <div className="bg-black/20 p-4 rounded-xl border border-white/5 mb-4">
                            <p className="text-slate-300 text-sm line-clamp-2 leading-relaxed">
                                {doc.content}
                            </p>
                        </div>
                    </div>

                    {/* Actions & Status */}
                    <div className="flex flex-row lg:flex-col items-center lg:items-end justify-between lg:justify-center gap-4 border-t lg:border-t-0 lg:border-r border-white/10 pt-4 lg:pt-0 lg:pr-6">
                        <div className={`flex items-center gap-2 px-4 py-2 rounded-xl text-sm font-bold border ${getStatusColor(doc.status)}`}>
                            {getStatusIcon(doc.status)}
                            {getStatusLabel(doc.status)}
                        </div>
                        
                        <button 
                            onClick={() => onViewDoc(doc)}
                            className="flex items-center gap-2 px-6 py-2 bg-blue-600 hover:bg-blue-500 text-white rounded-xl font-bold transition-all shadow-[0_0_15px_rgba(37,99,235,0.3)] hover:shadow-[0_0_25px_rgba(37,99,235,0.5)] hover:-translate-y-0.5"
                        >
                            <Eye size={18} />
                            بینینی نوسراو
                        </button>
                    </div>
                </div>
              </motion.div>
            ))}
          </div>
        )}
      </div>
    </div>
  );
};
