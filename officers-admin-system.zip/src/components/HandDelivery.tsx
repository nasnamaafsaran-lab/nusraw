import React, { useState } from 'react';
import { useApp } from '../context';
import { HandDeliveryRecord } from '../types';
import { Camera, User, FileText, X } from 'lucide-react';

interface HandDeliveryModalProps {
  docId: string;
  onClose: () => void;
  onSuccess: () => void;
}

export const HandDeliveryModal: React.FC<HandDeliveryModalProps> = ({ docId, onClose, onSuccess }) => {
  const { handDeliverDocument, currentUser } = useApp();
  const [receiverName, setReceiverName] = useState('');
  const [receiverId, setReceiverId] = useState('');
  const [receiverDept, setReceiverDept] = useState('');
  const [notes, setNotes] = useState('');
  
  // Mock photo capture (in real app use react-webcam)
  const [receiverPhoto, setReceiverPhoto] = useState<string | null>(null);
  const [docPhoto, setDocPhoto] = useState<string | null>(null);

  const handleCapture = (type: 'receiver' | 'doc') => {
    // Mocking a captured image with a local base64 SVG to work offline
    const mockImage = "data:image/svg+xml;base64,PHN2ZyB4bWxucz0iaHR0cDovL3d3dy53My5vcmcvMjAwMC9zdmciIHdpZHRoPSIyMDAiIGhlaWdodD0iMjAwIj48cmVjdCB3aWR0aD0iMTAwJSIgaGVpZ2h0PSIxMDAlIiBmaWxsPSIjZWVlIi8+PHRleHQgeD0iNTAlIiB5PSI1MCUiIGZvbnQtZmFtaWx5PSJzYW5zLXNlcmlmIiBmb250LXNpemU9IjE0IiB0ZXh0LWFuY2hvcj0ibWlkZGxlIiBkeT0iLjNlbSIgZmlsbD0iIzU1NSI+TW9jayBJbWFnZTwvdGV4dD48L3N2Zz4=";
    if (type === 'receiver') setReceiverPhoto(mockImage);
    else setDocPhoto(mockImage);
  };

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (receiverName && receiverId && receiverDept && receiverPhoto && docPhoto && currentUser) {
      const record: HandDeliveryRecord = {
        id: Math.random().toString(36).substr(2, 9),
        documentId: docId,
        receiverName,
        receiverId,
        receiverDept,
        receiverPhotoUrl: receiverPhoto,
        documentPhotoUrl: docPhoto,
        deliveredBy: currentUser.name,
        timestamp: new Date().toISOString(),
        notes
      };
      handDeliverDocument(docId, record);
      onSuccess();
    }
  };

  return (
    <div className="fixed inset-0 bg-black/80 flex items-center justify-center z-50 p-4 backdrop-blur-md animate-in fade-in duration-200">
      <div className="glass-panel rounded-2xl w-full max-w-2xl shadow-2xl border border-white/10 overflow-hidden flex flex-col max-h-[90vh]" dir="rtl">
        <div className="p-6 border-b border-white/10 flex justify-between items-center bg-white/5 backdrop-blur-md">
          <h3 className="text-xl font-bold text-white flex items-center gap-2 neon-text">
            <User className="text-blue-400 drop-shadow-[0_0_8px_rgba(59,130,246,0.8)]" />
            تۆمارکردنی نوسراو بە زمە
          </h3>
          <button onClick={onClose} className="text-slate-400 hover:text-white transition-all hover:bg-white/10 p-2 rounded-full hover:shadow-[0_0_10px_rgba(255,255,255,0.1)]">
            <X size={24} />
          </button>
        </div>

        <div className="p-6 overflow-y-auto custom-scrollbar">
          <form onSubmit={handleSubmit} className="space-y-6">
            <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
              {/* Receiver Info */}
              <div className="space-y-4">
                <div>
                  <label className="block text-sm font-medium text-slate-300 mb-2">ناوی وەرگر</label>
                  <input
                    type="text"
                    value={receiverName}
                    onChange={e => setReceiverName(e.target.value)}
                    className="input-vibrant w-full px-4 py-3"
                    placeholder="ناوی سیانی..."
                    required
                  />
                </div>
                <div>
                  <label className="block text-sm font-medium text-slate-300 mb-2">ژمارەی ناسنامە / سەربازی</label>
                  <input
                    type="text"
                    value={receiverId}
                    onChange={e => setReceiverId(e.target.value)}
                    className="input-vibrant w-full px-4 py-3"
                    placeholder="ID..."
                    required
                  />
                </div>
                <div>
                  <label className="block text-sm font-medium text-slate-300 mb-2">بەش / ژوور</label>
                  <input
                    type="text"
                    value={receiverDept}
                    onChange={e => setReceiverDept(e.target.value)}
                    className="input-vibrant w-full px-4 py-3"
                    placeholder="شوێنی کار..."
                    required
                  />
                </div>
              </div>

              {/* Photos */}
              <div className="space-y-4">
                <div>
                  <label className="block text-sm font-medium text-slate-300 mb-2">وێنەی وەرگر</label>
                  <div 
                    onClick={() => handleCapture('receiver')}
                    className={`h-32 rounded-xl border-2 border-dashed flex items-center justify-center cursor-pointer transition-all group ${
                      receiverPhoto ? 'border-green-500/50 bg-green-500/10' : 'border-white/20 bg-white/5 hover:border-blue-400/50 hover:bg-white/10'
                    }`}
                  >
                    {receiverPhoto ? (
                      <img src={receiverPhoto} alt="Receiver" className="h-full w-full object-cover rounded-xl shadow-lg" />
                    ) : (
                      <div className="text-center text-slate-400 group-hover:text-blue-300 transition-colors">
                        <Camera className="mx-auto mb-1 drop-shadow-lg" />
                        <span className="text-xs">کلیک بکە بۆ گرتنی وێنە</span>
                      </div>
                    )}
                  </div>
                </div>

                <div>
                  <label className="block text-sm font-medium text-slate-300 mb-2">وێنەی نوسراو</label>
                  <div 
                    onClick={() => handleCapture('doc')}
                    className={`h-32 rounded-xl border-2 border-dashed flex items-center justify-center cursor-pointer transition-all group ${
                      docPhoto ? 'border-green-500/50 bg-green-500/10' : 'border-white/20 bg-white/5 hover:border-blue-400/50 hover:bg-white/10'
                    }`}
                  >
                    {docPhoto ? (
                      <img src={docPhoto} alt="Document" className="h-full w-full object-cover rounded-xl shadow-lg" />
                    ) : (
                      <div className="text-center text-slate-400 group-hover:text-blue-300 transition-colors">
                        <FileText className="mx-auto mb-1 drop-shadow-lg" />
                        <span className="text-xs">کلیک بکە بۆ گرتنی وێنە</span>
                      </div>
                    )}
                  </div>
                </div>
              </div>
            </div>

            <div>
              <label className="block text-sm font-medium text-slate-300 mb-2">تێبینی</label>
              <textarea
                value={notes}
                onChange={e => setNotes(e.target.value)}
                className="input-vibrant w-full px-4 py-3 h-24 resize-none"
                placeholder="تێبینی زیادە..."
              />
            </div>

            <div className="pt-4 flex gap-3 border-t border-white/10">
              <button
                type="button"
                onClick={onClose}
                className="flex-1 btn-vibrant-secondary py-3"
              >
                پاشگەزبوونەوە
              </button>
              <button
                type="submit"
                disabled={!receiverName || !receiverId || !receiverDept || !receiverPhoto || !docPhoto}
                className="flex-1 btn-vibrant-primary py-3"
              >
                تۆمارکردن
              </button>
            </div>
          </form>
        </div>
      </div>
    </div>
  );
};
