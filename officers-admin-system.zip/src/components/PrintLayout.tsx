import React from 'react';
import { Document } from '../types';
import QRCode from 'react-qr-code';

export const PrintLayout: React.FC<{ doc: Document }> = ({ doc }) => {
  return (
    <div className="hidden print:block fixed inset-0 bg-white z-[9999] p-8 text-black" dir="rtl">
      {/* Header */}
      <div className="flex justify-between items-start border-b-2 border-black pb-4 mb-8">
        <div className="text-center">
          <h1 className="text-xl font-bold mb-1">حکومەتی هەرێمی کوردستان</h1>
          <h2 className="text-lg font-bold mb-1">وەزارەتی ناوخۆ</h2>
          <h3 className="text-md font-bold">{doc.senderDepartment}</h3>
        </div>
        <div className="text-center">
          <img src="data:image/svg+xml;base64,PHN2ZyB4bWxucz0iaHR0cDovL3d3dy53My5vcmcvMjAwMC9zdmciIHZpZXdCb3g9IjAgMCAxMDAgMTAwIj48Y2lyY2xlIGN4PSI1MCIgY3k9IjUwIiByPSI0NSIgZmlsbD0ibm9uZSIgc3Ryb2tlPSJibGFjayIgc3Ryb2tlLXdpZHRoPSI1Ii8+PHBhdGggZD0iTTMwIDcwIEw1MCAzMCBMNzAgNzAiIGZpbGw9Im5vbmUiIHN0cm9rZT0iYmxhY2siIHN0cm9rZS13aWR0aD0iNSIvPjwvc3ZnPg==" alt="Logo" className="w-24 h-24 object-contain" />
        </div>
        <div className="text-left space-y-1 text-sm font-bold">
          <p>ژمارە: {doc.uniqueId}</p>
          <p>ڕێکەوت: {new Date(doc.createdAt).toLocaleDateString('en-GB')}</p>
          <p>کات: {new Date(doc.createdAt).toLocaleTimeString('en-US')}</p>
        </div>
      </div>

      {/* Content */}
      <div className="mb-8">
        <div className="flex gap-4 mb-6">
          <span className="font-bold w-24">بابەت:</span>
          <span className="font-bold border-b border-black/20 flex-1 pb-1">{doc.title}</span>
        </div>
        
        <div className="prose max-w-none text-justify leading-loose text-lg font-medium">
          {doc.content}
        </div>
      </div>

      {/* Footer / Signatures */}
      <div className="mt-24 flex justify-between items-end">
        <div className="text-center">
          <p className="font-bold mb-16">بەڕێوەبەری بەش</p>
          <div className="border-t border-black w-48 mx-auto pt-2">
            <p className="text-sm">ناوە و واژۆ</p>
          </div>
        </div>
        
        <div className="flex flex-col items-center gap-2">
          <QRCode value={doc.uniqueId} size={96} />
          <span className="text-xs font-mono">{doc.uniqueId}</span>
        </div>
      </div>

      {/* Attachments List */}
      {doc.attachments.length > 0 && (
        <div className="mt-12 border-t border-black pt-4">
          <h4 className="font-bold mb-2 text-sm">هاوپێچەکان:</h4>
          <ul className="list-disc list-inside text-sm">
            {doc.attachments.map(att => (
              <li key={att.id}>{att.name} ({att.type})</li>
            ))}
          </ul>
        </div>
      )}

      {/* System Footer */}
      <div className="fixed bottom-4 left-0 right-0 text-center text-xs text-gray-500 border-t border-gray-300 pt-2 mx-8">
        ئەم نوسراوە بە شێوەی ئەلیکترۆنی دروستکراوە و پارێزراوە لە سیستەمی ئەلیکترۆنی.
      </div>
    </div>
  );
};
