import React, { useState, useRef } from 'react';
import { useApp } from '../context';
import { Users, FileText, Activity, Shield, Search, Download, Upload, Database, Plus, Trash2, Edit, Lock, Unlock, Building2 } from 'lucide-react';
import { Document, DocumentLog, User, DepartmentInfo, Role } from '../types';
import { BarChart, Bar, XAxis, YAxis, CartesianGrid, Tooltip, Legend, ResponsiveContainer, PieChart, Pie, Cell } from 'recharts';
import { getRoleLabel, getActionLabel } from '../translations';

export const AdminPanel: React.FC = () => {
  const { 
    users, documents, departments, backupData, restoreData,
    addUser, updateUser, deleteUser, toggleUserLock,
    addDepartment, updateDepartment, deleteDepartment,
    activityLogs
  } = useApp();
  
  const [activeTab, setActiveTab] = useState<'overview' | 'users' | 'departments' | 'logs' | 'backup'>('overview');
  const [searchTerm, setSearchTerm] = useState('');
  const fileInputRef = useRef<HTMLInputElement>(null);

  // User Management State
  const [isUserModalOpen, setIsUserModalOpen] = useState(false);
  const [editingUser, setEditingUser] = useState<User | null>(null);
  const [userForm, setUserForm] = useState<Partial<User>>({
    username: '', name: '', role: 'staff_officer', department: 'main_office', title: ''
  });

  // Department Management State
  const [isDeptModalOpen, setIsDeptModalOpen] = useState(false);
  const [editingDept, setEditingDept] = useState<DepartmentInfo | null>(null);
  const [deptForm, setDeptForm] = useState<Partial<DepartmentInfo>>({
    id: '', name: '', forms: []
  });

  // Calculate System Stats
  const totalDocs = documents.length;
  const archivedDocs = documents.filter(d => d.status === 'archived').length;
  const activeDocs = totalDocs - archivedDocs;
  
  const docsByDept = documents.reduce((acc, doc) => {
    acc[doc.senderDepartment] = (acc[doc.senderDepartment] || 0) + 1;
    return acc;
  }, {} as Record<string, number>);

  const docsByStatus = documents.reduce((acc, doc) => {
    acc[doc.status] = (acc[doc.status] || 0) + 1;
    return acc;
  }, {} as Record<string, number>);

  const deptChartData = Object.entries(docsByDept).map(([name, value]) => ({ name, value }));
  const statusChartData = Object.entries(docsByStatus).map(([name, value]) => ({ name, value }));

  const COLORS = ['#3b82f6', '#10b981', '#f59e0b', '#ef4444', '#8b5cf6'];

  const filteredLogs = activityLogs.filter(log => 
    log.action.toLowerCase().includes(searchTerm.toLowerCase()) ||
    log.userName.toLowerCase().includes(searchTerm.toLowerCase()) ||
    log.targetId.toLowerCase().includes(searchTerm.toLowerCase())
  );

  const handleUserSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    if (editingUser) {
      await updateUser(editingUser.id, userForm);
    } else {
      await addUser(userForm as Omit<User, 'id' | 'isLocked'>);
    }
    setIsUserModalOpen(false);
    setEditingUser(null);
    setUserForm({ username: '', name: '', role: 'staff_officer', department: 'main_office', title: '' });
  };

  const handleDeptSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (editingDept) {
      updateDepartment({ ...editingDept, ...deptForm } as DepartmentInfo);
    } else {
      addDepartment({ ...deptForm, forms: [] } as DepartmentInfo);
    }
    setIsDeptModalOpen(false);
    setEditingDept(null);
    setDeptForm({ id: '', name: '', forms: [] });
  };

  const exportLogs = () => {
    const headers = ['بەکارهێنەر', 'کردار', 'ئامانج', 'جۆر', 'کات'];
    const csvContent = [
      headers.join(','),
      ...filteredLogs.map(log => [
        `"${log.userName}"`,
        `"${log.action}"`,
        `"${log.targetId}"`,
        `"${log.type}"`,
        new Date(log.timestamp).toLocaleString('en-US')
      ].join(','))
    ].join('\n');

    const blob = new Blob([csvContent], { type: 'text/csv;charset=utf-8;' });
    const link = document.createElement('a');
    link.href = URL.createObjectURL(blob);
    link.download = `system_logs_${new Date().toISOString().split('T')[0]}.csv`;
    link.click();
  };

  const handleFileRestore = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (file) {
      const reader = new FileReader();
      reader.onload = (event) => {
        if (event.target?.result) {
          restoreData(event.target.result as string);
        }
      };
      reader.readAsText(file);
    }
  };

  return (
    <div className="space-y-8" dir="rtl">
      <header className="flex items-center justify-between">
        <div>
          <h2 className="text-3xl font-bold text-white flex items-center gap-3 neon-text">
            <Shield className="text-blue-400 drop-shadow-[0_0_8px_rgba(59,130,246,0.8)]" size={32} />
            پەنێڵی بەڕێوەبەرایەتی
          </h2>
          <p className="text-slate-400 mt-2">بەڕێوەبردنی سیستەم و چاودێری بەکارهێنەران</p>
        </div>
        <div className="flex gap-4 p-2 bg-white/5 rounded-3xl border border-white/10 backdrop-blur-md">
          {[
            { id: 'overview', label: 'پوختە', icon: Activity, gradient: 'from-blue-600 to-cyan-500', shadow: 'shadow-blue-500/40' },
            { id: 'users', label: 'بەکارهێنەران', icon: Users, gradient: 'from-violet-600 to-purple-500', shadow: 'shadow-purple-500/40' },
            { id: 'departments', label: 'بەشەکان', icon: Building2, gradient: 'from-emerald-600 to-teal-500', shadow: 'shadow-emerald-500/40' },
            { id: 'logs', label: 'تۆماری چالاکیەکان', icon: FileText, gradient: 'from-amber-500 to-orange-500', shadow: 'shadow-orange-500/40' },
            { id: 'backup', label: 'پاشەکەوت', icon: Database, gradient: 'from-rose-600 to-red-500', shadow: 'shadow-red-500/40' }
          ].map((tab) => (
            <button
              key={tab.id}
              onClick={() => setActiveTab(tab.id as any)}
              className={`relative px-6 py-3 rounded-2xl font-bold text-sm transition-all duration-500 flex items-center gap-3 overflow-hidden group ${
                activeTab === tab.id 
                  ? `bg-gradient-to-r ${tab.gradient} text-white shadow-lg ${tab.shadow} scale-105 ring-1 ring-white/30` 
                  : 'bg-white/5 text-slate-400 hover:bg-white/10 hover:text-white hover:shadow-lg hover:shadow-white/5'
              }`}
            >
              <div className={`absolute inset-0 bg-gradient-to-r from-transparent via-white/20 to-transparent translate-x-[-100%] group-hover:translate-x-[100%] transition-transform duration-1000 ${activeTab === tab.id ? 'opacity-100' : 'opacity-0 group-hover:opacity-50'}`} />
              <tab.icon size={18} className={`transition-transform duration-300 ${activeTab === tab.id ? 'scale-110' : 'group-hover:scale-110'}`} />
              <span className="relative z-10">{tab.label}</span>
            </button>
          ))}
        </div>
      </header>

      {activeTab === 'overview' && (
        <div className="space-y-6">
          <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
            <div className="glass-panel p-6 rounded-2xl shadow-lg border border-white/10">
              <div className="flex items-center justify-between mb-4">
                <div className="p-3 bg-blue-500/20 text-blue-400 rounded-xl border border-blue-500/30 shadow-[0_0_10px_rgba(59,130,246,0.3)]">
                  <FileText size={24} />
                </div>
                <span className="text-3xl font-bold text-white neon-text">{totalDocs}</span>
              </div>
              <h3 className="text-slate-400 font-medium">کۆی گشتی نوسراوەکان</h3>
            </div>

            <div className="glass-panel p-6 rounded-2xl shadow-lg border border-white/10">
              <div className="flex items-center justify-between mb-4">
                <div className="p-3 bg-emerald-500/20 text-emerald-400 rounded-xl border border-emerald-500/30 shadow-[0_0_10px_rgba(16,185,129,0.3)]">
                  <Activity size={24} />
                </div>
                <span className="text-3xl font-bold text-white neon-text">{activeDocs}</span>
              </div>
              <h3 className="text-slate-400 font-medium">نوسراوە چالاکەکان</h3>
            </div>

            <div className="glass-panel p-6 rounded-2xl shadow-lg border border-white/10">
              <div className="flex items-center justify-between mb-4">
                <div className="p-3 bg-purple-500/20 text-purple-400 rounded-xl border border-purple-500/30 shadow-[0_0_10px_rgba(168,85,247,0.3)]">
                  <Users size={24} />
                </div>
                <span className="text-3xl font-bold text-white neon-text">{users.length}</span>
              </div>
              <h3 className="text-slate-400 font-medium">بەکارهێنەرانی سیستەم</h3>
            </div>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
            <div className="bg-white/5 rounded-2xl shadow-sm border border-white/10 overflow-hidden">
              <h3 className="text-lg font-bold text-white mb-6 p-6 neon-text">دابەشبوونی نوسراوەکان بەپێی بەش</h3>
              <div className="h-64 px-6 pb-6" dir="ltr">
                <ResponsiveContainer width="100%" height="100%" minHeight={1}>
                  <BarChart data={deptChartData}>
                    <CartesianGrid strokeDasharray="3 3" stroke="rgba(255,255,255,0.05)" />
                    <XAxis dataKey="name" stroke="#94a3b8" tick={{fill: '#94a3b8'}} />
                    <YAxis stroke="#94a3b8" tick={{fill: '#94a3b8'}} />
                    <Tooltip 
                      cursor={{fill: 'rgba(255,255,255,0.05)'}}
                      contentStyle={{ backgroundColor: 'rgba(15, 23, 42, 0.9)', borderColor: 'rgba(255,255,255,0.1)', color: '#fff', backdropFilter: 'blur(10px)' }}
                      itemStyle={{ color: '#fff' }}
                    />
                    <Bar dataKey="value" fill="#3b82f6" radius={[4, 4, 0, 0]}>
                      {deptChartData.map((entry, index) => (
                        <Cell key={`cell-${index}`} fill={COLORS[index % COLORS.length]} />
                      ))}
                    </Bar>
                  </BarChart>
                </ResponsiveContainer>
              </div>
            </div>

            <div className="bg-white/5 rounded-2xl shadow-sm border border-white/10 overflow-hidden">
              <h3 className="text-lg font-bold text-white mb-6 p-6 neon-text">دۆخی نوسراوەکان</h3>
              <div className="h-64 px-6 pb-6" dir="ltr">
                <ResponsiveContainer width="100%" height="100%" minHeight={1}>
                  <PieChart>
                    <Pie
                      data={statusChartData}
                      cx="50%"
                      cy="50%"
                      labelLine={false}
                      label={({ name, percent }) => `${name} ${(percent * 100).toFixed(0)}%`}
                      outerRadius={80}
                      fill="#8884d8"
                      dataKey="value"
                      stroke="rgba(0,0,0,0)"
                    >
                      {statusChartData.map((entry, index) => (
                        <Cell key={`cell-${index}`} fill={COLORS[index % COLORS.length]} />
                      ))}
                    </Pie>
                    <Tooltip 
                      contentStyle={{ backgroundColor: 'rgba(15, 23, 42, 0.9)', borderColor: 'rgba(255,255,255,0.1)', color: '#fff', backdropFilter: 'blur(10px)' }}
                      itemStyle={{ color: '#fff' }}
                    />
                  </PieChart>
                </ResponsiveContainer>
              </div>
            </div>
          </div>
        </div>
      )}

      {activeTab === 'users' && (
        <div className="space-y-4">
          <div className="flex justify-end">
            <button
              onClick={() => {
                setEditingUser(null);
                setUserForm({ username: '', name: '', role: 'staff_officer', department: 'main_office', title: '' });
                setIsUserModalOpen(true);
              }}
              className="relative group bg-gradient-to-r from-blue-600 to-indigo-600 hover:from-blue-500 hover:to-indigo-500 text-white px-6 py-3 rounded-2xl flex items-center gap-2 shadow-[0_10px_20px_rgba(37,99,235,0.3)] border border-white/20 transition-all hover:-translate-y-1 overflow-hidden"
            >
              <div className="absolute inset-0 bg-gradient-to-r from-transparent via-white/20 to-transparent translate-x-[-100%] group-hover:translate-x-[100%] transition-transform duration-1000" />
              <Plus size={20} className="group-hover:rotate-90 transition-transform duration-300" />
              <span className="relative z-10 font-bold">زیادکردنی بەکارهێنەر</span>
            </button>
          </div>
          <div className="bg-white/5 rounded-2xl shadow-sm border border-white/10 overflow-hidden">
            <table className="elite-table text-right">
              <thead>
                <tr>
                  <th>ناوی بەکارهێنەر</th>
                  <th>ناوی تەواو</th>
                  <th>ناونیشان</th>
                  <th>ڕۆڵ</th>
                  <th>بەش</th>
                  <th>کردارەکان</th>
                </tr>
              </thead>
              <tbody>
                {users.map(user => (
                  <tr key={user.id} className={`group ${user.isLocked ? 'bg-red-500/10' : ''}`}>
                    <td className="font-medium text-white group-hover:text-blue-400 transition-colors">{user.username}</td>
                    <td className="text-slate-300">{user.name}</td>
                    <td className="text-slate-300">{user.title}</td>
                    <td>
                      <span className="badge-glow badge-info">
                        {getRoleLabel(user.role)}
                      </span>
                    </td>
                    <td className="text-slate-400">{user.department}</td>
                    <td className="flex gap-2">
                      <button 
                        onClick={() => {
                          setEditingUser(user);
                          setUserForm(user);
                          setIsUserModalOpen(true);
                        }}
                        className="text-blue-400 hover:bg-blue-500/20 p-2 rounded-lg transition-all hover:shadow-[0_0_10px_rgba(59,130,246,0.3)]"
                      >
                        <Edit size={18} />
                      </button>
                      <button 
                        onClick={() => toggleUserLock(user.id)}
                        className={`${user.isLocked ? 'text-red-400 hover:shadow-[0_0_10px_rgba(239,68,68,0.3)]' : 'text-slate-400 hover:shadow-[0_0_10px_rgba(255,255,255,0.1)]'} hover:bg-white/10 p-2 rounded-lg transition-all`}
                        title={user.isLocked ? 'Unlock' : 'Lock'}
                      >
                        {user.isLocked ? <Lock size={18} /> : <Unlock size={18} />}
                      </button>
                      <button 
                        onClick={() => {
                          if (window.confirm('دڵنیایت لە سڕینەوەی ئەم بەکارهێنەرە؟')) {
                            deleteUser(user.id);
                          }
                        }}
                        className="text-red-400 hover:bg-red-500/20 p-2 rounded-lg transition-all hover:shadow-[0_0_10px_rgba(239,68,68,0.3)]"
                      >
                        <Trash2 size={18} />
                      </button>
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        </div>
      )}

      {activeTab === 'departments' && (
        <div className="space-y-4">
          <div className="flex justify-end">
            <button
              onClick={() => {
                setEditingDept(null);
                setDeptForm({ id: '', name: '', forms: [] });
                setIsDeptModalOpen(true);
              }}
              className="relative group bg-gradient-to-r from-emerald-600 to-teal-600 hover:from-emerald-500 hover:to-teal-500 text-white px-6 py-3 rounded-2xl flex items-center gap-2 shadow-[0_10px_20px_rgba(16,185,129,0.3)] border border-white/20 transition-all hover:-translate-y-1 overflow-hidden"
            >
              <div className="absolute inset-0 bg-gradient-to-r from-transparent via-white/20 to-transparent translate-x-[-100%] group-hover:translate-x-[100%] transition-transform duration-1000" />
              <Plus size={20} className="group-hover:rotate-90 transition-transform duration-300" />
              <span className="relative z-10 font-bold">زیادکردنی بەش</span>
            </button>
          </div>
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
            {departments.map(dept => (
              <div key={dept.id} className="glass-panel p-6 rounded-2xl shadow-lg border border-white/10 hover:border-blue-500/30 transition-all hover:-translate-y-1">
                <div className="flex justify-between items-start mb-4">
                  <div className="p-3 bg-blue-500/20 text-blue-400 rounded-xl border border-blue-500/30 shadow-[0_0_10px_rgba(59,130,246,0.3)]">
                    <Building2 size={24} />
                  </div>
                  <div className="flex gap-1">
                    <button 
                      onClick={() => {
                        setEditingDept(dept);
                        setDeptForm(dept);
                        setIsDeptModalOpen(true);
                      }}
                      className="text-slate-400 hover:text-blue-400 p-1 transition-all hover:shadow-[0_0_10px_rgba(59,130,246,0.3)] rounded"
                    >
                      <Edit size={18} />
                    </button>
                    <button 
                      onClick={() => {
                        if (window.confirm('دڵنیایت لە سڕینەوەی ئەم بەشە؟')) {
                          deleteDepartment(dept.id);
                        }
                      }}
                      className="text-slate-400 hover:text-red-400 p-1 transition-all hover:shadow-[0_0_10px_rgba(239,68,68,0.3)] rounded"
                    >
                      <Trash2 size={18} />
                    </button>
                  </div>
                </div>
                <h3 className="text-lg font-bold text-white mb-2 neon-text">{dept.name}</h3>
                <p className="text-sm text-slate-400 mb-4">ID: {dept.id}</p>
                <div className="text-sm text-slate-300">
                  <span className="font-medium">فۆڕمەکان:</span> {dept.forms.length}
                </div>
              </div>
            ))}
          </div>
        </div>
      )}

      {/* User Modal */}
      {isUserModalOpen && (
        <div className="fixed inset-0 bg-black/80 backdrop-blur-md flex items-center justify-center z-50 animate-in fade-in duration-200">
          <div className="glass-panel rounded-2xl p-8 w-full max-w-md border border-white/10 shadow-2xl">
            <h3 className="text-xl font-bold mb-6 text-white neon-text">{editingUser ? 'دەستکاری بەکارهێنەر' : 'زیادکردنی بەکارهێنەر'}</h3>
            <form onSubmit={handleUserSubmit} className="space-y-4">
              <div>
                <label className="block text-sm font-medium mb-1 text-slate-300">ناوی بەکارهێنەر</label>
                <input
                  type="text"
                  required
                  value={userForm.username}
                  onChange={e => setUserForm({...userForm, username: e.target.value})}
                  className="w-full p-2 rounded-lg bg-white/5 border border-white/10 text-white focus:border-blue-500/50 focus:ring-2 focus:ring-blue-500/20 outline-none transition-all"
                />
              </div>
              <div>
                <label className="block text-sm font-medium mb-1 text-slate-300">ناوی تەواو</label>
                <input
                  type="text"
                  required
                  value={userForm.name}
                  onChange={e => setUserForm({...userForm, name: e.target.value})}
                  className="w-full p-2 rounded-lg bg-white/5 border border-white/10 text-white focus:border-blue-500/50 focus:ring-2 focus:ring-blue-500/20 outline-none transition-all"
                />
              </div>
              <div>
                <label className="block text-sm font-medium mb-1 text-slate-300">ناونیشانی وەزیفی</label>
                <input
                  type="text"
                  required
                  value={userForm.title}
                  onChange={e => setUserForm({...userForm, title: e.target.value})}
                  className="w-full p-2 rounded-lg bg-white/5 border border-white/10 text-white focus:border-blue-500/50 focus:ring-2 focus:ring-blue-500/20 outline-none transition-all"
                />
              </div>
              <div>
                <label className="block text-sm font-medium mb-1 text-slate-300">ڕۆڵ</label>
                <select
                  value={userForm.role}
                  onChange={e => setUserForm({...userForm, role: e.target.value as Role})}
                  className="w-full p-2 rounded-lg bg-slate-900 border border-white/10 text-white focus:border-blue-500/50 focus:ring-2 focus:ring-blue-500/20 outline-none transition-all"
                >
                  <option value="super_admin">بەڕێوەبەری سیستەم</option>
                  <option value="director_general">بەڕێوەبەری گشتی</option>
                  <option value="deputy_director">جێگری بەڕێوەبەر</option>
                  <option value="staff_officer">ئەفسەری ستاف</option>
                  <option value="office_manager">بەڕێوەبەری نووسینگە</option>
                  <option value="section_director">بەڕێوەبەری بەش</option>
                  <option value="unit_head">بەڕێوەبەری هۆبە</option>
                  <option value="employee">کارمەند</option>
                  <option value="dispatch_staff">کارمەندی ناردن</option>
                  <option value="print_staff">کارمەندی پڕێنت</option>
                  <option value="control_room">ژووری کۆنترۆڵ</option>
                </select>
              </div>
              <div>
                <label className="block text-sm font-medium mb-1 text-slate-300">بەش</label>
                <select
                  value={userForm.department}
                  onChange={e => setUserForm({...userForm, department: e.target.value})}
                  className="w-full p-2 rounded-lg bg-slate-900 border border-white/10 text-white focus:border-blue-500/50 focus:ring-2 focus:ring-blue-500/20 outline-none transition-all"
                >
                  {departments.map(d => (
                    <option key={d.id} value={d.id}>{d.name}</option>
                  ))}
                </select>
              </div>
              <div className="flex gap-3 mt-6">
                <button type="submit" className="flex-1 bg-blue-600 hover:bg-blue-500 text-white py-2 rounded-lg shadow-[0_0_15px_rgba(59,130,246,0.4)] transition-all hover:-translate-y-0.5">تۆمارکردن</button>
                <button type="button" onClick={() => setIsUserModalOpen(false)} className="flex-1 bg-white/10 hover:bg-white/20 text-slate-300 hover:text-white py-2 rounded-lg transition-all hover:shadow-[0_0_10px_rgba(255,255,255,0.05)]">پاشگەزبوونەوە</button>
              </div>
            </form>
          </div>
        </div>
      )}

      {/* Department Modal */}
      {isDeptModalOpen && (
        <div className="fixed inset-0 bg-black/80 backdrop-blur-md flex items-center justify-center z-50 animate-in fade-in duration-200">
          <div className="glass-panel rounded-2xl p-8 w-full max-w-md border border-white/10 shadow-2xl">
            <h3 className="text-xl font-bold mb-6 text-white neon-text">{editingDept ? 'دەستکاری بەش' : 'زیادکردنی بەش'}</h3>
            <form onSubmit={handleDeptSubmit} className="space-y-4">
              <div>
                <label className="block text-sm font-medium mb-1 text-slate-300">کۆدی بەش (ID)</label>
                <input
                  type="text"
                  required
                  disabled={!!editingDept}
                  value={deptForm.id}
                  onChange={e => setDeptForm({...deptForm, id: e.target.value})}
                  className="w-full p-2 rounded-lg bg-white/5 border border-white/10 text-white focus:border-blue-500/50 focus:ring-2 focus:ring-blue-500/20 outline-none transition-all disabled:opacity-50"
                  dir="ltr"
                />
              </div>
              <div>
                <label className="block text-sm font-medium mb-1 text-slate-300">ناوی بەش</label>
                <input
                  type="text"
                  required
                  value={deptForm.name}
                  onChange={e => setDeptForm({...deptForm, name: e.target.value})}
                  className="w-full p-2 rounded-lg bg-white/5 border border-white/10 text-white focus:border-blue-500/50 focus:ring-2 focus:ring-blue-500/20 outline-none transition-all"
                />
              </div>
              <div className="flex gap-3 mt-6">
                <button type="submit" className="flex-1 bg-emerald-600 hover:bg-emerald-500 text-white py-2 rounded-lg shadow-[0_0_15px_rgba(16,185,129,0.4)] transition-all hover:-translate-y-0.5">تۆمارکردن</button>
                <button type="button" onClick={() => setIsDeptModalOpen(false)} className="flex-1 bg-white/10 hover:bg-white/20 text-slate-300 hover:text-white py-2 rounded-lg transition-all hover:shadow-[0_0_10px_rgba(255,255,255,0.05)]">پاشگەزبوونەوە</button>
              </div>
            </form>
          </div>
        </div>
      )}

      {activeTab === 'logs' && (
        <div className="space-y-4">
          <div className="flex gap-4">
            <div className="flex-1 relative">
              <input
                type="text"
                value={searchTerm}
                onChange={e => setSearchTerm(e.target.value)}
                placeholder="گەڕان لە تۆمارەکان..."
                className="w-full pl-4 pr-10 py-3 rounded-xl bg-white/5 border border-white/10 focus:border-blue-500/50 focus:ring-2 focus:ring-blue-500/20 outline-none transition-all text-white placeholder:text-slate-500"
              />
              <Search className="absolute right-3 top-3.5 text-slate-400" size={20} />
            </div>
            <button
              onClick={exportLogs}
              className="bg-emerald-600 hover:bg-emerald-500 text-white px-6 py-3 rounded-xl font-medium flex items-center gap-2 transition-all shadow-[0_0_15px_rgba(16,185,129,0.4)] border border-white/10 hover:-translate-y-0.5"
            >
              <Download size={20} />
              داگرتن (Excel)
            </button>
          </div>

          <div className="bg-white/5 rounded-2xl shadow-sm border border-white/10 overflow-hidden">
            <table className="elite-table text-right">
              <thead>
                <tr>
                  <th>کات</th>
                  <th>بەکارهێنەر</th>
                  <th>کردار</th>
                  <th>ئامانج</th>
                  <th>جۆر</th>
                </tr>
              </thead>
              <tbody>
                {filteredLogs.map((log, idx) => (
                  <tr key={idx} className="group">
                    <td className="text-slate-400 text-sm font-mono" dir="ltr">
                      {new Date(log.timestamp).toLocaleString('en-US')}
                    </td>
                    <td className="font-medium text-white group-hover:text-blue-400 transition-colors">{log.userName}</td>
                    <td>
                      <span className={`badge-glow ${
                        log.action.includes('create') ? 'badge-success' :
                        log.action.includes('delete') ? 'badge-error' :
                        log.action.includes('update') ? 'badge-info' :
                        'badge-info'
                      }`}>
                        {log.action}
                      </span>
                    </td>
                    <td className="text-slate-300 font-mono text-sm">
                      {log.targetId}
                    </td>
                    <td className="text-slate-400 text-sm">
                      {log.type}
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        </div>
      )}

      {activeTab === 'backup' && (
        <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
          <div className="glass-panel p-8 rounded-2xl shadow-lg border border-white/10 text-center">
            <div className="w-20 h-20 bg-blue-500/20 rounded-full flex items-center justify-center mx-auto mb-6 border border-blue-500/30 shadow-[0_0_15px_rgba(59,130,246,0.3)]">
              <Download className="text-blue-400" size={40} />
            </div>
            <h3 className="text-xl font-bold text-white mb-2 neon-text">پاشەکەوتکردنی داتا</h3>
            <p className="text-slate-400 mb-8">
              هەموو داتاکانی سیستەم (نوسراوەکان، بەکارهێنەران، لۆگەکان) دابەزێنە وەک فایلێکی JSON بۆ پاراستن.
            </p>
            <button
              onClick={backupData}
              className="bg-blue-600 hover:bg-blue-500 text-white px-8 py-3 rounded-xl font-bold transition-all flex items-center gap-2 mx-auto shadow-[0_0_20px_rgba(59,130,246,0.4)] border border-white/10 hover:-translate-y-0.5"
            >
              <Database size={20} />
              داگرتنی پاشەکەوت
            </button>
          </div>

          <div className="glass-panel p-8 rounded-2xl shadow-lg border border-white/10 text-center">
            <div className="w-20 h-20 bg-emerald-500/20 rounded-full flex items-center justify-center mx-auto mb-6 border border-emerald-500/30 shadow-[0_0_15px_rgba(16,185,129,0.3)]">
              <Upload className="text-emerald-400" size={40} />
            </div>
            <h3 className="text-xl font-bold text-white mb-2 neon-text">گەڕاندنەوەی داتا</h3>
            <p className="text-slate-400 mb-8">
              فایلی پاشەکەوت (JSON) باربکە بۆ گەڕاندنەوەی داتاکانی سیستەم. ئاگاداربە داتاکانی ئێستا دەسڕدرێنەوە.
            </p>
            <input
              type="file"
              ref={fileInputRef}
              onChange={handleFileRestore}
              className="hidden"
              accept=".json"
            />
            <button
              onClick={() => fileInputRef.current?.click()}
              className="bg-emerald-600 hover:bg-emerald-500 text-white px-8 py-3 rounded-xl font-bold transition-all flex items-center gap-2 mx-auto shadow-[0_0_20px_rgba(16,185,129,0.4)] border border-white/10 hover:-translate-y-0.5"
            >
              <Upload size={20} />
              بارکردنی فایل
            </button>
          </div>
        </div>
      )}
    </div>
  );
};
