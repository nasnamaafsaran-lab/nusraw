import React, { useState } from 'react';
import { useApp } from '../context';
import { Send, FileText, ArrowLeft, Clock, CheckCircle2, XCircle, Paperclip, File, Download, UserCheck, QrCode, Edit2, Printer, RotateCcw, Activity, MessageSquare, Plus, Layers, Building2, Calendar, PenTool, Search } from 'lucide-react';
import { Document, Attachment } from '../types';
import { HandDeliveryModal } from './HandDelivery';
import QRCode from 'react-qr-code';
import printJS from 'print-js';

export const CreateDocument: React.FC<{ onSuccess: () => void }> = ({ onSuccess }) => {
  const { createDocument, currentUser, users, departments, uploadFiles, documents, workflowTemplates } = useApp();
  const [title, setTitle] = useState('');
  const [content, setContent] = useState('');
  const [targetId, setTargetId] = useState('');
  const [targetDeptId, setTargetDeptId] = useState('');
  const [workflowTemplateId, setWorkflowTemplateId] = useState('');
  const [priority, setPriority] = useState<'Normal' | 'Urgent' | 'Top Secret'>('Normal');
  const [confidentiality, setConfidentiality] = useState<'Normal' | 'Confidential' | 'Secret'>('Normal');
  const [selectedFiles, setSelectedFiles] = useState<File[]>([]);
  const [loading, setLoading] = useState(false);

  // New Fields
  const [incomingNumber, setIncomingNumber] = useState('');
  const [incomingDate, setIncomingDate] = useState(new Date().toISOString().split('T')[0]);
  const [source, setSource] = useState('');
  const [relatedRoomName, setRelatedRoomName] = useState('');
  const [relatedDocIds, setRelatedDocIds] = useState<string[]>([]);
  const [searchTerm, setSearchTerm] = useState('');
  const [note, setNote] = useState('');

  const [isDirectRequest, setIsDirectRequest] = useState(false);

  // Filter valid targets based on allowedDestinations
  const currentDeptInfo = departments.find(d => d.id === currentUser?.department);
  const allowedDestinations = currentDeptInfo?.allowedDestinations || [];

  const validTargets = users.filter(u => {
    if (u.id === currentUser?.id) return false; // Can't send to self
    return true; 
  });

  const handleFileChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    if (e.target.files && e.target.files.length > 0) {
      const newFiles = Array.from(e.target.files!);
      setSelectedFiles(prev => [...prev, ...newFiles]);
    }
  };

  const addAttachmentsToNote = () => {
    if (selectedFiles.length === 0) return;
    const fileList = selectedFiles.map(f => `- ${f.name}`).join('\n');
    setNote(prev => prev ? `${prev}\n\nهاوپێچەکان:\n${fileList}` : `هاوپێچەکان:\n${fileList}`);
  };

  const removeFile = (index: number) => {
    setSelectedFiles(prev => prev.filter((_, i) => i !== index));
  };

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    if (title && content && targetId) {
      setLoading(true);
      try {
        const uploadedAttachments = await uploadFiles(selectedFiles);
        // Append note to content if present
        const finalContent = note ? `${content}\n\nتێبینی:\n${note}` : content;
        
        let finalWorkflowStage = 'DISPATCH';
        let finalTemplateId = workflowTemplateId || undefined;

        if (isDirectRequest) {
            const targetUser = users.find(u => u.id === targetId);
            // Map target user role to a workflow stage if applicable, otherwise default to 'PENDING_REVIEW' or similar
            // For now, we can reuse existing stages if they match, or just set a generic 'DIRECT_INBOX' stage
            // However, the system relies on specific stages for filtering. 
            // Let's try to map to the user's "IN" stage based on their role.
            
            if (targetUser?.role === 'director_general') {
                finalWorkflowStage = 'DIRECTOR_REVIEW';
            } else if (targetUser?.role === 'deputy_director') {
                finalWorkflowStage = 'DEPUTY_REVIEW';
            } else if (targetUser?.role === 'section_director') {
                finalWorkflowStage = 'DEPT_HEAD_IN';
            } else if (targetUser?.role === 'unit_head') {
                finalWorkflowStage = 'UNIT_HEAD_IN';
            } else if (targetUser?.role === 'employee') {
                finalWorkflowStage = 'EMPLOYEE_ACTION';
            } else if (targetUser?.role === 'dispatch_staff') {
                finalWorkflowStage = 'DISPATCH';
            } else if (targetUser?.role === 'print_staff') {
                finalWorkflowStage = 'PRINT_ROOM';
            } else {
                 // Fallback for other roles or if no specific stage matches
                 finalWorkflowStage = 'DIRECT_ACTION'; 
            }
            finalTemplateId = undefined; // Direct requests bypass templates
        }

        createDocument(
          title, 
          finalContent, 
          targetId, 
          uploadedAttachments, 
          priority, 
          confidentiality, 
          false, // isCircular
          incomingNumber,
          incomingDate,
          source,
          relatedDocIds,
          finalTemplateId,
          isDirectRequest ? finalWorkflowStage : undefined,
          'official', // type
          undefined, // deadline
          relatedRoomName
        );
        onSuccess();
      } catch (error) {
        console.error('Failed to create document', error);
      } finally {
        setLoading(false);
      }
    }
  };

  return (
    <div className="max-w-7xl mx-auto" dir="rtl">
      <div className="glass-panel rounded-3xl shadow-2xl border border-white/10 overflow-hidden">
        {/* Header */}
        <div className="bg-white/5 p-8 text-white flex justify-between items-center border-b border-white/10 backdrop-blur-md">
          <div>
            <h2 className="text-3xl font-black flex items-center gap-3 neon-text">
              <FileText className="text-blue-400 drop-shadow-[0_0_10px_rgba(59,130,246,0.8)]" size={32} />
              تۆمارکردنی نوسراوی نوێ
            </h2>
            <p className="text-slate-400 mt-2 text-lg">پڕکردنەوەی زانیارییەکان بۆ دروستکردن و ناردنی نوسراوی فەرمی</p>
          </div>
          <div className="bg-white/10 px-4 py-2 rounded-xl backdrop-blur-sm border border-white/10 shadow-inner">
            <span className="text-sm font-mono opacity-80 text-blue-200">{new Date().toLocaleDateString('en-GB')}</span>
          </div>
        </div>
        
        <form onSubmit={handleSubmit} className="p-8">
          <div className="grid grid-cols-1 lg:grid-cols-12 gap-8">
            
            {/* Top Row: Incoming Information Card */}
            <div className="lg:col-span-12 bg-white/5 p-6 rounded-3xl border border-white/10 relative overflow-hidden group">
              <div className="absolute top-0 right-0 w-32 h-32 bg-blue-500/10 rounded-bl-full -mr-10 -mt-10 transition-transform group-hover:scale-110" />
              
              <h3 className="text-lg font-bold text-white mb-6 flex items-center gap-2 relative z-10">
                <Building2 className="text-blue-400" />
                زانیاری نوسراوی هاتوو (Incoming Information)
              </h3>

              <div className="grid grid-cols-1 md:grid-cols-3 gap-6 relative z-10">
                <div>
                  <label className="block text-sm font-bold text-slate-300 mb-2">نوسراو لە کوێ هاتووە</label>
                  <div className="relative">
                    <input
                      type="text"
                      value={source}
                      onChange={e => setSource(e.target.value)}
                      className="w-full pl-4 pr-10 py-3 rounded-xl bg-black/20 border border-white/10 focus:border-blue-500/50 focus:ring-2 focus:ring-blue-500/20 outline-none transition-all text-white placeholder:text-slate-600"
                    />
                    <Building2 className="absolute right-3 top-3.5 text-slate-500" size={18} />
                  </div>
                </div>

                <div>
                  <label className="block text-sm font-bold text-slate-300 mb-2">ژمارەی نوسراو (هاتوو)</label>
                  <div className="relative">
                    <input
                      type="text"
                      value={incomingNumber}
                      onChange={e => setIncomingNumber(e.target.value)}
                      className="w-full pl-4 pr-10 py-3 rounded-xl bg-black/20 border border-white/10 focus:border-blue-500/50 focus:ring-2 focus:ring-blue-500/20 outline-none transition-all text-white font-mono placeholder:text-slate-600"
                    />
                    <FileText className="absolute right-3 top-3.5 text-slate-500" size={18} />
                  </div>
                </div>

                <div>
                  <label className="block text-sm font-bold text-slate-300 mb-2">بەرواری نوسراو</label>
                  <div className="relative">
                    <input
                      type="date"
                      value={incomingDate}
                      onChange={e => setIncomingDate(e.target.value)}
                      className="w-full pl-4 pr-10 py-3 rounded-xl bg-black/20 border border-white/10 focus:border-blue-500/50 focus:ring-2 focus:ring-blue-500/20 outline-none transition-all text-white placeholder:text-slate-600"
                    />
                    <Calendar className="absolute right-3 top-3.5 text-slate-500" size={18} />
                  </div>
                </div>

                <div>
                  <label className="block text-sm font-bold text-slate-300 mb-2">ناوی ژووری پەیوەندیدار</label>
                  <div className="relative">
                    <input
                      type="text"
                      value={relatedRoomName}
                      onChange={e => setRelatedRoomName(e.target.value)}
                      className="w-full pl-4 pr-10 py-3 rounded-xl bg-black/20 border border-white/10 focus:border-blue-500/50 focus:ring-2 focus:ring-blue-500/20 outline-none transition-all text-white placeholder:text-slate-600"
                      placeholder="ناوی ژوور..."
                    />
                    <Layers className="absolute right-3 top-3.5 text-slate-500" size={18} />
                  </div>
                </div>
              </div>
            </div>

            {/* Main Content Column */}
            <div className="lg:col-span-8 space-y-6">
              <div>
                <label className="block text-sm font-bold text-slate-300 mb-2">بابەتی نوسراو</label>
                <input
                  type="text"
                  value={title}
                  onChange={e => setTitle(e.target.value)}
                  className="w-full px-5 py-4 rounded-2xl bg-white/5 border border-white/10 focus:border-blue-500/50 focus:ring-4 focus:ring-blue-500/10 outline-none transition-all text-lg font-bold text-white placeholder:font-normal placeholder:text-slate-500"
                  placeholder="ناونیشانی نوسراو..."
                  required
                />
              </div>

              <div>
                <label className="block text-sm font-bold text-slate-300 mb-2">ناوەڕۆک</label>
                <textarea
                  value={content}
                  onChange={e => setContent(e.target.value)}
                  className="w-full px-5 py-4 rounded-2xl bg-white/5 border border-white/10 focus:border-blue-500/50 focus:ring-4 focus:ring-blue-500/10 outline-none transition-all h-48 resize-none text-lg leading-relaxed text-slate-200 placeholder:text-slate-500"
                  placeholder="دەقی نوسراو..."
                  required
                />
              </div>

              <div>
                <label className="block text-sm font-bold text-slate-300 mb-2">پەیوەندی بە نوسراوی تر</label>
                <div className="space-y-3">
                  <div className="relative">
                    <Search className="absolute right-3 top-3.5 text-slate-500" size={18} />
                    <input 
                      type="text" 
                      placeholder="گەڕان بۆ نوسراو..." 
                      className="w-full pr-10 pl-4 py-3 rounded-xl bg-white/5 border border-white/10 focus:border-blue-500/50 outline-none text-white"
                      value={searchTerm}
                      onChange={(e) => setSearchTerm(e.target.value)}
                    />
                  </div>
                  
                  <div className="max-h-48 overflow-y-auto custom-scrollbar bg-black/20 rounded-xl border border-white/10 p-2">
                    {documents
                      .filter(doc => 
                        doc.title.toLowerCase().includes(searchTerm.toLowerCase()) || 
                        doc.referenceNumber.toLowerCase().includes(searchTerm.toLowerCase())
                      )
                      .map(doc => (
                      <div 
                        key={doc.id} 
                        onClick={() => {
                          if (relatedDocIds.includes(doc.id)) {
                            setRelatedDocIds(prev => prev.filter(id => id !== doc.id));
                          } else {
                            setRelatedDocIds(prev => [...prev, doc.id]);
                          }
                        }}
                        className={`p-3 rounded-lg cursor-pointer flex items-center justify-between mb-1 transition-colors ${
                          relatedDocIds.includes(doc.id) 
                            ? 'bg-blue-600/20 border border-blue-500/30' 
                            : 'hover:bg-white/5 border border-transparent'
                        }`}
                      >
                        <div>
                          <div className="text-sm font-bold text-white">{doc.title}</div>
                          <div className="text-xs text-slate-400 font-mono">{doc.referenceNumber}</div>
                        </div>
                        {relatedDocIds.includes(doc.id) && <CheckCircle2 size={16} className="text-blue-400" />}
                      </div>
                    ))}
                  </div>
                  
                  {relatedDocIds.length > 0 && (
                    <div className="flex flex-wrap gap-2 mt-2">
                      {relatedDocIds.map(id => {
                        const doc = documents.find(d => d.id === id);
                        return (
                          <span key={id} className="bg-blue-500/10 text-blue-400 px-2 py-1 rounded-lg text-xs flex items-center gap-1 border border-blue-500/20">
                            {doc?.referenceNumber}
                            <button onClick={() => setRelatedDocIds(prev => prev.filter(dId => dId !== id))} className="hover:text-white">
                              <XCircle size={12} />
                            </button>
                          </span>
                        );
                      })}
                    </div>
                  )}
                </div>
              </div>

              <div>
                <label className="block text-sm font-bold text-slate-300 mb-2">هاوپێچەکان (Word / Excel / PDF)</label>
                <div className="border-2 border-dashed border-white/20 rounded-2xl p-8 hover:bg-white/5 transition-colors text-center group cursor-pointer relative bg-white/5">
                  <input type="file" className="absolute inset-0 w-full h-full opacity-0 cursor-pointer" onChange={handleFileChange} multiple accept=".doc,.docx,.xls,.xlsx,.pdf,.jpg,.png" />
                  <div className="w-20 h-20 bg-blue-500/10 text-blue-400 rounded-full flex items-center justify-center mx-auto mb-4 group-hover:scale-110 transition-transform shadow-[0_0_20px_rgba(59,130,246,0.3)]">
                    <Paperclip size={32} />
                  </div>
                  <p className="text-slate-300 font-bold text-lg">کلیک بکە یان فایلەکە ڕابکێشە بۆ ئێرە</p>
                  <p className="text-sm text-slate-500 mt-2">Word, Excel, PDF (زۆرترین قەبارە ١٠ مێگابایت)</p>
                </div>

                {selectedFiles.length > 0 && (
                  <div className="mt-4">
                    <button
                      type="button"
                      onClick={addAttachmentsToNote}
                      className="text-xs bg-blue-500/10 text-blue-400 px-3 py-1.5 rounded-lg hover:bg-blue-500/20 hover:text-white transition-all flex items-center gap-2 mb-4 border border-blue-500/20 hover:shadow-[0_0_10px_rgba(59,130,246,0.2)]"
                    >
                      <Plus size={14} />
                      زیادکردنی ناوی فایلەکان بۆ تێبینی
                    </button>
                    
                    <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                      {selectedFiles.map((file, index) => {
                        let type = 'other';
                        if (file.name.endsWith('.pdf')) type = 'pdf';
                        else if (file.name.match(/\.(doc|docx)$/)) type = 'word';
                        else if (file.name.match(/\.(xls|xlsx)$/)) type = 'excel';
                        
                        const previewUrl = URL.createObjectURL(file);

                        return (
                          <div key={index} className="group relative flex items-center justify-between bg-white/5 p-4 rounded-2xl border border-white/10 hover:border-blue-500/50 transition-all hover:bg-white/10 overflow-hidden">
                            <div className="flex items-center gap-4 relative z-10">
                              <div className={`w-12 h-12 rounded-xl flex items-center justify-center flex-shrink-0 shadow-lg ${
                                type === 'pdf' ? 'bg-red-500/20 text-red-400' :
                                type === 'word' ? 'bg-blue-500/20 text-blue-400' :
                                type === 'excel' ? 'bg-green-500/20 text-green-400' :
                                'bg-slate-500/20 text-slate-400'
                              }`}>
                                <File size={24} />
                              </div>
                              <div className="overflow-hidden">
                                <span className="text-sm font-bold text-slate-200 truncate block max-w-[200px]">{file.name}</span>
                                <span className="text-xs text-slate-500 uppercase font-mono">{(file.size / 1024 / 1024).toFixed(2)} MB</span>
                              </div>
                            </div>
                            
                            <button type="button" onClick={() => removeFile(index)} className="relative z-10 text-red-400 hover:bg-red-500/10 hover:text-red-300 p-2 rounded-xl transition-all hover:shadow-[0_0_10px_rgba(239,68,68,0.2)]">
                              <XCircle size={24} />
                            </button>

                            {/* Preview Overlay on Hover */}
                            <div className="absolute inset-0 bg-black/80 backdrop-blur-sm opacity-0 group-hover:opacity-100 transition-opacity duration-300 flex items-center justify-center z-20 pointer-events-none">
                               <div className="text-center transform translate-y-4 group-hover:translate-y-0 transition-transform duration-300">
                                 <p className="text-white font-bold text-sm mb-1">Preview Available</p>
                                 <p className="text-xs text-blue-400">Click to Open</p>
                               </div>
                            </div>
                            {/* Invisible link to open file */}
                            <a href={previewUrl} target="_blank" rel="noreferrer" className="absolute inset-0 z-30" title="Click to Preview"></a>
                          </div>
                        );
                      })}
                    </div>
                  </div>
                )}
              </div>
            </div>

            {/* Right Column - Routing & Meta */}
            <div className="lg:col-span-4 space-y-6">
              <div className="bg-white/5 p-6 rounded-3xl border border-white/10 space-y-6 backdrop-blur-sm sticky top-6">
                
                {/* Request Type Toggle */}
                <div>
                  <label className="block text-sm font-bold text-slate-300 mb-2">جۆری ناردن</label>
                  <div className="flex gap-2 bg-black/20 p-1 rounded-xl border border-white/10">
                      <button
                        type="button"
                        onClick={() => { setIsDirectRequest(false); setTargetId(''); setTargetDeptId(''); }}
                        className={`flex-1 py-2 rounded-lg text-sm font-bold transition-all ${!isDirectRequest ? 'bg-gradient-to-r from-blue-600 to-blue-500 text-white shadow-[0_5px_15px_rgba(37,99,235,0.3)]' : 'text-slate-400 hover:text-white hover:bg-white/5'}`}
                      >
                        ڕەوتی ئاسایی
                      </button>
                      <button
                        type="button"
                        onClick={() => { setIsDirectRequest(true); setTargetId(''); setTargetDeptId(''); }}
                        className={`flex-1 py-2 rounded-lg text-sm font-bold transition-all ${isDirectRequest ? 'bg-gradient-to-r from-purple-600 to-purple-500 text-white shadow-[0_5px_15px_rgba(147,51,234,0.3)]' : 'text-slate-400 hover:text-white hover:bg-white/5'}`}
                      >
                        داواکاری تایبەت
                      </button>
                  </div>
                  {isDirectRequest && (
                    <p className="text-xs text-purple-400 mt-2 bg-purple-500/10 p-2 rounded border border-purple-500/20">
                      ئەم نوسراوە ڕاستەوخۆ دەچێت بۆ کەسی دیاریکراو بەبێ تێپەڕبوون بە ڕەوتی ئاسایی.
                    </p>
                  )}
                </div>

                {!isDirectRequest && (
                  <div>
                    <label className="block text-sm font-bold text-slate-300 mb-2">ڕەوتی کار</label>
                    <p className="text-xs text-slate-500 mb-3">دیاری بکە ئەم نوسراوە بە چ ڕەوتێکی کاردا دەڕوات</p>
                    <select
                      value={workflowTemplateId}
                      onChange={e => setWorkflowTemplateId(e.target.value)}
                      className="w-full px-4 py-3 rounded-xl bg-slate-900 border border-white/10 focus:border-purple-500 focus:ring-2 focus:ring-purple-500/20 outline-none transition-all text-white"
                    >
                      <option value="" className="bg-slate-900">ڕەوتی کاری ئاسایی (Manual)</option>
                      {workflowTemplates.map(template => (
                        <option key={template.id} value={template.id} className="bg-slate-900">
                          {template.name}
                        </option>
                      ))}
                    </select>
                    {workflowTemplateId && (
                      <div className="mt-4 bg-white/5 p-4 rounded-2xl border border-white/10 animate-in slide-in-from-top-2 duration-300">
                        <h4 className="text-[10px] font-bold text-slate-500 uppercase tracking-widest mb-3">هەنگاوەکانی ئەم قاڵبە:</h4>
                        <div className="space-y-2">
                          {workflowTemplates.find(t => t.id === workflowTemplateId)?.steps.map((step, idx) => (
                            <div key={step.id} className="flex items-center gap-3 text-[11px]">
                              <div className="w-5 h-5 rounded-full bg-purple-600 text-white flex items-center justify-center font-bold text-[9px]">
                                {idx + 1}
                              </div>
                              <span className="text-slate-300">{step.label}</span>
                              <span className="text-slate-600 mr-auto">({step.role})</span>
                            </div>
                          ))}
                        </div>
                      </div>
                    )}
                  </div>
                )}

                <div>
                  <label className="block text-sm font-bold text-slate-300 mb-2">ناردن بۆ</label>
                  <p className="text-xs text-slate-500 mb-3">دیاری بکە ئەم نوسراوە بۆ کێ دەچێت</p>
                  
                  <div className="space-y-3">
                    {!isDirectRequest && (
                      <select
                        value={targetDeptId}
                        onChange={e => {
                          setTargetDeptId(e.target.value);
                          setTargetId('');
                        }}
                        className="w-full px-4 py-3 rounded-xl bg-slate-900 border border-white/10 focus:border-purple-500 focus:ring-2 focus:ring-purple-500/20 outline-none transition-all text-white"
                      >
                        <option value="" className="bg-slate-900">هەڵبژاردنی بەش / ژوور...</option>
                        {departments.map(dept => (
                          <option key={dept.id} value={dept.id} className="bg-slate-900">
                            {dept.name}
                          </option>
                        ))}
                      </select>
                    )}

                    <select
                      value={targetId}
                      onChange={e => setTargetId(e.target.value)}
                      className="w-full px-4 py-3 rounded-xl bg-slate-900 border border-white/10 focus:border-blue-500 focus:ring-2 focus:ring-blue-500/20 outline-none transition-all text-white"
                      required
                      disabled={!isDirectRequest && !targetDeptId}
                    >
                      <option value="" className="bg-slate-900">هەڵبژاردنی کەسی وەرگر...</option>
                      {isDirectRequest ? (
                        users.filter(u => u.id !== currentUser?.id).map(user => (
                          <option key={user.id} value={user.id} className="bg-slate-900">
                            {user.title} - {user.name} ({user.role})
                          </option>
                        ))
                      ) : (
                        users.filter(u => u.department === targetDeptId && u.id !== currentUser?.id).map(user => (
                          <option key={user.id} value={user.id} className="bg-slate-900">
                            {user.title} - {user.name}
                          </option>
                        ))
                      )}
                    </select>
                  </div>
                </div>

                <div>
                  <label className="block text-sm font-bold text-slate-300 mb-2">گرنگی</label>
                  <div className="grid grid-cols-1 gap-2">
                    {[
                      { id: 'Normal', label: 'ئاسایی', color: 'bg-blue-600 shadow-[0_0_10px_rgba(37,99,235,0.5)]' },
                      { id: 'Urgent', label: 'بەپەلە', color: 'bg-orange-500 shadow-[0_0_10px_rgba(249,115,22,0.5)]' },
                      { id: 'Top Secret', label: 'زۆر بەپەلە', color: 'bg-red-600 shadow-[0_0_10px_rgba(220,38,38,0.5)]' }
                    ].map(opt => (
                      <button
                        key={opt.id}
                        type="button"
                        onClick={() => setPriority(opt.id as any)}
                        className={`py-3 rounded-xl text-sm font-bold transition-all flex items-center justify-between px-4 ${priority === opt.id ? `${opt.color} text-white scale-105 ring-2 ring-white/20 shadow-lg` : 'bg-white/5 border border-white/10 text-slate-400 hover:bg-white/10 hover:text-white hover:shadow-[0_0_15px_rgba(255,255,255,0.05)]'}`}
                      >
                        <span>{opt.label}</span>
                        {priority === opt.id && <CheckCircle2 size={16} />}
                      </button>
                    ))}
                  </div>
                </div>

                <div>
                  <label className="block text-sm font-bold text-slate-300 mb-2">نهێنی بوون</label>
                  <div className="grid grid-cols-1 gap-2">
                    {[
                      { id: 'Normal', label: 'ئاسایی', color: 'bg-slate-600 shadow-[0_0_10px_rgba(71,85,105,0.5)]' },
                      { id: 'Confidential', label: 'نهێنی', color: 'bg-purple-600 shadow-[0_0_10px_rgba(147,51,234,0.5)]' },
                      { id: 'Secret', label: 'زۆر نهێنی', color: 'bg-red-900 shadow-[0_0_10px_rgba(127,29,29,0.5)]' }
                    ].map(opt => (
                      <button
                        key={opt.id}
                        type="button"
                        onClick={() => setConfidentiality(opt.id as any)}
                        className={`py-3 rounded-xl text-sm font-bold transition-all flex items-center justify-between px-4 ${confidentiality === opt.id ? `${opt.color} text-white scale-105 ring-2 ring-white/20 shadow-lg` : 'bg-white/5 border border-white/10 text-slate-400 hover:bg-white/10 hover:text-white hover:shadow-[0_0_15px_rgba(255,255,255,0.05)]'}`}
                      >
                        <span>{opt.label}</span>
                        {confidentiality === opt.id && <CheckCircle2 size={16} />}
                      </button>
                    ))}
                  </div>
                </div>

                <div>
                  <label className="block text-sm font-bold text-slate-300 mb-2">تێبینی</label>
                  <textarea
                    value={note}
                    onChange={e => setNote(e.target.value)}
                    className="w-full px-4 py-3 rounded-xl bg-slate-900 border border-white/10 focus:border-blue-500/50 outline-none transition-all h-32 resize-none text-white placeholder:text-slate-500"
                    placeholder="تێبینی زیادە..."
                  />
                </div>

                <button
                  type="submit"
                  disabled={loading}
                  className="relative w-full group bg-gradient-to-r from-blue-600 to-indigo-600 hover:from-blue-500 hover:to-indigo-500 text-white py-4 rounded-2xl font-black text-lg shadow-[0_10px_30px_rgba(37,99,235,0.3)] hover:shadow-[0_20px_40px_rgba(37,99,235,0.4)] transition-all hover:-translate-y-1 flex items-center justify-center gap-3 border border-white/20 disabled:opacity-50 disabled:cursor-not-allowed mt-6 overflow-hidden"
                >
                  <div className="absolute inset-0 bg-gradient-to-r from-transparent via-white/20 to-transparent translate-x-[-100%] group-hover:translate-x-[100%] transition-transform duration-1000" />
                  <Send size={24} className="group-hover:translate-x-1 transition-transform" />
                  <span className="relative z-10">{loading ? 'دەینێرێت...' : 'ناردنی نوسراو'}</span>
                </button>
              </div>
            </div>

          </div>
        </form>
      </div>
    </div>
  );
};

export const EmployeeRequestsPanel: React.FC = () => {
  const { documents, currentUser, users, createDocument, addComment, updateDocument, uploadFiles, workflowTemplates, departments, getVisibleDocuments } = useApp();
  const [showNewRequestForm, setShowNewRequestForm] = useState(false);
  const [selectedRequest, setSelectedRequest] = useState<Document | null>(null);

  React.useEffect(() => {
    if (selectedRequest) {
      const updatedReq = documents.find(d => d.id === selectedRequest.id);
      if (updatedReq && updatedReq !== selectedRequest) {
        setSelectedRequest(updatedReq);
      }
    }
  }, [documents, selectedRequest?.id]);
  
  // New Request Form State
  const [title, setTitle] = useState('');
  const [content, setContent] = useState('');
  const [targetId, setTargetId] = useState('');
  const [targetDeptId, setTargetDeptId] = useState('');
  const [workflowTemplateId, setWorkflowTemplateId] = useState('');
  const [isDirectRequest, setIsDirectRequest] = useState(false);
  const [attachSignature, setAttachSignature] = useState(false);
  const [deadlineDays, setDeadlineDays] = useState(0);
  const [deadlineHours, setDeadlineHours] = useState(0);
  const [selectedFiles, setSelectedFiles] = useState<File[]>([]);
  const [loading, setLoading] = useState(false);
  const [commentText, setCommentText] = useState('');

  // Filter requests
  const myRequests = getVisibleDocuments().filter(d => d.type === 'request');
  
  // Only the requester and the recipient should see the request
  const allRequests = myRequests;

  const handleFileChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    if (e.target.files && e.target.files.length > 0) {
      setSelectedFiles(prev => [...prev, ...Array.from(e.target.files!)]);
    }
  };

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    if (title && content) {
      setLoading(true);
      try {
        const uploadedAttachments = await uploadFiles(selectedFiles);
        
        let finalWorkflowStage = 'DISPATCH';
        let finalTemplateId = workflowTemplateId || undefined;

        if (isDirectRequest) {
            const targetUser = users.find(u => u.id === targetId);
            if (targetUser?.role === 'director_general') {
                finalWorkflowStage = 'DIRECTOR_REVIEW';
            } else if (targetUser?.role === 'deputy_director') {
                finalWorkflowStage = 'DEPUTY_REVIEW';
            } else {
                 finalWorkflowStage = 'DIRECT_ACTION'; 
            }
            finalTemplateId = undefined;
        }

        // Add signature note if attached
        const finalContent = attachSignature 
          ? `${content}\n\n[ واژۆی ئەلیکترۆنی: ${currentUser?.name} - ${new Date().toLocaleString()} ]`
          : content;

        let calculatedDeadline = undefined;
        if (deadlineDays > 0 || deadlineHours > 0) {
          const now = new Date();
          now.setDate(now.getDate() + deadlineDays);
          now.setHours(now.getHours() + deadlineHours);
          calculatedDeadline = now.toISOString();
        }

        await createDocument(
          title,
          finalContent,
          targetId,
          uploadedAttachments,
          'Normal',
          'Normal',
          false,
          undefined,
          undefined,
          undefined,
          undefined,
          finalTemplateId,
          isDirectRequest ? finalWorkflowStage : undefined,
          'request',
          calculatedDeadline
        );
        setShowNewRequestForm(false);
        setTitle('');
        setContent('');
        setTargetId('');
        setTargetDeptId('');
        setWorkflowTemplateId('');
        setAttachSignature(false);
        setSelectedFiles([]);
      } catch (error) {
        console.error(error);
      } finally {
        setLoading(false);
      }
    }
  };

  const handleAddComment = async () => {
    if (!selectedRequest || !commentText.trim()) return;
    await addComment(selectedRequest.id, commentText);
    setCommentText('');
  };

  const handleStatusUpdate = async (status: 'Approved' | 'Rejected') => {
    if (!selectedRequest) return;
    await updateDocument(selectedRequest.id, { status });
    setSelectedRequest(prev => prev ? ({ ...prev, status }) : null);
  };

  if (selectedRequest) {
    return (
      <div className="max-w-5xl mx-auto">
        <button onClick={() => setSelectedRequest(null)} className="mb-4 flex items-center gap-2 text-slate-400 hover:text-white transition-all hover:-translate-x-1 px-3 py-2 rounded-lg hover:bg-white/5">
          <ArrowLeft size={20} />
          گەڕانەوە
        </button>

        <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
          {/* Main Content */}
          <div className="lg:col-span-2 space-y-6">
            <div className="glass-panel p-8 rounded-3xl border border-white/10">
              <div className="flex justify-between items-start mb-6">
                <div>
                  <h2 className="text-2xl font-bold text-white mb-2">{selectedRequest.title}</h2>
                  <div className="flex items-center gap-4 text-sm text-slate-400">
                    <span className="flex items-center gap-1"><UserCheck size={14} /> {selectedRequest.senderName}</span>
                    <span className="flex items-center gap-1"><Clock size={14} /> {new Date(selectedRequest.createdAt).toLocaleDateString()}</span>
                    <span className={`px-2 py-0.5 rounded text-xs font-bold ${
                      selectedRequest.status === 'Approved' ? 'bg-green-500/20 text-green-400' :
                      selectedRequest.status === 'Rejected' ? 'bg-red-500/20 text-red-400' :
                      'bg-yellow-500/20 text-yellow-400'
                    }`}>
                      {selectedRequest.status === 'Approved' ? 'قبوڵکراوە' :
                       selectedRequest.status === 'Rejected' ? 'ڕەتکراوەتەوە' : 'چاوەڕوانە'}
                    </span>
                  </div>
                </div>
                {(currentUser?.role === 'director_general' || currentUser?.role === 'deputy_director') && selectedRequest.status === 'Pending' && (
                  <div className="flex gap-2">
                    <button onClick={() => handleStatusUpdate('Approved')} className="bg-gradient-to-r from-green-600 to-green-500 hover:from-green-500 hover:to-green-400 text-white p-2 rounded-lg transition-all shadow-[0_0_15px_rgba(22,163,74,0.3)] hover:-translate-y-0.5" title="قبوڵکردن">
                      <CheckCircle2 size={20} />
                    </button>
                    <button onClick={() => handleStatusUpdate('Rejected')} className="bg-gradient-to-r from-red-600 to-red-500 hover:from-red-500 hover:to-red-400 text-white p-2 rounded-lg transition-all shadow-[0_0_15px_rgba(220,38,38,0.3)] hover:-translate-y-0.5" title="ڕەتکردنەوە">
                      <XCircle size={20} />
                    </button>
                  </div>
                )}
              </div>

              <div className="prose prose-invert max-w-none mb-8">
                <p className="whitespace-pre-wrap text-slate-300 leading-relaxed">{selectedRequest.content}</p>
              </div>

              {selectedRequest.attachments.length > 0 && (
                <div className="border-t border-white/10 pt-6">
                  <h4 className="text-sm font-bold text-slate-400 mb-4 flex items-center gap-2">
                    <Paperclip size={16} />
                    هاوپێچەکان
                  </h4>
                  <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
                    {selectedRequest.attachments.map(att => (
                      <a key={att.id} href={att.url} download={att.name} className="flex items-center gap-3 p-3 rounded-xl bg-white/5 hover:bg-white/10 transition-colors border border-white/5">
                        <File size={20} className="text-blue-400" />
                        <span className="text-sm text-slate-300 truncate">{att.name}</span>
                      </a>
                    ))}
                  </div>
                </div>
              )}
            </div>
          </div>

          {/* Comments / Note Board */}
          <div className="lg:col-span-1">
            <div className="glass-panel p-6 rounded-3xl border border-white/10 h-full flex flex-col">
              <h3 className="text-lg font-bold text-white mb-4 flex items-center gap-2">
                <MessageSquare size={18} className="text-yellow-400" />
                بۆردی تێبینی
              </h3>
              
              <div className="flex-1 overflow-y-auto custom-scrollbar space-y-4 mb-4 max-h-[500px]">
                {selectedRequest.comments?.length === 0 ? (
                  <p className="text-center text-slate-500 text-sm py-8">هیچ تێبینییەک نییە</p>
                ) : (
                  selectedRequest.comments?.map(comment => (
                    <div key={comment.id} className={`p-3 rounded-xl ${comment.userId === currentUser?.id ? 'bg-blue-500/10 border border-blue-500/20 mr-4' : 'bg-white/5 border border-white/10 ml-4'}`}>
                      <div className="flex justify-between items-center mb-1">
                        <span className="text-xs font-bold text-slate-300">{comment.userName}</span>
                        <span className="text-[10px] text-slate-500">{new Date(comment.timestamp).toLocaleTimeString()}</span>
                      </div>
                      <p className="text-sm text-slate-200">{comment.content}</p>
                    </div>
                  ))
                )}
              </div>

              <div className="mt-auto">
                <div className="relative">
                  <input
                    type="text"
                    value={commentText}
                    onChange={e => setCommentText(e.target.value)}
                    placeholder="تێبینی بنووسە..."
                    className="w-full pl-10 pr-4 py-3 rounded-xl bg-black/20 border border-white/10 focus:border-yellow-500/50 outline-none text-white text-sm"
                    onKeyDown={e => e.key === 'Enter' && handleAddComment()}
                  />
                  <button 
                    onClick={handleAddComment}
                    className="absolute left-2 top-2 p-1.5 text-yellow-400 hover:bg-yellow-500/10 rounded-lg transition-all hover:scale-110"
                  >
                    <Send size={16} />
                  </button>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
    );
  }

  return (
    <div className="max-w-7xl mx-auto">
      <div className="flex justify-between items-center mb-8">
        <div>
          <h2 className="text-3xl font-black text-white flex items-center gap-3">
            <MessageSquare className="text-purple-400" size={32} />
            داواکارییەکان
          </h2>
          <p className="text-slate-400 mt-1">بەڕێوەبردنی داواکاری و پێشنیارەکان</p>
        </div>
        <button
          onClick={() => setShowNewRequestForm(true)}
          className="bg-gradient-to-r from-purple-600 to-purple-500 hover:from-purple-500 hover:to-purple-400 text-white px-6 py-3 rounded-xl font-bold transition-all shadow-[0_10px_20px_rgba(147,51,234,0.3)] hover:shadow-[0_15px_30px_rgba(147,51,234,0.4)] hover:-translate-y-1 flex items-center gap-2 border border-white/10"
        >
          <Plus size={20} />
          داواکاری نوێ
        </button>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
        {allRequests.map(req => (
          <div 
            key={req.id} 
            onClick={() => setSelectedRequest(req)}
            className="glass-panel p-6 rounded-2xl border border-white/10 hover:border-purple-500/50 transition-all cursor-pointer group relative overflow-hidden"
          >
            <div className="absolute top-0 right-0 w-20 h-20 bg-purple-500/5 rounded-bl-full -mr-10 -mt-10 transition-transform group-hover:scale-110" />
            
            <div className="flex justify-between items-start mb-4 relative z-10">
              <div className="flex items-center gap-3">
                <div className="w-10 h-10 rounded-full bg-purple-500/10 flex items-center justify-center text-purple-400">
                  <UserCheck size={20} />
                </div>
                <div>
                  <h3 className="font-bold text-white truncate max-w-[150px]">{req.title}</h3>
                  <p className="text-xs text-slate-400">{req.senderName}</p>
                </div>
              </div>
              <span className={`px-2 py-1 rounded-lg text-xs font-bold ${
                req.status === 'Approved' ? 'bg-green-500/10 text-green-400 border border-green-500/20' :
                req.status === 'Rejected' ? 'bg-red-500/10 text-red-400 border border-red-500/20' :
                'bg-yellow-500/10 text-yellow-400 border border-yellow-500/20'
              }`}>
                {req.status === 'Approved' ? 'قبوڵکراوە' :
                 req.status === 'Rejected' ? 'ڕەتکراوە' : 'چاوەڕوانە'}
              </span>
            </div>
            
            <p className="text-slate-400 text-sm line-clamp-2 mb-4 relative z-10">
              {req.content}
            </p>

            <div className="flex items-center justify-between text-xs text-slate-500 border-t border-white/5 pt-4 relative z-10">
              <span className="flex items-center gap-1">
                <Clock size={12} />
                {new Date(req.createdAt).toLocaleDateString()}
              </span>
              {req.comments?.length > 0 && (
                <span className="flex items-center gap-1 text-purple-400">
                  <MessageSquare size={12} />
                  {req.comments.length} تێبینی
                </span>
              )}
            </div>
          </div>
        ))}
      </div>

      {showNewRequestForm && (
        <div className="fixed inset-0 bg-black/60 backdrop-blur-sm flex items-center justify-center z-50 p-4">
          <div className="glass-panel rounded-3xl shadow-2xl border border-white/10 overflow-hidden w-full max-w-4xl max-h-[90vh] flex flex-col">
            <div className="bg-white/5 p-6 border-b border-white/10 flex justify-between items-center shrink-0">
              <h2 className="text-2xl font-bold text-white flex items-center gap-2">
                <MessageSquare className="text-purple-400" />
                داواکاری نوێ
              </h2>
              <button onClick={() => setShowNewRequestForm(false)} className="text-slate-400 hover:text-white hover:bg-white/10 p-2 rounded-full transition-all">
                <XCircle size={24} />
              </button>
            </div>
            
            <div className="overflow-y-auto custom-scrollbar p-8">
              <form onSubmit={handleSubmit} className="space-y-6">
                <div>
                  <label className="block text-sm font-bold text-slate-300 mb-2">بابەت</label>
                  <input
                    type="text"
                    value={title}
                    onChange={e => setTitle(e.target.value)}
                    className="w-full px-4 py-3 rounded-xl bg-white/5 border border-white/10 focus:border-purple-500 outline-none text-white"
                    placeholder="بابەتی داواکاری..."
                    required
                  />
                </div>

                <div>
                  <label className="block text-sm font-bold text-slate-300 mb-2">ناوەڕۆک</label>
                  <textarea
                    value={content}
                    onChange={e => setContent(e.target.value)}
                    className="w-full px-4 py-3 rounded-xl bg-white/5 border border-white/10 focus:border-purple-500 outline-none text-white h-32 resize-none"
                    placeholder="وردەکاری داواکاری..."
                    required
                  />
                </div>

                {/* Workflow / Destination Selection */}
                <div className="bg-white/5 p-6 rounded-2xl border border-white/10 space-y-4">
                  <div>
                    <label className="block text-sm font-bold text-slate-300 mb-2">جۆری ناردن</label>
                    <div className="flex gap-2 bg-black/20 p-1 rounded-xl border border-white/10">
                      <button
                        type="button"
                        onClick={() => { setIsDirectRequest(false); setTargetId(''); setTargetDeptId(''); }}
                        className={`flex-1 py-2 rounded-lg text-sm font-bold transition-all ${!isDirectRequest ? 'bg-gradient-to-r from-blue-600 to-blue-500 text-white shadow-[0_5px_15px_rgba(37,99,235,0.3)]' : 'text-slate-400 hover:text-white hover:bg-white/5'}`}
                      >
                        ڕەوتی ئاسایی (Workflow)
                      </button>
                      <button
                        type="button"
                        onClick={() => { setIsDirectRequest(true); setTargetId(''); setTargetDeptId(''); }}
                        className={`flex-1 py-2 rounded-lg text-sm font-bold transition-all ${isDirectRequest ? 'bg-gradient-to-r from-purple-600 to-purple-500 text-white shadow-[0_5px_15px_rgba(147,51,234,0.3)]' : 'text-slate-400 hover:text-white hover:bg-white/5'}`}
                      >
                        داواکاری تایبەت (Direct)
                      </button>
                    </div>
                  </div>

                  {!isDirectRequest && (
                    <div>
                      <label className="block text-sm font-bold text-slate-300 mb-2">ڕەوتی کار (Workflow Template)</label>
                      <select
                        value={workflowTemplateId}
                        onChange={e => setWorkflowTemplateId(e.target.value)}
                        className="w-full px-4 py-3 rounded-xl bg-slate-900 border border-white/10 focus:border-purple-500 outline-none text-white"
                      >
                        <option value="" className="bg-slate-900">ڕەوتی کاری ئاسایی...</option>
                        {workflowTemplates.map(template => (
                          <option key={template.id} value={template.id} className="bg-slate-900">
                            {template.name}
                          </option>
                        ))}
                      </select>
                    </div>
                  )}

                  <div>
                    <label className="block text-sm font-bold text-slate-300 mb-2">ناردن بۆ</label>
                    <div className="space-y-3">
                        {!isDirectRequest && (
                          <select
                            value={targetDeptId}
                            onChange={e => {
                              setTargetDeptId(e.target.value);
                              setTargetId('');
                            }}
                            className="w-full px-4 py-3 rounded-xl bg-slate-900 border border-white/10 focus:border-purple-500 outline-none text-white"
                          >
                            <option value="" className="bg-slate-900">هەڵبژاردنی بەش / ژوور...</option>
                            {departments.map(dept => (
                              <option key={dept.id} value={dept.id} className="bg-slate-900">
                                {dept.name}
                              </option>
                            ))}
                          </select>
                        )}

                        <select
                          value={targetId}
                          onChange={e => setTargetId(e.target.value)}
                          className="w-full px-4 py-3 rounded-xl bg-slate-900 border border-white/10 focus:border-purple-500 outline-none text-white"
                          required
                          disabled={!isDirectRequest && !targetDeptId}
                        >
                          <option value="" className="bg-slate-900">هەڵبژاردنی وەرگر...</option>
                          {isDirectRequest ? (
                            users.filter(u => u.id !== currentUser?.id).map(user => (
                              <option key={user.id} value={user.id} className="bg-slate-900">
                                {user.title} - {user.name} ({user.role})
                              </option>
                            ))
                          ) : (
                            users.filter(u => u.department === targetDeptId && u.id !== currentUser?.id).map(user => (
                              <option key={user.id} value={user.id} className="bg-slate-900">
                                {user.title} - {user.name}
                              </option>
                            ))
                          )}
                        </select>
                    </div>
                  </div>
                </div>

                <div className="flex items-center gap-3 bg-white/5 p-4 rounded-xl border border-white/10 hover:border-purple-500/30 transition-colors cursor-pointer" onClick={() => setAttachSignature(!attachSignature)}>
                  <div className={`w-6 h-6 rounded-lg border-2 flex items-center justify-center transition-colors ${attachSignature ? 'bg-purple-500 border-purple-500 shadow-[0_0_10px_rgba(168,85,247,0.4)]' : 'border-slate-500'}`}>
                    {attachSignature && <CheckCircle2 size={16} className="text-white" />}
                  </div>
                  <div className="flex-1">
                    <span className="text-sm font-bold text-white block">واژۆی ئەلیکترۆنی</span>
                    <span className="text-xs text-slate-400">زیادکردنی واژۆی فەرمی خۆت بۆ ئەم داواکارییە</span>
                  </div>
                  <PenTool className={attachSignature ? 'text-purple-400' : 'text-slate-600'} />
                </div>

                <div className="bg-white/5 p-6 rounded-2xl border border-white/10 space-y-4">
                  <label className="block text-sm font-bold text-slate-300 mb-2">کاتی پێویست بۆ جێبەجێکردن (ئارەزوومەندانە)</label>
                  <div className="flex gap-4">
                    <div className="flex-1">
                      <label className="block text-xs text-slate-400 mb-1">ڕۆژ</label>
                      <input
                        type="number"
                        min="0"
                        value={deadlineDays}
                        onChange={e => setDeadlineDays(parseInt(e.target.value) || 0)}
                        className="w-full px-4 py-3 rounded-xl bg-slate-900 border border-white/10 focus:border-purple-500 outline-none text-white"
                        placeholder="0"
                      />
                    </div>
                    <div className="flex-1">
                      <label className="block text-xs text-slate-400 mb-1">کاتژمێر</label>
                      <input
                        type="number"
                        min="0"
                        max="23"
                        value={deadlineHours}
                        onChange={e => setDeadlineHours(parseInt(e.target.value) || 0)}
                        className="w-full px-4 py-3 rounded-xl bg-slate-900 border border-white/10 focus:border-purple-500 outline-none text-white"
                        placeholder="0"
                      />
                    </div>
                  </div>
                </div>

                <div>
                  <label className="block text-sm font-bold text-slate-300 mb-2">هاوپێچەکان</label>
                  <input type="file" onChange={handleFileChange} multiple className="block w-full text-sm text-slate-500 file:mr-4 file:py-2 file:px-4 file:rounded-full file:border-0 file:text-sm file:font-semibold file:bg-purple-50 file:text-purple-700 hover:file:bg-purple-100" />
                </div>

                <div className="flex justify-end pt-4">
                  <button
                    type="submit"
                    disabled={loading}
                    className="bg-gradient-to-r from-purple-600 to-purple-500 hover:from-purple-500 hover:to-purple-400 text-white px-8 py-3 rounded-xl font-bold transition-all shadow-[0_10px_20px_rgba(147,51,234,0.3)] hover:shadow-[0_15px_30px_rgba(147,51,234,0.4)] hover:-translate-y-1 flex items-center gap-2 border border-white/10"
                  >
                    {loading ? '...ناردن' : (
                      <>
                        <Send size={20} />
                        ناردنی داواکاری
                      </>
                    )}
                  </button>
                </div>
              </form>
            </div>
          </div>
        </div>
      )}
    </div>
  );
};

import { WorkflowTimeline } from './WorkflowTimeline';

export const DocumentDetail: React.FC<{ doc: Document; onBack: () => void }> = ({ doc, onBack }) => {
  const { currentUser, updateDocument, users, uploadFiles, workflowTemplates, departments } = useApp();
  const [note, setNote] = useState('');
  const [selectedTarget, setSelectedTarget] = useState('');
  const [action, setAction] = useState<'forward' | 'approve' | 'reject' | 'return' | 'edit' | null>(null);
  const [selectedFiles, setSelectedFiles] = useState<File[]>([]);
  const [showHandDelivery, setShowHandDelivery] = useState(false);
  const [showRejectModal, setShowRejectModal] = useState(false);
  const [rejectReason, setRejectReason] = useState('');
  const [showCommentModal, setShowCommentModal] = useState(false);
  const [commentText, setCommentText] = useState('');
  const [loading, setLoading] = useState(false);
  const [previewFile, setPreviewFile] = useState<Attachment | null>(null);

  const template = doc.workflowTemplateId ? workflowTemplates.find(t => t.id === doc.workflowTemplateId) : null;
  const nextStep = template && doc.currentStepIndex < template.steps.length - 1 
    ? template.steps[doc.currentStepIndex + 1] 
    : null;

  const handlePrint = () => {
    window.print();
  };

  const submitComment = async () => {
    if (!commentText) return;
    setLoading(true);
    try {
      await updateDocument(doc.id, { 
        history: [...doc.history, { 
          action: 'comment', 
          fromUser: currentUser?.name, 
          toUser: 'All',
          timestamp: new Date().toISOString(), 
          note: commentText,
          metadata: { department: currentUser?.department }
        }] 
      });
      setShowCommentModal(false);
      setCommentText('');
    } catch (error) {
      console.error(error);
    } finally {
      setLoading(false);
    }
  };

  const handlePrintAttachment = (url: string, type: string) => {
    // Always open in new tab for viewing
    window.open(url, '_blank');
  };

  // Edit State
  const [editTitle, setEditTitle] = useState(doc.title);
  const [editContent, setEditContent] = useState(doc.content);

  // Determine available actions based on role and status
  // Simplified logic for now
  const canForward = true;
  const canApprove = true;
  const canReject = true;
  const canReturn = true;
  
  // Edit permission: Current holder can edit
  const canEdit = doc.currentHolderId === currentUser?.id;
  
  // Hand delivery is available for everyone who holds the document
  const canHandDeliver = doc.currentHolderId === currentUser?.id;

  // Strict Workflow Routing Logic
  // Dispatch -> Dept Head -> Unit Head -> Employee -> Unit Head -> Dept Head -> Deputy -> Director -> Print -> Archive
  
  const getNextStage = (currentStage: string): string | null => {
    switch (currentStage) {
      case 'DISPATCH': return 'DEPT_HEAD_IN';
      case 'DEPT_HEAD_IN': return 'UNIT_HEAD_IN';
      case 'UNIT_HEAD_IN': return 'EMPLOYEE_ACTION';
      case 'EMPLOYEE_ACTION': return 'UNIT_HEAD_OUT';
      case 'UNIT_HEAD_OUT': return 'DEPT_HEAD_OUT';
      case 'DEPT_HEAD_OUT': return 'DEPUTY_REVIEW';
      case 'DEPUTY_REVIEW': return 'DIRECTOR_REVIEW'; // Or PRINT_ROOM
      case 'DIRECTOR_REVIEW': return 'PRINT_ROOM';
      case 'PRINT_ROOM': return 'ARCHIVED';
      default: return null;
    }
  };

  const getPreviousStages = (currentStage: string): string[] => {
    if (template) {
      return template.steps
        .slice(0, doc.currentStepIndex)
        .map(s => s.label)
        .reverse();
    }
    const stages = [
      'DISPATCH', 'DEPT_HEAD_IN', 'UNIT_HEAD_IN', 'EMPLOYEE_ACTION', 
      'UNIT_HEAD_OUT', 'DEPT_HEAD_OUT', 'DEPUTY_REVIEW', 'DIRECTOR_REVIEW', 'PRINT_ROOM'
    ];
    const currentIndex = stages.indexOf(currentStage);
    if (currentIndex <= 0) return [];
    return stages.slice(0, currentIndex).reverse();
  };

  // Filter targets based on strict workflow
  const availableTargets = users.filter(u => {
    if (u.id === currentUser?.id) return false;

    // If we have a template, filter by the next step's role and optionally department
    if (nextStep) {
      const roleMatch = u.role === nextStep.role;
      const deptMatch = nextStep.departmentId ? u.department === nextStep.departmentId : true;
      return roleMatch && deptMatch;
    }

    const nextStage = getNextStage(doc.workflowStage);
    if (!nextStage) return false;

    // Strict Role-based filtering
    const roleMap: Record<string, string> = {
      'DEPT_HEAD_IN': 'section_director',
      'DEPT_HEAD_OUT': 'section_director',
      'UNIT_HEAD_IN': 'unit_head',
      'UNIT_HEAD_OUT': 'unit_head',
      'EMPLOYEE_ACTION': 'employee',
      'DEPUTY_REVIEW': 'deputy_director',
      'DIRECTOR_REVIEW': 'director_general',
      'PRINT_ROOM': 'print_staff'
    };

    const requiredRole = roleMap[nextStage];
    if (requiredRole) {
      return u.role === requiredRole;
    }
    
    return true; // Fallback to all users if stage not mapped
  });

  const [showForwardModal, setShowForwardModal] = useState(false);
  const [manualRouting, setManualRouting] = useState(false);
  const [selectedDept, setSelectedDept] = useState('');
  const [showReturnModal, setShowReturnModal] = useState(false);
  const [returnTargetId, setReturnTargetId] = useState('');
  const [returnReason, setReturnReason] = useState('');

  const handleForward = () => {
    setShowForwardModal(true);
  };

  const handleReturn = () => {
    setShowReturnModal(true);
  };

  const submitForward = async () => {
    if (!selectedTarget) return;
    setLoading(true);
    try {
      const uploadedAttachments = await uploadFiles(selectedFiles);
      const nextStage = getNextStage(doc.workflowStage) || doc.workflowStage;
      
      const updates: any = { 
        currentHolderId: selectedTarget, 
        status: 'Pending', 
        history: [...doc.history, { 
          action: manualRouting ? 'manual_forward' : 'forward', 
          fromUser: currentUser?.name, 
          toUser: users.find(u => u.id === selectedTarget)?.name, 
          timestamp: new Date().toISOString(), 
          note: manualRouting ? `(Manual) ${note}` : note 
        }],
        attachments: [...doc.attachments, ...uploadedAttachments]
      };

      if (manualRouting) {
        const targetUser = users.find(u => u.id === selectedTarget);
        if (targetUser) {
          if (targetUser.role === 'section_director') updates.workflowStage = 'DEPT_HEAD_IN';
          else if (targetUser.role === 'unit_head') updates.workflowStage = 'UNIT_HEAD_IN';
          else if (targetUser.role === 'employee') updates.workflowStage = 'EMPLOYEE_ACTION';
          else if (targetUser.role === 'deputy_director') updates.workflowStage = 'DEPUTY_REVIEW';
          else if (targetUser.role === 'director_general') updates.workflowStage = 'DIRECTOR_REVIEW';
          else if (targetUser.role === 'dispatch_staff') updates.workflowStage = 'DISPATCH';
          else if (targetUser.role === 'print_staff') updates.workflowStage = 'PRINT_ROOM';
        }
        updates.workflowTemplateId = null; // Break template if manual
      } else if (template) {
        updates.currentStepIndex = doc.currentStepIndex + 1;
      } else {
        updates.workflowStage = nextStage as any;
      }
      
      await updateDocument(doc.id, updates);
      setShowForwardModal(false);
      onBack();
    } catch (error) {
      console.error(error);
    } finally {
      setLoading(false);
    }
  };

  const submitReturn = async () => {
    if (!returnTargetId || !returnReason) return;
    setLoading(true);
    try {
      const targetUser = users.find(u => u.id === returnTargetId);
      let newStage = doc.workflowStage;
      
      // Attempt to determine stage based on target role
      if (targetUser) {
          if (targetUser.role === 'section_director') newStage = 'DEPT_HEAD_IN';
          else if (targetUser.role === 'unit_head') newStage = 'UNIT_HEAD_IN';
          else if (targetUser.role === 'employee') newStage = 'EMPLOYEE_ACTION';
          else if (targetUser.role === 'deputy_director') newStage = 'DEPUTY_REVIEW';
          else if (targetUser.role === 'director_general') newStage = 'DIRECTOR_REVIEW';
          else if (targetUser.role === 'dispatch_staff') newStage = 'DISPATCH';
          else if (targetUser.role === 'print_staff') newStage = 'PRINT_ROOM';
      }

      const updates: any = { 
        currentHolderId: returnTargetId,
        workflowStage: newStage,
        status: 'Returned', 
        history: [...doc.history, { 
            action: 'return', 
            fromUser: currentUser?.name, 
            toUser: targetUser?.name, 
            timestamp: new Date().toISOString(), 
            note: returnReason 
        }] 
      };

      await updateDocument(doc.id, updates);
      setShowReturnModal(false);
      onBack();
    } catch (error) {
      console.error(error);
    } finally {
      setLoading(false);
    }
  };

  const submitReject = async () => {
    if (!rejectReason) return;
    setLoading(true);
    try {
      await updateDocument(doc.id, { 
        status: 'Rejected', 
        history: [...doc.history, { action: 'reject', fromUser: currentUser?.name, timestamp: new Date().toISOString(), note: rejectReason }] 
      });
      setShowRejectModal(false);
      onBack();
    } catch (error) {
      console.error(error);
    } finally {
      setLoading(false);
    }
  };

  const handleFileChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    if (e.target.files && e.target.files.length > 0) {
      setSelectedFiles(prev => [...prev, ...Array.from(e.target.files!)]);
    }
  };

  const removeFile = (index: number) => {
    setSelectedFiles(prev => prev.filter((_, i) => i !== index));
  };

  const handleApprove = async () => {
    setLoading(true);
    try {
      // Logic: If management (Director/Deputy) approves, it goes to Print Room
      const isManagement = currentUser?.role === 'director_general' || currentUser?.role === 'deputy_director';
      const nextStage = isManagement ? 'PRINT_ROOM' : doc.workflowStage;
      const nextStatus = isManagement ? 'Approved' : 'Under Review';

      await updateDocument(doc.id, { 
        status: nextStatus,
        workflowStage: nextStage,
        history: [...doc.history, { 
          action: 'approve', 
          fromUser: currentUser?.name, 
          timestamp: new Date().toISOString(), 
          note: isManagement ? 'پەسەندکرا و ناردرا بۆ ژووری پڕێنت' : 'پەسەندکرا بۆ قۆناغی داهاتوو' 
        }] 
      });
      onBack();
    } catch (error) {
      console.error(error);
    } finally {
      setLoading(false);
    }
  };

  const handleEdit = async () => {
    setLoading(true);
    try {
      await updateDocument(doc.id, { title: editTitle, content: editContent });
      setAction(null);
    } catch (error) {
      console.error('Edit failed', error);
    } finally {
      setLoading(false);
    }
  };

  const handlePrintAndArchive = async () => {
    setLoading(true);
    try {
      await updateDocument(doc.id, { 
        status: 'Archived',
        workflowStage: 'ARCHIVED',
        history: [...doc.history, { 
          action: 'archive', 
          fromUser: currentUser?.name, 
          timestamp: new Date().toISOString(), 
          note: 'نوسراوەکە چاپکرا و ئەرشیفکرا' 
        }] 
      });
      // Trigger actual print
      printJS({
        printable: 'document-content',
        type: 'html',
        targetStyles: ['*']
      });
      onBack();
    } catch (error) {
      console.error(error);
    } finally {
      setLoading(false);
    }
  };

  const isPrintStaff = currentUser?.role === 'print_staff';
  const isManagement = currentUser?.role === 'director_general' || currentUser?.role === 'deputy_director';
  const isInPrintRoom = doc.workflowStage === 'PRINT_ROOM';
  const isArchived = doc.status === 'Archived';

  const handleAddAttachment = async (e: React.ChangeEvent<HTMLInputElement>) => {
    if (e.target.files && e.target.files.length > 0) {
      setLoading(true);
      try {
        const newFiles = Array.from(e.target.files);
        const uploadedAttachments = await uploadFiles(newFiles);
        
        await updateDocument(doc.id, {
          attachments: [...doc.attachments, ...uploadedAttachments],
          history: [...doc.history, {
            action: 'edit',
            fromUser: currentUser?.name,
            timestamp: new Date().toISOString(),
            note: 'هاوپێچی نوێ زیادکرا'
          }]
        });
      } catch (error) {
        console.error('Failed to add attachment', error);
      } finally {
        setLoading(false);
      }
    }
  };

  const handleStageClick = async (stage: { id: string, label: string }, index: number, isFuture: boolean, isPast: boolean) => {
    if (isArchived) return;
    
    const isForward = isFuture;
    const actionText = isForward ? 'ناردن' : 'گەڕاندنەوە';
    const confirmMessage = isForward 
      ? `ئایا دڵنیایت دەتەوێت نوسراوەکە بنێریت بۆ (${stage.label})؟`
      : `ئایا دڵنیایت دەتەوێت نوسراوەکە بگەڕێنیتەوە بۆ (${stage.label})؟`;
    
    if (window.confirm(confirmMessage)) {
      setLoading(true);
      try {
        // Find a user in the target stage/department to set as currentHolderId
        // This is a simplified approach. In a real app, you might want to open a modal to select the specific user.
        // For now, we just update the workflowStage and currentStepIndex.
        
        let updates: any = {
          workflowStage: stage.id,
          status: 'Pending',
          history: [...doc.history, {
            action: isForward ? 'forward' : 'return',
            fromUser: currentUser?.name,
            timestamp: new Date().toISOString(),
            note: `${isForward ? 'نێردرا' : 'گەڕێندرایەوە'} بۆ ${stage.label} لە ڕێگەی ڕەوتی کارەوە`
          }]
        };

        if (template) {
           updates.currentStepIndex = index;
           // Attempt to find the target role/department from the template step
           const step = template.steps[index];
           if (step) {
               const targetUser = users.find(u => u.role === step.role && (!step.department || u.department === step.department));
               if (targetUser) {
                   updates.currentHolderId = targetUser.id;
               }
           }
        } else {
           // Fallback for default stages
           const roleMap: Record<string, string> = {
               'DISPATCH': 'dispatch_staff',
               'DEPT_HEAD_IN': 'section_director',
               'UNIT_HEAD_IN': 'unit_head',
               'EMPLOYEE_ACTION': 'employee',
               'UNIT_HEAD_OUT': 'unit_head',
               'DEPT_HEAD_OUT': 'section_director',
               'DEPUTY_REVIEW': 'deputy_director',
               'DIRECTOR_REVIEW': 'director_general',
               'PRINT_ROOM': 'print_staff'
           };
           const targetRole = roleMap[stage.id];
           if (targetRole) {
               const targetUser = users.find(u => u.role === targetRole && (targetRole === 'director_general' || targetRole === 'deputy_director' || targetRole === 'dispatch_staff' || targetRole === 'print_staff' || u.department === doc.senderDepartment));
               if (targetUser) {
                   updates.currentHolderId = targetUser.id;
               }
           }
        }

        await updateDocument(doc.id, updates);
        onBack();
      } catch (error) {
        console.error(error);
      } finally {
        setLoading(false);
      }
    }
  };

  return (
    <div className="glass-panel rounded-2xl shadow-2xl border border-white/10 overflow-hidden" dir="rtl">
      {/* Workflow Timeline */}
      <div className="bg-black/40 border-b border-white/10 p-6 backdrop-blur-xl">
        <div className="flex items-center justify-between mb-4">
          <h3 className="text-sm font-bold text-slate-400 flex items-center gap-2">
            <Activity size={16} className="text-blue-400" />
            ڕەوتی کار {template && <span className="text-purple-400">({template.name})</span>}
          </h3>
          <div className="flex items-center gap-2 px-3 py-1 bg-blue-500/10 border border-blue-500/20 rounded-full">
            <div className="w-2 h-2 rounded-full bg-blue-500 animate-pulse shadow-[0_0_8px_rgba(59,130,246,0.8)]" />
            <span className="text-[10px] font-black text-blue-400 uppercase tracking-widest">
              شوێنی ئێستا: {nextStep ? nextStep.label : doc.workflowStage}
            </span>
          </div>
        </div>
        <WorkflowTimeline doc={doc} onStageClick={handleStageClick} />
      </div>

      <div className="p-6 border-b border-white/10 flex justify-between items-start bg-white/5 backdrop-blur-md">
        {/* ... existing header content ... */}

        <div className="flex-1">
          {/* Incoming Info Badge */}
          {(doc.incomingNumber || doc.source) && (
             <div className="flex items-center gap-4 mb-4 bg-blue-500/5 border border-blue-500/10 p-3 rounded-xl w-fit">
               {doc.source && (
                 <div className="flex items-center gap-2 text-sm text-slate-300">
                   <Building2 size={16} className="text-blue-400" />
                   <span className="font-bold text-blue-200">سەرچاوە:</span>
                   <span>{doc.source}</span>
                 </div>
               )}
               {doc.incomingNumber && (
                 <div className="flex items-center gap-2 text-sm text-slate-300 border-r border-white/10 pr-4 mr-4">
                   <FileText size={16} className="text-blue-400" />
                   <span className="font-bold text-blue-200">ژمارەی هاتوو:</span>
                   <span className="font-mono">{doc.incomingNumber}</span>
                 </div>
               )}
               {doc.incomingDate && (
                 <div className="flex items-center gap-2 text-sm text-slate-300 border-r border-white/10 pr-4 mr-4">
                   <Calendar size={16} className="text-blue-400" />
                   <span className="font-bold text-blue-200">بەرواری هاتوو:</span>
                   <span className="font-mono">{doc.incomingDate}</span>
                 </div>
               )}
             </div>
          )}

          <div className="flex items-center gap-3 mb-2">
            {action === 'edit' ? (
               <input 
                 value={editTitle}
                 onChange={e => setEditTitle(e.target.value)}
                 className="text-2xl font-bold text-white bg-transparent border-b-2 border-blue-500 outline-none neon-text"
               />
            ) : (
               <h2 className="text-2xl font-bold text-white neon-text">{doc.title}</h2>
            )}
            {doc.isCircular && (
              <span className="bg-purple-500/10 text-purple-400 px-2 py-1 rounded text-xs font-bold border border-purple-500/20 shadow-[0_0_10px_rgba(168,85,247,0.2)]">
                گشتاندن
              </span>
            )}
            <span className="bg-white/10 text-blue-300 px-2 py-1 rounded text-xs font-mono border border-white/10">
              {doc.referenceNumber}
            </span>
          </div>
          <div className="flex items-center gap-4 text-sm text-slate-400">
            <span className="flex items-center gap-1">
              <Clock size={14} />
              {new Date(doc.createdAt).toLocaleDateString('en-US')}
            </span>
            <span className={`px-2 py-0.5 rounded-full text-xs font-medium border ${
              doc.status === 'Approved' ? 'bg-emerald-500/10 text-emerald-400 border-emerald-500/20' :
              doc.status === 'Rejected' ? 'bg-red-500/10 text-red-400 border-red-500/20' :
              doc.status === 'Archived' ? 'bg-purple-500/10 text-purple-400 border-purple-500/20' :
              'bg-blue-500/10 text-blue-400 border-blue-500/20'
            }`}>
              {doc.status === 'Approved' ? 'پەسەندکراو' : 
               doc.status === 'Rejected' ? 'ڕەتکراوە' :
               doc.status === 'Archived' ? 'ئەرشیفکراو' :
               doc.status === 'Under Review' ? 'لەژێر پێداچوونەوە' :
               'چاوەڕوان'}
            </span>
          </div>
        </div>
        <div className="flex items-center gap-3 print:hidden">
          {!isArchived && (
            <>
              {/* Reply Button */}
              <button 
                onClick={() => {
                  const commentSection = document.getElementById('comment-section');
                  commentSection?.scrollIntoView({ behavior: 'smooth' });
                }}
                className="flex items-center gap-2 px-4 py-2 bg-purple-600/20 border border-purple-500/30 text-purple-400 rounded-xl font-bold hover:bg-purple-600 hover:text-white transition-all shadow-lg shadow-purple-500/5"
              >
                <MessageSquare size={18} />
                وەڵامدانەوە
              </button>

              {/* Print & Archive for Print Staff */}
              {isPrintStaff && isInPrintRoom && (
                <button 
                  onClick={handlePrintAndArchive}
                  className="flex items-center gap-2 px-6 py-2 bg-emerald-600 text-white rounded-xl font-bold hover:bg-emerald-500 transition-all shadow-lg shadow-emerald-600/20 animate-pulse"
                >
                  <Printer size={18} />
                  چاپ و ئەرشیف
                </button>
              )}

              {/* Management Approval */}
              {isManagement && doc.status !== 'Approved' && (
                <button 
                  onClick={handleApprove}
                  className="flex items-center gap-2 px-6 py-2 bg-blue-600 text-white rounded-xl font-bold hover:bg-blue-500 transition-all shadow-lg shadow-blue-600/20"
                >
                  <CheckCircle2 size={18} />
                  پەسەندکردن و ناردن بۆ چاپ
                </button>
              )}
            </>
          )}

          <div className="w-px h-8 bg-white/10 mx-2" />
          
          <button onClick={handlePrint} className="p-2 hover:bg-white/10 rounded-full text-slate-400 hover:text-white transition-colors" title="Print Document">
            <Printer size={20} />
          </button>
          <div className="bg-white p-2 rounded-lg border border-white/10 shadow-sm">
            <QRCode value={doc.referenceNumber} size={48} />
          </div>
          <button onClick={onBack} className="p-2 hover:bg-white/10 rounded-full text-slate-400 hover:text-white transition-colors">
            <ArrowLeft size={20} />
          </button>
        </div>
      </div>

      <div className="p-8 space-y-8">
        {/* Registration Metadata Grid */}
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-4 bg-white/5 p-6 rounded-3xl border border-white/10 shadow-inner relative overflow-hidden">
          <div className="absolute inset-0 bg-blue-500/5 pointer-events-none" />
          <div className="space-y-1 relative z-10">
            <p className="text-[10px] font-black text-slate-500 uppercase tracking-widest flex items-center gap-1">
              <Layers size={10} />
              ژمارەی هاتوو (Incoming No)
            </p>
            <p className="text-sm font-bold text-blue-400 font-mono">{doc.incomingNumber || '---'}</p>
          </div>
          <div className="space-y-1 relative z-10">
            <p className="text-[10px] font-black text-slate-500 uppercase tracking-widest flex items-center gap-1">
              <Clock size={10} />
              بەرواری هاتوو (Incoming Date)
            </p>
            <p className="text-sm font-bold text-blue-400">{doc.incomingDate || '---'}</p>
          </div>
          <div className="space-y-1 relative z-10">
            <p className="text-[10px] font-black text-slate-500 uppercase tracking-widest flex items-center gap-1">
              <Building2 size={10} />
              سەرچاوە (Source)
            </p>
            <p className="text-sm font-bold text-blue-400">{doc.source || '---'}</p>
          </div>
          <div className="space-y-1 relative z-10">
            <p className="text-[10px] font-black text-slate-500 uppercase tracking-widest flex items-center gap-1">
              <Paperclip size={10} />
              نوسراوی پەیوەندیدار (Related)
            </p>
            <p className="text-sm font-bold text-blue-400">{(doc.relatedDocIds && doc.relatedDocIds.length > 0) ? doc.relatedDocIds.join(', ') : '---'}</p>
          </div>
        </div>

        <div className="bg-white/5 p-8 rounded-3xl border border-white/10 shadow-xl relative overflow-hidden">
          <div className="absolute top-0 right-0 w-32 h-32 bg-blue-500/5 blur-[60px] rounded-full" />
          <h4 className="text-xs font-black text-slate-500 uppercase tracking-widest mb-4 flex items-center gap-2">
            <FileText size={14} className="text-blue-400" />
            ناوەڕۆکی نوسراو
          </h4>
          {action === 'edit' ? (
            <textarea
              value={editContent}
              onChange={e => setEditContent(e.target.value)}
              className="w-full h-96 p-6 bg-black/40 border border-white/10 rounded-2xl focus:border-blue-500/50 outline-none resize-none text-slate-200 font-medium leading-relaxed"
            />
          ) : (
            <div className="prose max-w-none text-slate-200 leading-relaxed whitespace-pre-wrap text-lg font-medium">
              {doc.content}
            </div>
          )}
        </div>

        {/* Participants Section */}
        <div className="bg-white/5 p-6 rounded-3xl border border-white/10 shadow-inner">
          <h4 className="text-[10px] font-black text-slate-500 uppercase tracking-widest mb-4 flex items-center gap-2">
            <UserCheck size={12} className="text-blue-400" />
            بەشداربووانی ئەم نوسراوە
          </h4>
          <div className="flex flex-wrap gap-3">
            {doc.participants?.map(pId => {
              const user = users.find(u => u.id === pId);
              const dept = departments.find(d => d.id === pId);
              if (!user && !dept) return null;
              return (
                <div key={pId} className="flex items-center gap-2 bg-white/5 px-3 py-1.5 rounded-xl border border-white/10">
                  <div className={`w-6 h-6 rounded-lg flex items-center justify-center text-[10px] font-bold ${user ? 'bg-blue-500/20 text-blue-400' : 'bg-purple-500/20 text-purple-400'}`}>
                    {user ? <UserCheck size={12} /> : <Building2 size={12} />}
                  </div>
                  <span className="text-xs font-bold text-slate-300">{user?.name || dept?.name}</span>
                </div>
              );
            })}
          </div>
        </div>

        {/* Attachments Display */}
        <div className="mt-8 pt-6 border-t border-white/10 relative">
          <div className="flex items-center justify-between mb-4">
            <h4 className="text-sm font-bold text-slate-300 flex items-center gap-2">
              <Paperclip size={16} />
              هاوپێچەکان
            </h4>
            
            <label className="cursor-pointer bg-blue-600 hover:bg-blue-500 text-white px-4 py-2 rounded-xl text-xs font-bold transition-all shadow-lg shadow-blue-600/20 flex items-center gap-2">
              <Plus size={14} />
              زیادکردنی هاوپێچ
              <input type="file" multiple accept=".pdf,.doc,.docx,.xls,.xlsx,image/*" className="hidden" onChange={handleAddAttachment} />
            </label>
          </div>

          {doc.attachments.length === 0 ? (
            <p className="text-slate-500 text-sm italic text-center py-8 border-2 border-dashed border-white/10 rounded-xl">
              هیچ هاوپێچێک نییە
            </p>
          ) : (
            <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-4 mb-6">
              {doc.attachments.map(att => (
                <div 
                  key={att.id} 
                  className="relative group"
                  onMouseEnter={() => setPreviewFile(att)}
                  onMouseLeave={() => setPreviewFile(null)}
                >
                  <div 
                    className="flex items-center justify-between p-4 rounded-2xl border border-white/10 bg-white/5 hover:bg-white/10 hover:border-blue-500/50 transition-all duration-300 cursor-pointer shadow-sm hover:shadow-lg hover:-translate-y-1" 
                    onClick={() => {
                      const a = document.createElement('a');
                      a.href = att.url;
                      a.download = att.name;
                      document.body.appendChild(a);
                      a.click();
                      document.body.removeChild(a);
                    }}
                  >
                    <div className="flex items-center gap-4">
                      <div className={`w-12 h-12 rounded-xl flex items-center justify-center shadow-lg transition-transform group-hover:scale-110 ${
                        att.type === 'pdf' ? 'bg-red-500/20 text-red-400 shadow-red-500/10' :
                        att.type === 'word' ? 'bg-blue-500/20 text-blue-400 shadow-blue-500/10' :
                        att.type === 'excel' ? 'bg-green-500/20 text-green-400 shadow-green-500/10' :
                        'bg-slate-500/20 text-slate-400 shadow-slate-500/10'
                      }`}>
                        {att.type === 'image' ? (
                          <img src={att.url} alt="" className="w-full h-full object-cover rounded-xl" />
                        ) : (
                          <FileText size={24} />
                        )}
                      </div>
                      <div className="overflow-hidden">
                        <p className="font-bold text-sm text-slate-200 truncate max-w-[150px] group-hover:text-blue-400 transition-colors">{att.name}</p>
                        <div className="flex items-center gap-2 text-[10px] text-slate-500 mt-1">
                          <span className="uppercase font-mono bg-white/5 px-1.5 py-0.5 rounded">{att.type}</span>
                          {att.uploadedBy && <span>by {att.uploadedBy}</span>}
                        </div>
                      </div>
                    </div>
                    
                    <button 
                      onClick={(e) => {
                        e.stopPropagation();
                        const a = document.createElement('a');
                        a.href = att.url;
                        a.download = att.name;
                        document.body.appendChild(a);
                        a.click();
                        document.body.removeChild(a);
                      }}
                      className="p-2 rounded-full bg-white/5 text-slate-400 hover:bg-blue-500 hover:text-white transition-all opacity-0 group-hover:opacity-100 transform translate-x-2 group-hover:translate-x-0 hover:shadow-[0_0_15px_rgba(59,130,246,0.4)] cursor-pointer"
                      title="Download"
                    >
                      <Download size={18} />
                    </button>
                  </div>

                  {/* Hover Preview Card */}
                  {previewFile?.id === att.id && (
                    <div className="absolute bottom-full left-1/2 -translate-x-1/2 pb-4 w-80 z-50 animate-in zoom-in-95 duration-200 pointer-events-none">
                      <div className="glass-panel p-2 rounded-2xl bg-slate-900/95 backdrop-blur-xl border border-white/20 shadow-2xl overflow-hidden pointer-events-auto">
                        {/* Preview Content */}
                        <div className="relative w-full h-48 bg-black/50 rounded-xl overflow-hidden mb-3 flex items-center justify-center border border-white/5">
                          {att.type === 'image' ? (
                            <img src={att.url} alt="Preview" className="w-full h-full object-cover" />
                          ) : att.type === 'pdf' ? (
                            <div className="w-full h-full relative group-hover:scale-105 transition-transform">
                              <iframe src={`${att.url}#toolbar=0&navpanes=0&scrollbar=0`} className="w-full h-full pointer-events-none opacity-80" title="PDF Preview" />
                              <div className="absolute inset-0 bg-gradient-to-t from-slate-900 via-transparent to-transparent" />
                            </div>
                          ) : (
                            <div className={`w-20 h-20 rounded-2xl flex items-center justify-center ${
                              att.type === 'word' ? 'bg-blue-500/20 text-blue-400' :
                              att.type === 'excel' ? 'bg-green-500/20 text-green-400' :
                              'bg-slate-500/20 text-slate-400'
                            }`}>
                              <FileText size={40} />
                            </div>
                          )}
                          
                          {/* Overlay Info */}
                          <div className="absolute bottom-0 left-0 right-0 p-3 bg-gradient-to-t from-black/90 to-transparent">
                            <p className="text-xs text-slate-300 font-mono text-center">کلیک بکە بۆ بینینی قەبارەی تەواو</p>
                          </div>
                        </div>

                        {/* Actions */}
                        <div className="flex gap-2 px-1 pb-1">
                          <button 
                            onClick={(e) => {
                              e.stopPropagation();
                              const a = document.createElement('a');
                              a.href = att.url;
                              a.download = att.name;
                              document.body.appendChild(a);
                              a.click();
                              document.body.removeChild(a);
                            }}
                            className="flex-1 bg-gradient-to-r from-blue-600 to-blue-500 hover:from-blue-500 hover:to-blue-400 text-white text-xs font-bold py-2 rounded-lg flex items-center justify-center gap-2 transition-all hover:shadow-[0_5px_15px_rgba(37,99,235,0.3)] cursor-pointer"
                          >
                            <FileText size={14} />
                            کردنەوە
                          </button>
                          <button 
                            onClick={(e) => {
                              e.stopPropagation();
                              const a = document.createElement('a');
                              a.href = att.url;
                              a.download = att.name;
                              document.body.appendChild(a);
                              a.click();
                              document.body.removeChild(a);
                            }}
                            className="flex-1 bg-white/10 hover:bg-white/20 text-white text-xs font-bold py-2 rounded-lg flex items-center justify-center gap-2 transition-all hover:shadow-[0_5px_15px_rgba(255,255,255,0.1)] cursor-pointer"
                          >
                            <Download size={14} />
                            داگرتن
                          </button>
                        </div>
                      </div>
                      {/* Arrow */}
                      <div className="w-4 h-4 bg-slate-900 border-r border-b border-white/20 transform rotate-45 absolute bottom-2 left-1/2 -translate-x-1/2"></div>
                    </div>
                  )}
                </div>
              ))}
            </div>
          )}
        </div>
      </div>

      <div className="bg-white/5 p-6 border-t border-white/10 backdrop-blur-sm">
        <h3 className="text-sm font-bold text-slate-300 uppercase tracking-wider mb-6 flex items-center gap-2">
          <Clock size={16} />
          مێژووی نوسراو و تێبینییەکان
        </h3>
        <div className="space-y-8 relative" id="comment-section">
          <div className="absolute left-8 top-0 bottom-0 w-px bg-gradient-to-b from-transparent via-slate-700 to-transparent md:left-1/2 md:-translate-x-px" />
          
          {/* Reply Section */}
          <div className="relative flex items-start gap-6 md:gap-10 group mb-12">
            <div className="absolute left-8 -translate-x-1/2 md:left-1/2 md:-translate-x-1/2 mt-1.5 w-4 h-4 rounded-full border-2 bg-slate-900 border-blue-500 z-10" />
            <div className="ml-16 md:ml-0 w-full md:w-[calc(50%-2.5rem)]">
              <div className="glass-panel p-5 rounded-2xl border border-blue-500/30 bg-blue-500/5 shadow-[0_10px_30px_rgba(59,130,246,0.1)]">
                <h4 className="text-xs font-black text-blue-400 uppercase tracking-widest mb-3">وەڵامی نووسراو</h4>
                <textarea 
                  value={note}
                  onChange={(e) => setNote(e.target.value)}
                  placeholder="وەڵامی نوسراوەکە بنووسە..."
                  className="w-full bg-black/20 border border-white/10 rounded-xl p-3 text-sm text-white placeholder:text-slate-600 outline-none focus:border-blue-500/50 min-h-[80px] transition-all"
                />
                <div className="mt-3 flex items-center justify-between">
                  <div className="flex gap-2">
                    <label className="p-2 rounded-lg bg-white/5 border border-white/10 text-slate-400 hover:text-white hover:bg-white/10 cursor-pointer transition-all flex items-center gap-2">
                      <Paperclip size={16} />
                      <span className="text-xs font-bold">هاوپێچکردنی فایل</span>
                      <input type="file" multiple className="hidden" onChange={handleFileChange} />
                    </label>
                  </div>
                  <button 
                    onClick={async () => {
                      if (!note && selectedFiles.length === 0) return;
                      setLoading(true);
                      try {
                        const uploaded = await uploadFiles(selectedFiles);
                        await updateDocument(doc.id, {
                          history: [...doc.history, { 
                            action: 'comment', 
                            fromUser: currentUser?.name || 'Unknown', 
                            timestamp: new Date().toISOString(), 
                            note 
                          }],
                          attachments: [...doc.attachments, ...uploaded]
                        });
                        setNote('');
                        setSelectedFiles([]);
                      } finally {
                        setLoading(false);
                      }
                    }}
                    disabled={loading || (!note && selectedFiles.length === 0)}
                    className="px-6 py-2 bg-gradient-to-r from-blue-600 to-blue-500 hover:from-blue-500 hover:to-blue-400 text-white text-xs font-black rounded-xl transition-all shadow-[0_5px_15px_rgba(37,99,235,0.3)] hover:shadow-[0_8px_20px_rgba(37,99,235,0.4)] hover:-translate-y-0.5 disabled:opacity-50"
                  >
                    {loading ? 'چاوەڕوانبە...' : 'ناردنی وەڵام'}
                  </button>
                </div>
                {selectedFiles.length > 0 && (
                  <div className="mt-3 flex flex-wrap gap-2">
                    {selectedFiles.map((f, i) => (
                      <div key={i} className="flex items-center gap-2 bg-white/5 px-2 py-1 rounded-lg border border-white/10 text-[10px] text-slate-400">
                        <span className="truncate max-w-[100px]">{f.name}</span>
                        <button onClick={() => removeFile(i)} className="text-red-400 hover:text-red-300 hover:bg-red-500/10 rounded p-0.5 transition-colors">×</button>
                      </div>
                    ))}
                  </div>
                )}
              </div>
            </div>
          </div>

          {doc.history.map((log, idx) => {
            const isCurrentUser = log.fromUser === currentUser?.name;
            const isComment = log.action === 'comment';
            
            return (
              <div key={log.id} className={`relative flex items-start gap-6 md:gap-10 ${isCurrentUser ? 'md:flex-row-reverse' : ''} group`}>
                
                {/* Timeline Node */}
                <div className={`absolute left-8 -translate-x-1/2 md:left-1/2 md:-translate-x-1/2 mt-1.5 w-4 h-4 rounded-full border-2 z-10 transition-all duration-300 ${
                  log.action === 'rejected' || log.action === 'returned' ? 'bg-slate-900 border-red-500 shadow-[0_0_10px_rgba(239,68,68,0.5)]' : 
                  log.action === 'approved' ? 'bg-slate-900 border-emerald-500 shadow-[0_0_10px_rgba(16,185,129,0.5)]' : 
                  isComment ? 'bg-slate-900 border-purple-500 shadow-[0_0_10px_rgba(168,85,247,0.5)]' :
                  'bg-slate-900 border-blue-500 shadow-[0_0_10px_rgba(59,130,246,0.5)]'
                }`} />

                {/* Content Card */}
                <div className={`ml-16 md:ml-0 w-full md:w-[calc(50%-2.5rem)] ${isCurrentUser ? 'text-right' : 'text-left'}`}>
                  <div className={`p-5 rounded-2xl border transition-all duration-300 hover:-translate-y-1 ${
                    isComment 
                      ? 'bg-purple-500/5 border-purple-500/20 hover:border-purple-500/40' 
                      : 'bg-white/5 border-white/10 hover:border-blue-500/30'
                  }`}>
                    <div className={`flex items-center gap-3 mb-3 ${isCurrentUser ? 'flex-row-reverse' : ''}`}>
                      <div className={`w-8 h-8 rounded-full flex items-center justify-center text-xs font-bold ${
                        isComment ? 'bg-purple-500/20 text-purple-400' : 'bg-blue-500/20 text-blue-400'
                      }`}>
                        {log.fromUser.charAt(0)}
                      </div>
                      <div className={`flex flex-col ${isCurrentUser ? 'items-end' : 'items-start'}`}>
                        <span className="font-bold text-slate-200 text-sm">{log.fromUser}</span>
                        <span className="text-[10px] text-slate-500 font-mono">{new Date(log.timestamp).toLocaleString()}</span>
                      </div>
                      {log.metadata?.department && (
                        <span className="px-2 py-0.5 rounded-full bg-white/5 text-[10px] text-slate-400 border border-white/5">
                          {log.metadata.department}
                        </span>
                      )}
                    </div>

                    <div className={`text-sm leading-relaxed ${isComment ? 'text-purple-100' : 'text-slate-300'}`}>
                      {isComment ? (
                        <div className="flex gap-2">
                          <MessageSquare size={16} className="mt-1 shrink-0 opacity-50" />
                          <p>{log.note}</p>
                        </div>
                      ) : (
                        <>
                          <div className="flex items-center gap-2 mb-2">
                            <span className={`px-2 py-0.5 rounded text-[10px] font-bold uppercase tracking-wider ${
                              log.action === 'rejected' ? 'bg-red-500/20 text-red-400' :
                              log.action === 'approved' ? 'bg-emerald-500/20 text-emerald-400' :
                              'bg-blue-500/20 text-blue-400'
                            }`}>
                              {log.action}
                            </span>
                            <span className="text-slate-500 text-xs">to {log.toUser}</span>
                          </div>
                          {log.note && <p className="bg-black/20 p-3 rounded-lg border border-white/5">{log.note}</p>}
                        </>
                      )}
                    </div>
                  </div>
                </div>
              </div>
            );
          })}
        </div>
      </div>

      {/* Action Bar */}
      {doc.currentHolderId === currentUser.id && (
        <div className="fixed bottom-6 left-1/2 -translate-x-1/2 w-full max-w-4xl px-6 z-50 print:hidden">
          <div className="glass-panel p-4 rounded-3xl border border-white/20 shadow-[0_10px_40px_rgba(0,0,0,0.5)] bg-black/40 backdrop-blur-xl flex items-center justify-between gap-4 animate-in slide-in-from-bottom-10 duration-500">
            <div className="flex gap-3 w-full">
              {action === 'edit' ? (
                <>
                  <button
                    onClick={handleEdit}
                    className="flex-1 bg-gradient-to-r from-emerald-600 to-emerald-500 hover:from-emerald-500 hover:to-emerald-400 text-white py-3.5 rounded-2xl font-bold flex items-center justify-center gap-2 hover:-translate-y-1 transition-all shadow-[0_10px_20px_rgba(16,185,129,0.3)] hover:shadow-[0_15px_30px_rgba(16,185,129,0.4)] border border-white/10"
                  >
                    <CheckCircle2 size={20} />
                    پاشەکەوتکردن (Save)
                  </button>
                  <button
                    onClick={() => setAction(null)}
                    className="flex-1 bg-white/10 hover:bg-white/20 text-white py-3.5 rounded-2xl font-bold transition-all flex items-center justify-center gap-2 border border-white/10 hover:border-white/30 backdrop-blur-md hover:shadow-[0_0_20px_rgba(255,255,255,0.1)]"
                  >
                    <XCircle size={20} />
                    پاشگەزبوونەوە (Cancel)
                  </button>
                </>
              ) : (
                <>
                  {canForward && (
                    <button
                      onClick={handleForward}
                      className="flex-1 bg-gradient-to-r from-blue-600 to-blue-500 hover:from-blue-500 hover:to-blue-400 text-white py-3.5 rounded-2xl font-bold flex items-center justify-center gap-2 hover:-translate-y-1 transition-all shadow-[0_10px_20px_rgba(37,99,235,0.3)] hover:shadow-[0_15px_30px_rgba(37,99,235,0.4)] border border-white/10"
                    >
                      <Send size={20} />
                      ناردن
                    </button>
                  )}
                  {canApprove && (
                    <button
                      onClick={handleApprove}
                      className="flex-1 bg-gradient-to-r from-emerald-600 to-emerald-500 hover:from-emerald-500 hover:to-emerald-400 text-white py-3.5 rounded-2xl font-bold flex items-center justify-center gap-2 hover:-translate-y-1 transition-all shadow-[0_10px_20px_rgba(16,185,129,0.3)] hover:shadow-[0_15px_30px_rgba(16,185,129,0.4)] border border-white/10"
                    >
                      <CheckCircle2 size={20} />
                      پەسەندکردن
                    </button>
                  )}
                  {canReject && (
                    <button
                      onClick={() => setShowRejectModal(true)}
                      className="flex-1 bg-gradient-to-r from-red-600 to-red-500 hover:from-red-500 hover:to-red-400 text-white py-3.5 rounded-2xl font-bold flex items-center justify-center gap-2 hover:-translate-y-1 transition-all shadow-[0_10px_20px_rgba(220,38,38,0.3)] hover:shadow-[0_15px_30px_rgba(220,38,38,0.4)] border border-white/10"
                    >
                      <XCircle size={20} />
                      ڕەتکردنەوە
                    </button>
                  )}
                  {canReturn && (
                    <button
                      onClick={handleReturn}
                      className="flex-1 bg-gradient-to-r from-amber-500 to-amber-400 hover:from-amber-400 hover:to-amber-300 text-white py-3.5 rounded-2xl font-bold flex items-center justify-center gap-2 hover:-translate-y-1 transition-all shadow-[0_10px_20px_rgba(245,158,11,0.3)] hover:shadow-[0_15px_30px_rgba(245,158,11,0.4)] border border-white/10"
                    >
                      <RotateCcw size={20} />
                      گەڕاندنەوە
                    </button>
                  )}
                  {canEdit && (
                    <button
                      onClick={() => setAction('edit')}
                      className="flex-1 bg-white/10 hover:bg-white/20 text-white py-3.5 rounded-2xl font-bold flex items-center justify-center gap-2 hover:-translate-y-1 transition-all border border-white/10 hover:shadow-[0_0_20px_rgba(255,255,255,0.1)]"
                    >
                      <Edit2 size={20} />
                      دەستکاری
                    </button>
                  )}
                  <button
                    onClick={() => {
                      const commentSection = document.getElementById('comment-section');
                      commentSection?.scrollIntoView({ behavior: 'smooth' });
                    }}
                    className="flex-1 bg-gradient-to-r from-purple-600 to-purple-500 hover:from-purple-500 hover:to-purple-400 text-white py-3.5 rounded-2xl font-bold flex items-center justify-center gap-2 hover:-translate-y-1 transition-all shadow-[0_10px_20px_rgba(147,51,234,0.3)] hover:shadow-[0_15px_30px_rgba(147,51,234,0.4)] border border-white/10"
                  >
                    <MessageSquare size={20} />
                    وەڵامدانەوە (Reply)
                  </button>
                  {canHandDeliver && (
                    <button
                      onClick={() => setShowHandDelivery(true)}
                      className="flex-1 bg-gradient-to-r from-indigo-600 to-indigo-500 hover:from-indigo-500 hover:to-indigo-400 text-white py-3.5 rounded-2xl font-bold transition-all flex items-center justify-center gap-2 shadow-[0_10px_20px_rgba(99,102,241,0.3)] hover:shadow-[0_15px_30px_rgba(99,102,241,0.4)] hover:-translate-y-1 border border-white/10"
                    >
                      <UserCheck size={20} />
                      بە زمە
                    </button>
                  )}
                </>
              )}
            </div>
          </div>
        </div>
      )}

      {/* Forward Modal (Smart Routing) */}
      {showForwardModal && (
        <div className="fixed inset-0 bg-black/80 backdrop-blur-md z-[60] flex items-center justify-center p-4 animate-in fade-in duration-200">
          <div className="glass-panel rounded-3xl w-full max-w-lg shadow-2xl overflow-hidden animate-in zoom-in-95 duration-200 border border-white/10">
            <div className="p-6 border-b border-white/10 flex justify-between items-center bg-white/5 backdrop-blur-md">
              <h3 className="text-xl font-bold text-white neon-text flex items-center gap-2">
                <Send size={24} className="text-blue-400" />
                ناردنی نوسراو (Smart Routing)
              </h3>
              <button onClick={() => setShowForwardModal(false)} className="p-2 hover:bg-white/10 rounded-full transition-all hover:shadow-[0_0_10px_rgba(255,255,255,0.1)]">
                <XCircle size={24} className="text-slate-400 hover:text-white" />
              </button>
            </div>
            
            <div className="p-6 space-y-6">
              <div className="flex items-center justify-between bg-white/5 p-3 rounded-2xl border border-white/10">
                <div className="flex items-center gap-2">
                  <Activity size={16} className="text-purple-400" />
                  <span className="text-sm font-bold text-slate-300">ناردنی دەستی</span>
                </div>
                <button 
                  onClick={() => {
                    setManualRouting(!manualRouting);
                    setSelectedDept('');
                    setSelectedTarget('');
                  }}
                  className={`w-12 h-6 rounded-full transition-all relative ${manualRouting ? 'bg-purple-600 shadow-[0_0_10px_rgba(147,51,234,0.4)]' : 'bg-slate-700'}`}
                >
                  <div className={`absolute top-1 w-4 h-4 rounded-full bg-white transition-all shadow-sm ${manualRouting ? 'left-7' : 'left-1'}`} />
                </button>
              </div>

              {!manualRouting && (
                <div>
                  <label className="block text-sm font-bold text-slate-300 mb-2">قۆناغی داهاتوو (ڕەوتی کار)</label>
                  <div className="bg-blue-500/10 border border-blue-500/20 rounded-xl p-4 flex items-center gap-3">
                    <div className="w-10 h-10 rounded-full bg-blue-500/20 flex items-center justify-center text-blue-400">
                      <Clock size={20} className="animate-pulse" />
                    </div>
                    <div>
                      <p className="text-blue-300 font-bold">{getNextStage(doc.workflowStage)}</p>
                      <p className="text-xs text-blue-400/70">بەپێی ڕەوتی کار (Workflow)</p>
                    </div>
                  </div>
                </div>
              )}

              {manualRouting && (
                <div>
                  <label className="block text-sm font-bold text-slate-300 mb-2">هەڵبژاردنی ژوور / بەش</label>
                  <select
                    value={selectedDept}
                    onChange={e => {
                      setSelectedDept(e.target.value);
                      setSelectedTarget('');
                    }}
                    className="w-full px-4 py-3 rounded-xl bg-black/40 border border-white/10 focus:border-purple-500 outline-none text-white transition-all"
                  >
                    <option value="" className="bg-slate-900">هەڵبژاردنی ژوور...</option>
                    {departments.map(d => (
                      <option key={d.id} value={d.id} className="bg-slate-900">{d.name}</option>
                    ))}
                  </select>
                </div>
              )}

              <div>
                <label className="block text-sm font-bold text-slate-300 mb-2">ناردن بۆ</label>
                <select
                  value={selectedTarget}
                  onChange={e => setSelectedTarget(e.target.value)}
                  className="w-full px-4 py-3 rounded-xl bg-black/40 border border-white/10 focus:border-blue-500 outline-none text-white transition-all"
                >
                  <option value="" className="bg-slate-900">هەڵبژێرە...</option>
                  {(manualRouting 
                    ? (selectedDept ? users.filter(u => u.department === selectedDept) : users)
                    : availableTargets
                  ).filter(u => u.id !== currentUser?.id).map(u => (
                    <option key={u.id} value={u.id} className="bg-slate-900">
                      {u.title} - {u.name} ({departments.find(d => d.id === u.department)?.name})
                    </option>
                  ))}
                </select>
                {!manualRouting && availableTargets.length === 0 && (
                  <p className="text-xs text-red-400 mt-2">هیچ بەکارهێنەرێک بۆ ئەم قۆناغە نەدۆزرایەوە. تکایە "ناردنی دەستی" چالاک بکە.</p>
                )}
              </div>

              <div>
                <label className="block text-sm font-bold text-slate-300 mb-2">تێبینی (ئارەزوومەندانە)</label>
                <textarea
                  value={note}
                  onChange={e => setNote(e.target.value)}
                  className="w-full px-4 py-3 rounded-xl bg-black/40 border border-white/10 focus:border-blue-500 outline-none text-white transition-all h-24 resize-none"
                  placeholder="تێبینی بنووسە..."
                />
              </div>

              <button
                onClick={submitForward}
                disabled={loading || !selectedTarget}
                className="w-full bg-gradient-to-r from-blue-600 to-blue-500 hover:from-blue-500 hover:to-blue-400 text-white py-4 rounded-xl font-bold flex items-center justify-center gap-2 hover:-translate-y-1 transition-all shadow-[0_10px_20px_rgba(37,99,235,0.3)] hover:shadow-[0_15px_30px_rgba(37,99,235,0.4)] disabled:opacity-50 disabled:cursor-not-allowed border border-white/10"
              >
                {loading ? 'دەینێرێت...' : 'ناردن'}
              </button>
            </div>
          </div>
        </div>
      )}

      {/* Return Modal (Rejection Interface) */}
      {showReturnModal && (
        <div className="fixed inset-0 bg-black/80 backdrop-blur-md z-[60] flex items-center justify-center p-4 animate-in fade-in duration-200">
          <div className="glass-panel rounded-3xl w-full max-w-lg shadow-2xl overflow-hidden animate-in zoom-in-95 duration-200 border border-white/10">
            <div className="p-6 border-b border-white/10 flex justify-between items-center bg-white/5 backdrop-blur-md">
              <h3 className="text-xl font-bold text-white neon-text flex items-center gap-2">
                <RotateCcw size={24} className="text-amber-400" />
                گەڕاندنەوەی نوسراو
              </h3>
              <button onClick={() => setShowReturnModal(false)} className="p-2 hover:bg-white/10 rounded-full transition-all hover:shadow-[0_0_10px_rgba(255,255,255,0.1)]">
                <XCircle size={24} className="text-slate-400 hover:text-white" />
              </button>
            </div>
            
            <div className="p-6 space-y-6">
              <div className="bg-amber-500/10 border border-amber-500/20 rounded-xl p-4 text-amber-200 text-sm leading-relaxed">
                تکایە ئەو کەسە دیاری بکە کە نوسراوەکەی بۆ دەگەڕێنیتەوە.
              </div>

              <div>
                <label className="block text-sm font-bold text-slate-300 mb-2">گەڕاندنەوە بۆ</label>
                <select
                  value={returnTargetId}
                  onChange={e => setReturnTargetId(e.target.value)}
                  className="w-full px-4 py-3 rounded-xl bg-black/40 border border-white/10 focus:border-amber-500 outline-none text-white transition-all"
                >
                  <option value="" className="bg-slate-900">هەڵبژێرە...</option>
                  {users.filter(u => {
                      if (u.id === currentUser?.id) return false;
                      // Include sender and participants
                      return u.id === doc.senderId || doc.participants?.includes(u.id);
                  }).map(u => (
                    <option key={u.id} value={u.id} className="bg-slate-900">
                      {u.title} - {u.name} ({u.role})
                    </option>
                  ))}
                </select>
              </div>

              <div>
                <label className="block text-sm font-bold text-slate-300 mb-2">هۆکاری گەڕاندنەوە</label>
                <textarea
                  value={returnReason}
                  onChange={e => setReturnReason(e.target.value)}
                  className="w-full px-4 py-3 rounded-xl bg-black/40 border border-red-500/30 focus:border-red-500 outline-none text-white transition-all h-32 resize-none placeholder:text-red-400/50"
                  placeholder="هۆکاری گەڕاندنەوە بنووسە..."
                />
              </div>

              <button
                onClick={submitReturn}
                disabled={loading || !returnTargetId || !returnReason}
                className="w-full bg-gradient-to-r from-amber-500 to-amber-400 hover:from-amber-400 hover:to-amber-300 text-white py-4 rounded-xl font-bold flex items-center justify-center gap-2 hover:-translate-y-1 transition-all shadow-[0_10px_20px_rgba(245,158,11,0.3)] hover:shadow-[0_15px_30px_rgba(245,158,11,0.4)] disabled:opacity-50 disabled:cursor-not-allowed border border-white/10"
              >
                {loading ? 'دەگەڕێنێتەوە...' : 'گەڕاندنەوە'}
              </button>
            </div>
          </div>
        </div>
      )}

      {showRejectModal && (
        <div className="fixed inset-0 bg-black/80 backdrop-blur-md z-[60] flex items-center justify-center p-4 animate-in fade-in duration-200">
          <div className="glass-panel rounded-3xl w-full max-w-lg shadow-2xl overflow-hidden animate-in zoom-in-95 duration-200 border border-white/10">
            <div className="p-6 border-b border-white/10 flex justify-between items-center bg-white/5 backdrop-blur-md">
              <h3 className="text-xl font-bold text-white neon-text flex items-center gap-2">
                <XCircle size={24} className="text-red-400" />
                ڕەتکردنەوەی نوسراو
              </h3>
              <button onClick={() => setShowRejectModal(false)} className="p-2 hover:bg-white/10 rounded-full transition-all hover:shadow-[0_0_10px_rgba(255,255,255,0.1)]">
                <XCircle size={24} className="text-slate-400 hover:text-white" />
              </button>
            </div>
            
            <div className="p-6 space-y-6">
              <div className="bg-red-500/10 border border-red-500/20 rounded-xl p-4 text-red-200 text-sm leading-relaxed">
                ئەم نوسراوە بە تەواوی ڕەتدەکرێتەوە. تکایە هۆکاری ڕەتکردنەوە بنووسە.
              </div>

              <div>
                <label className="block text-sm font-bold text-slate-300 mb-2">هۆکاری ڕەتکردنەوە</label>
                <textarea
                  value={rejectReason}
                  onChange={e => setRejectReason(e.target.value)}
                  className="w-full px-4 py-3 rounded-xl bg-black/40 border border-red-500/30 focus:border-red-500 outline-none text-white transition-all h-32 resize-none placeholder:text-red-400/50"
                  placeholder="هۆکاری ڕەتکردنەوە بنووسە..."
                />
              </div>

              <button
                onClick={submitReject}
                disabled={loading || !rejectReason}
                className="w-full bg-gradient-to-r from-red-600 to-red-500 hover:from-red-500 hover:to-red-400 text-white py-4 rounded-xl font-bold flex items-center justify-center gap-2 hover:-translate-y-1 transition-all shadow-[0_10px_20px_rgba(220,38,38,0.3)] hover:shadow-[0_15px_30px_rgba(220,38,38,0.4)] disabled:opacity-50 disabled:cursor-not-allowed border border-white/10"
              >
                {loading ? 'ڕەتدەکرێتەوە...' : 'ڕەتکردنەوە'}
              </button>
            </div>
          </div>
        </div>
      )}

      {showHandDelivery && (
        <HandDeliveryModal 
          docId={doc.id} 
          onClose={() => setShowHandDelivery(false)} 
          onSuccess={() => {
            setShowHandDelivery(false);
            onBack();
          }} 
        />
      )}

      {/* Comment Modal */}
      {showCommentModal && (
        <div className="fixed inset-0 bg-black/80 backdrop-blur-sm z-[70] flex items-center justify-center p-4 animate-in fade-in duration-200">
          <div className="glass-panel w-full max-w-lg rounded-3xl p-8 border border-white/10 shadow-2xl animate-in zoom-in-95 duration-200">
            <h3 className="text-xl font-bold text-white mb-6 flex items-center gap-3 neon-text">
              <MessageSquare className="text-purple-400" />
              زیادکردنی تێبینی
            </h3>
            
            <textarea
              value={commentText}
              onChange={e => setCommentText(e.target.value)}
              className="w-full h-40 p-4 rounded-xl bg-black/40 border border-white/10 focus:border-purple-500 outline-none resize-none text-white placeholder:text-slate-500 mb-6 transition-all"
              placeholder="تێبینی خۆت بنوسە..."
              autoFocus
            />

            <div className="flex gap-3">
              <button
                onClick={submitComment}
                disabled={!commentText.trim() || loading}
                className="flex-1 bg-gradient-to-r from-purple-600 to-purple-500 hover:from-purple-500 hover:to-purple-400 py-3 rounded-xl font-bold text-white disabled:opacity-50 disabled:cursor-not-allowed flex items-center justify-center gap-2 transition-all shadow-[0_10px_20px_rgba(147,51,234,0.3)] hover:shadow-[0_15px_30px_rgba(147,51,234,0.4)] hover:-translate-y-1 border border-white/10"
              >
                {loading ? 'تۆماردەکرێت...' : 'تۆمارکردن'}
              </button>
              <button
                onClick={() => setShowCommentModal(false)}
                className="flex-1 bg-white/5 hover:bg-white/10 text-slate-300 py-3 rounded-xl font-bold border border-white/10 transition-all hover:text-white hover:shadow-[0_0_15px_rgba(255,255,255,0.05)]"
              >
                پاشگەزبوونەوە
              </button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
};
