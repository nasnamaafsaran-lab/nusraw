import React, { useState } from 'react';
import { useApp } from './context';
import { Sidebar } from './components/Sidebar';
import { Header } from './components/Header';
import { Dashboard } from './components/Dashboard';
import { CreateDocument, DocumentDetail, EmployeeRequestsPanel } from './components/Views';
import { DocumentsPanel } from './components/DocumentsPanel';
import { PrintPanel, ArchivePanel } from './components/PrintPanel';
import { NotificationCenter } from './components/NotificationCenter';

import { DepartmentCenter, WorkflowTemplateManager } from './components/DepartmentCenter';
import { UserManagement } from './components/UserManagement';
import { ReportsPanel } from './components/ReportsPanel';
import { SettingsPanel } from './components/SettingsPanel';
import { ChatInterface } from './components/ChatInterface';
import { SearchPanel } from './components/SearchPanel';
import { CircularsPanel } from './components/CircularsPanel';
import { HandDeliveryPanel } from './components/HandDeliveryPanel';
import { Shield, Lock, X, CheckCircle2, AlertTriangle, Info, ArrowLeft } from 'lucide-react';
import { Document, MOCK_USERS } from './types';

import { UserProfile } from './components/UserProfile';

const ToastContainer: React.FC = () => {
  const { toasts, removeToast } = useApp();
  
  if (toasts.length === 0) return null;

  return (
    <div className="fixed bottom-6 right-6 z-50 flex flex-col gap-3 pointer-events-none">
      {toasts.map(toast => (
        <div 
          key={toast.id} 
          className={`pointer-events-auto glass-panel p-4 rounded-xl flex items-center gap-4 min-w-[320px] toast-enter overflow-hidden relative group ${
            toast.type === 'error' ? 'toast-shake' : ''
          }`}
        >
          <div className={`absolute left-0 top-0 bottom-0 w-1 ${
            toast.type === 'success' ? 'bg-emerald-500 shadow-[0_0_10px_rgba(16,185,129,0.5)]' :
            toast.type === 'error' ? 'bg-red-500 shadow-[0_0_10px_rgba(239,68,68,0.5)]' :
            toast.type === 'warning' ? 'bg-yellow-500 shadow-[0_0_10px_rgba(234,179,8,0.5)]' :
            'bg-blue-500 shadow-[0_0_10px_rgba(59,130,246,0.5)]'
          }`} />
          
          <div className={`p-2 rounded-full ${
            toast.type === 'success' ? 'bg-emerald-500/20 text-emerald-400' :
            toast.type === 'error' ? 'bg-red-500/20 text-red-400' :
            toast.type === 'warning' ? 'bg-yellow-500/20 text-yellow-400' :
            'bg-blue-500/20 text-blue-400'
          }`}>
            {toast.type === 'success' ? <CheckCircle2 size={20} /> :
             toast.type === 'error' ? <AlertTriangle size={20} /> :
             toast.type === 'warning' ? <AlertTriangle size={20} /> :
             <Info size={20} />}
          </div>

          <div className="flex-1">
             <p className="text-sm font-bold text-white">{toast.message}</p>
             {toast.action && (
               <button
                 onClick={toast.action.onClick}
                 className="mt-2 text-xs bg-white/10 hover:bg-white/20 text-white px-3 py-1.5 rounded transition-colors border border-white/10"
               >
                 {toast.action.label}
               </button>
             )}
          </div>
          
          <button 
            onClick={() => removeToast(toast.id)} 
            className="text-slate-400 hover:text-white transition-all opacity-0 group-hover:opacity-100 hover:bg-white/10 p-1 rounded-full hover:shadow-[0_0_10px_rgba(255,255,255,0.1)]"
          >
            <X size={16} />
          </button>
        </div>
      ))}
    </div>
  );
};

const LoginScreen: React.FC = () => {
  const { login, users } = useApp();
  const [username, setUsername] = useState('');
  const [password, setPassword] = useState('');
  const [isLoading, setIsLoading] = useState(false);

  const handleLogin = async (e: React.FormEvent) => {
    e.preventDefault();
    setIsLoading(true);
    // Simulate loading for effect
    await new Promise(resolve => setTimeout(resolve, 800));
    const success = await login(username, password);
    setIsLoading(false);
    if (!success) {
        setPassword('');
    }
  };

  return (
    <div className="min-h-screen flex items-center justify-center p-4 relative overflow-hidden" dir="rtl">
      {/* Background Effects */}
      <div className="absolute top-0 left-0 w-full h-full overflow-hidden -z-10">
        <div className="absolute top-1/4 left-1/4 w-96 h-96 bg-violet-600/20 rounded-full blur-[100px] animate-pulse" />
        <div className="absolute bottom-1/4 right-1/4 w-96 h-96 bg-blue-600/20 rounded-full blur-[100px] animate-pulse delay-1000" />
      </div>

      <div className="glass-panel rounded-3xl w-full max-w-md p-8 relative z-10 border-white/10">
        <div className="text-center mb-8">
          <div className="w-24 h-24 glass-card rounded-2xl flex items-center justify-center mx-auto mb-6 neon-border animate-float">
            <Shield className="text-blue-400 drop-shadow-[0_0_10px_rgba(59,130,246,0.5)]" size={48} />
          </div>
          <h1 className="text-3xl font-bold text-white mb-2 neon-text">ئیدارەی ئەفسەران</h1>
          <p className="text-slate-400">تکایە ناوی بەکارهێنەر داخل بکە</p>
        </div>

        <form onSubmit={handleLogin} className="space-y-6">
          <div>
            <label className="block text-sm font-medium text-slate-300 mb-2">ناوی بەکارهێنەر</label>
            <div className="relative group">
              <input
                type="text"
                value={username}
                onChange={e => setUsername(e.target.value)}
                className="w-full px-4 py-3.5 pr-10 rounded-xl outline-none transition-all text-left"
                placeholder="admin, control, dg..."
                dir="ltr"
              />
              <Lock className="absolute right-3 top-3.5 text-slate-500 group-focus-within:text-blue-400 transition-colors" size={18} />
            </div>
          </div>

          <div>
            <label className="block text-sm font-medium text-slate-300 mb-2">وشەی نهێنی</label>
            <div className="relative group">
              <input
                type="password"
                value={password}
                onChange={e => setPassword(e.target.value)}
                className="w-full px-4 py-3.5 pr-10 rounded-xl outline-none transition-all text-left"
                placeholder="••••••"
                dir="ltr"
              />
              <Lock className="absolute right-3 top-3.5 text-slate-500 group-focus-within:text-blue-400 transition-colors" size={18} />
            </div>
          </div>

          <button
            type="submit"
            disabled={isLoading}
            className="w-full bg-gradient-to-r from-blue-600 to-indigo-600 hover:from-blue-500 hover:to-indigo-500 text-white py-4 rounded-xl font-bold transition-all flex items-center justify-center gap-2 shadow-[0_0_20px_rgba(59,130,246,0.4)] hover:shadow-[0_0_30px_rgba(59,130,246,0.6)] hover:-translate-y-1 border border-white/10"
          >
            {isLoading ? (
              <div className="w-5 h-5 border-2 border-white/30 border-t-white rounded-full animate-spin" />
            ) : (
              'چوونەژوورەوە'
            )}
          </button>
        </form>

        <div className="mt-8 pt-6 border-t border-white/5">
          <p className="text-xs text-center text-slate-500 mb-4">بەکارهێنەرەکان بۆ تاقیکردنەوە (Password: 123):</p>
          <div className="flex flex-wrap gap-2 justify-center max-h-32 overflow-y-auto custom-scrollbar">
            {users.length === 0 ? (
              <span className="text-xs text-slate-500">Loading users...</span>
            ) : (
              users.map(u => (
                <button
                  key={u.id}
                  onClick={() => { setUsername(u.username); setPassword('123'); }}
                  className={`text-xs px-2 py-1 rounded transition-all hover:-translate-y-0.5 ${
                    u.role === 'super_admin' 
                      ? 'bg-red-500/10 hover:bg-red-500/20 text-red-400 border border-red-500/20 font-bold shadow-[0_0_10px_rgba(239,68,68,0.2)]'
                      : 'bg-white/5 hover:bg-white/10 text-slate-300 border border-white/5 hover:shadow-[0_0_10px_rgba(255,255,255,0.05)]'
                  }`}
                >
                  {u.username} ({u.role})
                </button>
              ))
            )}
          </div>
        </div>
      </div>
    </div>
  );
};

export default function App() {
  const { currentUser, documents } = useApp(); // Added documents
  const [activeView, setActiveView] = useState('dashboard');
  const [selectedDoc, setSelectedDoc] = useState<Document | null>(null);

  React.useEffect(() => {
    if (selectedDoc) {
      const updatedDoc = documents.find(d => d.id === selectedDoc.id);
      if (updatedDoc && updatedDoc !== selectedDoc) {
        setSelectedDoc(updatedDoc);
      }
    }
  }, [documents, selectedDoc]);

  React.useEffect(() => {
    const handleNavigate = (e: CustomEvent<string>) => {
      const docId = e.detail;
      const doc = documents.find(d => d.id === docId);
      if (doc) {
        setSelectedDoc(doc);
      }
    };
    window.addEventListener('NAVIGATE_TO_DOC', handleNavigate as EventListener);
    return () => window.removeEventListener('NAVIGATE_TO_DOC', handleNavigate as EventListener);
  }, [documents]);

  if (!currentUser) {
    return <LoginScreen />;
  }

  const renderContent = () => {
    if (selectedDoc) {
      return <DocumentDetail doc={selectedDoc} onBack={() => setSelectedDoc(null)} />;
    }

    switch (activeView) {
      case 'create':
      case 'dispatch':
        return <CreateDocument onSuccess={() => setActiveView('dashboard')} />;
      case 'documents':
        return <DocumentsPanel onViewDoc={setSelectedDoc} />;
      case 'print':
        return <PrintPanel />;
      case 'archive':
        return <ArchivePanel />;
      case 'users':
        return <UserManagement />;
      case 'departments':
        return <DepartmentCenter />;
      case 'workflow_templates':
        return (
          <div className="space-y-6">
            <div className="flex items-center justify-between">
              <button 
                onClick={() => setActiveView('dashboard')}
                className="flex items-center gap-2 text-slate-400 hover:text-white transition-all hover:-translate-x-1 px-3 py-2 rounded-lg hover:bg-white/5 hover:shadow-[0_0_10px_rgba(255,255,255,0.05)]"
              >
                <ArrowLeft size={20} />
                <span>گەڕانەوە بۆ داشبۆرد</span>
              </button>
            </div>
            <WorkflowTemplateManager onClose={() => setActiveView('dashboard')} />
          </div>
        );
      case 'reports':
        return <ReportsPanel />;
      case 'settings':
        return <SettingsPanel />;
      case 'notifications':
        return <NotificationCenter onViewDoc={setSelectedDoc} />;
      case 'search':
        return <SearchPanel onViewDoc={setSelectedDoc} />;
      case 'chats':
        return <ChatInterface />;
      case 'circulars':
        return <CircularsPanel />;
      case 'hand_delivery':
        return <HandDeliveryPanel />;
      case 'requests':
        return <EmployeeRequestsPanel />;
      case 'profile':
        return <UserProfile />;
      default:
        return <Dashboard onViewDoc={setSelectedDoc} onNavigate={setActiveView} />;
    }
  };

  console.log('Render End');

  return (
    <div className="flex h-screen font-sans overflow-hidden text-slate-200 bg-transparent" dir="rtl">
      <ToastContainer />
      
      {/* Sidebar - Fixed Right */}
      <Sidebar activeView={activeView} setActiveView={(view) => {
        setActiveView(view);
        setSelectedDoc(null);
      }} />

      {/* Main Content Area */}
      <div className="flex-1 flex flex-col min-w-0 relative z-0 bg-transparent">
        {/* Header - Fixed Top */}
        <Header 
          onSearchClick={() => setActiveView('search')}
          onNotificationClick={() => setActiveView('notifications')}
          onProfileClick={() => setActiveView('profile')}
        />

        {/* Scrollable Content */}
        <main className="flex-1 overflow-y-auto p-6 custom-scrollbar relative">
          <div className="max-w-7xl mx-auto animate-in fade-in zoom-in-[0.98] duration-150 ease-out pb-20 relative z-10">
            {renderContent()}
          </div>
        </main>
      </div>
    </div>
  );
}
